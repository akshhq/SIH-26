# Smart India Hackathon 2026 — Problem Statements (Complete Directory)

**Source:** Official SIH Portal — [https://sih.gov.in/sih2026PS](https://sih.gov.in/sih2026PS)  
**Total Problem Statements:** 226 | **Hardware:** 54 | **Software:** 172 | **Themes:** 18 | **Organizations:** 30

This document contains the complete details for all 226 Smart India Hackathon 2026 Problem Statements extracted directly from the official portal, including full problem descriptions, backgrounds, expected solutions, organization/department info, category, theme, submission count, deadlines, and dataset/reference links.

---

## Table of Contents
1. [Executive Summary & Statistics](#executive-summary--statistics)
2. [Theme Distribution](#theme-distribution)
3. [Organization / Ministry Distribution](#organization--ministry-distribution)
4. [Master Problem Statement Index (1–226)](#master-problem-statement-index)
5. [Detailed Problem Statements (SIH26001 – SIH26226)](#detailed-problem-statements)

---

## Executive Summary & Statistics

| Metric | Count / Detail |
|---|---|
| **Total Problem Statements** | **226** |
| **Software Statements** | **172** |
| **Hardware Statements** | **54** |
| **Distinct Themes** | **18** |
| **Participating Organizations / Ministries** | **30** |
| **Submitted Idea(s) Capacity** | 0 / 500 per problem statement |
| **Idea Submission Deadline** | 20 September 2026 |

### Theme Distribution

| Theme | Software | Hardware | Total |
|---|---|---|---|
| Miscellaneous | 32 | 6 | **38** |
| Smart Automation | 24 | 7 | **31** |
| Disaster Management | 24 | 5 | **29** |
| Blockchain & Cybersecurity | 20 | 2 | **22** |
| MedTech / BioTech / HealthTech | 9 | 5 | **14** |
| Smart Education | 11 | 2 | **13** |
| Agriculture, FoodTech & Rural Development | 8 | 4 | **12** |
| Space Technology | 9 | 2 | **11** |
| Robotics and Drones | 7 | 3 | **10** |
| Transportation & Logistics | 7 | 1 | **8** |
| Fitness & Sports | 5 | 3 | **8** |
| Heritage & Culture | 3 | 4 | **7** |
| Travel & Tourism | 3 | 3 | **6** |
| Smart Resource Conservation | 2 | 3 | **5** |
| Smart Vehicles | 2 | 2 | **4** |
| Renewable / Sustainable Energy | 2 | 2 | **4** |
| Clean & Green Technology | 2 | 0 | **2** |
| Toys & Games | 2 | 0 | **2** |

### Organization / Ministry Distribution

| Organization / Ministry | Software | Hardware | Total |
|---|---|---|---|
| AICTE | 17 | 17 | **34** |
| Ministry of Earth Sciences (MoES) | 27 | 3 | **30** |
| National Technical Research Organisation (NTRO) | 22 | 1 | **23** |
| Indian Space Research Organisation(ISRO) | 10 | 1 | **11** |
| Ministry of Home Affairs | 10 | 1 | **11** |
| Ministry of Rural Development | 9 | 1 | **10** |
| Ministry of Consumer Affairs, Food & Public Distribution | 8 | 2 | **10** |
| Government Of Maharashtra | 9 | 0 | **9** |
| Ministry of Social Justice and Empowerment (MoSJE) | 7 | 1 | **8** |
| DRDO | 4 | 3 | **7** |
| Ministry of Development of North Eastern Region (MDoNER) | 3 | 2 | **5** |
| Governmcnt of Jharkhand | 3 | 2 | **5** |
| Ministry of Ayush | 4 | 1 | **5** |
| Autodesk | 3 | 2 | **5** |
| Bharat Electronics Limited | 5 | 0 | **5** |
| Egreen Quanta | 5 | 0 | **5** |
| Qualcomm Inc | 0 | 5 | **5** |
| Ministry of Steel | 2 | 2 | **4** |
| MoSPI | 4 | 0 | **4** |
| Oil India Limited | 4 | 0 | **4** |
| Ministry of MSME | 1 | 2 | **3** |
| Ministry of Coal | 2 | 1 | **3** |
| Ministry of Railways | 2 | 1 | **3** |
| Ministry of Cooperation | 1 | 2 | **3** |
| All India Council for Technical Education (AICTE) | 3 | 0 | **3** |
| Ministry of Fisheries, Animal Husbandry & Dairying | 1 | 2 | **3** |
| Mangalore Refinery and Petrochemicals Limited (MRPL) | 2 | 1 | **3** |
| MathWorks | 2 | 0 | **2** |
| Ministry of Petroleum & Natural Gas | 2 | 0 | **2** |
| Ministry of Defence (MoD) | 0 | 1 | **1** |

---

## Master Problem Statement Index

| S.No | PS Number | Problem Statement Title | Category | Organization | Theme | Details |
|---|---|---|---|---|---|---|
| 1 | [SIH26001](#sih26001) | AI-Based early warning and landslide Risk Monitoring System in NER | Software | Ministry of Development of North Eastern Region (MDoNER) | Disaster Management | [View Details &rarr;](#sih26001) |
| 2 | [SIH26002](#sih26002) | Al-Based Smart Logistics and Accessibility Intelligence Platform for North Eastern Region (NER) | Software | Ministry of Development of North Eastern Region (MDoNER) | Smart Automation | [View Details &rarr;](#sih26002) |
| 3 | [SIH26003](#sih26003) | AI-Based Cognitive Gaming and Memory Assistance Platform for Elderly Dementia Patients in North Eastern Region (NER) | Software | Ministry of Development of North Eastern Region (MDoNER) | Space Technology | [View Details &rarr;](#sih26003) |
| 4 | [SIH26004](#sih26004) | Al-Assisted Early Detection System for Osteoarthritis (OA) Risk Markers in North Eastern Region (NER) | Hardware | Ministry of Development of North Eastern Region (MDoNER) | Space Technology | [View Details &rarr;](#sih26004) |
| 5 | [SIH26005](#sih26005) | Solar-Powered Smart Mini Cold Storage System for Fresh Vegetables in North Eastern Region (NER) | Hardware | Ministry of Development of North Eastern Region (MDoNER) | Smart Vehicles | [View Details &rarr;](#sih26005) |
| 6 | [SIH26006](#sih26006) | Development of an Intelligent Freight Forecasting Model for Optimized Vessel Chartering and Bulk Cargo Procurement from overseas to East Coast of India | Software | Ministry of Steel | Transportation & Logistics | [View Details &rarr;](#sih26006) |
| 7 | [SIH26007](#sih26007) | Safe and Efficient Operation of Mine Vehicles in Fog and Low-Visibility Conditions in Open Cast Iron Ore Mines. | Hardware | Ministry of Steel | Smart Automation | [View Details &rarr;](#sih26007) |
| 8 | [SIH26008](#sih26008) | Belt Joint Rupture and Conveyor Belt Damages in Iron Ore Mining Industry: Intelligent Monitoring and Prediction of Conveyor Belt Joint Rupture and Damages in Iron Ore Mining Industry. | Hardware | Ministry of Steel | Smart Automation | [View Details &rarr;](#sih26008) |
| 9 | [SIH26009](#sih26009) | Using AI/ML and Space Technology to Identify Manganese Reserves and Overcome Production Shortfalls. | Software | Ministry of Steel | Smart Automation | [View Details &rarr;](#sih26009) |
| 10 | [SIH26010](#sih26010) | Survey/Resurvey of Rural Agricultural Land in lndia | Hardware | Ministry of Rural Development | Smart Automation | [View Details &rarr;](#sih26010) |
| 11 | [SIH26011](#sih26011) | 3D ULPIN Generation and vertical Property Mapping SYstem | Software | Ministry of Rural Development | Space Technology | [View Details &rarr;](#sih26011) |
| 12 | [SIH26012](#sih26012) | AI-Based Automated Urban Parcel Mapping and Cadastral Feature Extraction System using Drone lmagery | Software | Ministry of Rural Development | Robotics and Drones | [View Details &rarr;](#sih26012) |
| 13 | [SIH26013](#sih26013) | Automated lntegration and lntelligent Harmonization of Multi-source Geospatial Data for urban Land Record Management. | Software | Ministry of Rural Development | Disaster Management | [View Details &rarr;](#sih26013) |
| 14 | [SIH26014](#sih26014) | An lntegrated GIS-based Digital Public lnfrastructure for Land Governance | Software | Ministry of Rural Development | Robotics and Drones | [View Details &rarr;](#sih26014) |
| 15 | [SIH26015](#sih26015) | Application of Geospatial Techniques for visualization and analysis to interpret Geo-Coded lmages to enhance watershed Development Outcomes. | Software | Ministry of Rural Development | Disaster Management | [View Details &rarr;](#sih26015) |
| 16 | [SIH26016](#sih26016) | Real-Time National Land Acquisition & Management System for End-to-End Digital Monitoring and Decision Support | Software | Ministry of Rural Development | Miscellaneous | [View Details &rarr;](#sih26016) |
| 17 | [SIH26017](#sih26017) | Predictive Analytics System for Early Detection of Land Acquisition Delays | Software | Ministry of Rural Development | Agriculture, FoodTech & Rural Development | [View Details &rarr;](#sih26017) |
| 18 | [SIH26018](#sih26018) | Intelligent Land Record Digitization and Validation System | Software | Ministry of Rural Development | MedTech / BioTech / HealthTech | [View Details &rarr;](#sih26018) |
| 19 | [SIH26019](#sih26019) | National Digital Platform for Research, Policy Innovation, and Evidence-Based Land Governance | Software | Ministry of Rural Development | Blockchain & Cybersecurity | [View Details &rarr;](#sih26019) |
| 20 | [SIH26020](#sih26020) | Design and Development of Innovative Hand-Spinning Equipment for Enhancing Khadi Artisan Productivity and Income | Hardware | Ministry of MSME | Blockchain & Cybersecurity | [View Details &rarr;](#sih26020) |
| 21 | [SIH26021](#sih26021) | Honey Chain: A block chain-based system for honey traceability and smart beekeeping management. | Software | Ministry of MSME | Smart Automation | [View Details &rarr;](#sih26021) |
| 22 | [SIH26022](#sih26022) | Design and develop a smart, solar-powered drying and compact packaging system to support home-based agarbatti manufacturing by rural women artisans. | Hardware | Ministry of MSME | Agriculture, FoodTech & Rural Development | [View Details &rarr;](#sih26022) |
| 23 | [SIH26023](#sih26023) | AI-Powered Geological, Mining and other Reporting Solution for CMPDI/CIL subsidiaries | Software | Ministry of Coal | Miscellaneous | [View Details &rarr;](#sih26023) |
| 24 | [SIH26024](#sih26024) | AI-Based Smart Governance and Compliance Monitoring System for Coal Mines | Software | Ministry of Coal | Smart Automation | [View Details &rarr;](#sih26024) |
| 25 | [SIH26025](#sih26025) | Development of an AI-enabled Low Cost Real Time Mine Subsidence Monitoring, Prediction and Early Warning System for Underground Coal Mines in India | Hardware | Ministry of Coal | Disaster Management | [View Details &rarr;](#sih26025) |
| 26 | [SIH26026](#sih26026) | Development of Mobile (Quadruped)/Handheld Device/System for Real-Time Detection of Narcotics and Explosives across Indian Railways. | Hardware | Ministry of Railways | Robotics and Drones | [View Details &rarr;](#sih26026) |
| 27 | [SIH26027](#sih26027) | Al-Powered Automatic Block Planning to Maximize Asset Availability for Train Operations on Indian Railways | Software | Ministry of Railways | Transportation & Logistics | [View Details &rarr;](#sih26027) |
| 28 | [SIH26028](#sih26028) | Dynamic Forecast of Expected Time of Arrival (ETA) for Coaching Trains | Software | Ministry of Railways | Disaster Management | [View Details &rarr;](#sih26028) |
| 29 | [SIH26029](#sih26029) | Automated High-Current Short-Circuit Test System for IEC 60898-1:2015 MCB Compliance. | Hardware | Ministry of Consumer Affairs, Food & Public Distribution | Disaster Management | [View Details &rarr;](#sih26029) |
| 30 | [SIH26030](#sih26030) | Automated Cable Specimen Preparation System for IS 10810 and IS 7098 Compliance. | Hardware | Ministry of Consumer Affairs, Food & Public Distribution | Smart Automation | [View Details &rarr;](#sih26030) |
| 31 | [SIH26031](#sih26031) | Quality assessment and grading of onions are often subjective and vary across procurement centers, resulting in disputes and inconsistencies. | Software | Ministry of Consumer Affairs, Food & Public Distribution | Fitness & Sports | [View Details &rarr;](#sih26031) |
| 32 | [SIH26032](#sih26032) | Farmers often face long waiting times, lack of information regarding procurement schedules, and uncertainty about procurement status. | Software | Ministry of Consumer Affairs, Food & Public Distribution | Heritage & Culture | [View Details &rarr;](#sih26032) |
| 33 | [SIH26033](#sih26033) | Multiple intermediaries reduce farmers earnings and increase consumer prices. | Software | Ministry of Consumer Affairs, Food & Public Distribution | MedTech / BioTech / HealthTech | [View Details &rarr;](#sih26033) |
| 34 | [SIH26034](#sih26034) | Software System to check compliance of Packaged Commodities under Legal Metrology(Packaged Commodities) Rules, 2011 by scanning products, images and labels. | Software | Ministry of Consumer Affairs, Food & Public Distribution | Agriculture, FoodTech & Rural Development | [View Details &rarr;](#sih26034) |
| 35 | [SIH26035](#sih26035) | Development of a Software Program/Application for Generation of Test Reports for Non-Automatic Weighing Instruments (NAWI) as per OIML Recommendation R- 76 | Software | Ministry of Consumer Affairs, Food & Public Distribution | Smart Vehicles | [View Details &rarr;](#sih26035) |
| 36 | [SIH26036](#sih26036) | Development of an Online Verification System for Weighing and Measuring Instruments | Software | Ministry of Consumer Affairs, Food & Public Distribution | Transportation & Logistics | [View Details &rarr;](#sih26036) |
| 37 | [SIH26037](#sih26037) | Adaptive Path Planning and Collision Avoidance for Autonomous Vehicles on Unstructured Indian Roads | Software | MathWorks | Robotics and Drones | [View Details &rarr;](#sih26037) |
| 38 | [SIH26038](#sih26038) | Explainable AI for Diabetic Retinopathy Screening in Rural India | Software | MathWorks | Clean & Green Technology | [View Details &rarr;](#sih26038) |
| 39 | [SIH26039](#sih26039) | Al-Powered Underground Mine Safety, Monitoring and Rescue System. | Hardware | Governmcnt of Jharkhand | Travel & Tourism | [View Details &rarr;](#sih26039) |
| 40 | [SIH26040](#sih26040) | Smart Water Purification and Quality Monitoring System for Rural and Mining-Affected Areas. | Hardware | Governmcnt of Jharkhand | Renewable / Sustainable Energy | [View Details &rarr;](#sih26040) |
| 41 | [SIH26041](#sih26041) | AR-Based Vocational Training Simulator for Industrial Safety in Jharkhand's Mining & Manufacturing Sector | Software | Governmcnt of Jharkhand | Blockchain & Cybersecurity | [View Details &rarr;](#sih26041) |
| 42 | [SIH26042](#sih26042) | Al-Powered Vernacular Pedagogy and Real-Time Translation Tool for Mother Tongue-Based Primary Education | Software | Governmcnt of Jharkhand | Smart Education | [View Details &rarr;](#sih26042) |
| 43 | [SIH26043](#sih26043) | A digital platform to crowdsource societal challenges and facilitate collaborative problem solving through universities and industry partnerships | Software | Governmcnt of Jharkhand | Disaster Management | [View Details &rarr;](#sih26043) |
| 44 | [SIH26044](#sih26044) | Portal for Academia - Industry collaboration for Skill Mapping, Internships and Placement | Software | Ministry of Ayush | Miscellaneous | [View Details &rarr;](#sih26044) |
| 45 | [SIH26045](#sih26045) | IP-SAKTI Sahayak a multilingual, RAG-based (source-cited) AI assistant for Intellectual Property and regulatory guidance in Ayurveda, across national and international regimes. | Software | Ministry of Ayush | Toys & Games | [View Details &rarr;](#sih26045) |
| 46 | [SIH26046](#sih26046) | AIIA Clinical Trials Dashboard - a real-time, cloud-based, GCP-compliant Clinical Trial Management System (CTMS) for Ayurveda research, with CDISC/FHIR-interoperable data, role-based KPIs, and integrated ethics, regulatory (CTRI / NDCT Rules 2019) and pharmacovigilance tracking. | Software | Ministry of Ayush | Space Technology | [View Details &rarr;](#sih26046) |
| 47 | [SIH26047](#sih26047) | Patient Case-Taking Software | Software | Ministry of Ayush | Smart Automation | [View Details &rarr;](#sih26047) |
| 48 | [SIH26048](#sih26048) | iKwath - a pod-based smart Kwatha (Kadha) maker that prepares a fresh, AFI/API-standardized decoction from coarse powder (yavaku?a c?r?a) on demand, in the shortest practical time without altering the decoctions quality or yield | Hardware | Ministry of Ayush | Fitness & Sports | [View Details &rarr;](#sih26048) |
| 49 | [SIH26049](#sih26049) | Modifications to improve the reliability, efficiency,and lifespan of electrical and electronic equipment and systems in the ambient condition of subzero temperature and low pressure of High Altitude Areas(HAA) and Super High Altitude Areas (SHAA) of Ladakh region. | Hardware | DRDO | Heritage & Culture | [View Details &rarr;](#sih26049) |
| 50 | [SIH26050](#sih26050) | High Altitude Performance Optimization and Robust Design of Anti-Drone System. | Hardware | DRDO | MedTech / BioTech / HealthTech | [View Details &rarr;](#sih26050) |
| 51 | [SIH26051](#sih26051) | Software Based Model Development for Design of Area Specific Shelter for Thermal Comfort Maintenance. | Software | DRDO | Agriculture, FoodTech & Rural Development | [View Details &rarr;](#sih26051) |
| 52 | [SIH26052](#sih26052) | To develop an AI/ML-enabled adaptive noise cancellation (ANC) system that effectively suppresses stationary, non-stationary, and impulsive defence noises while maintaining high speech intelligibility and real-time performance on embedded hardware. | Hardware | DRDO | Smart Vehicles | [View Details &rarr;](#sih26052) |
| 53 | [SIH26053](#sih26053) | Adaptive Variable Resolution 2.5D Lidar Mapping for Dynamic Environment Perception | Software | DRDO | Transportation & Logistics | [View Details &rarr;](#sih26053) |
| 54 | [SIH26054](#sih26054) | AI-Enabled Real-Time Digital Twin System for Health Monitoring, Fault Prediction and Mission Reliability Enhancement of Aero Piston Engines used in MALE UAVs. | Software | DRDO | Robotics and Drones | [View Details &rarr;](#sih26054) |
| 55 | [SIH26055](#sih26055) | Smart Scan strategy for Electronic Warfare | Software | DRDO | Clean & Green Technology | [View Details &rarr;](#sih26055) |
| 56 | [SIH26056](#sih26056) | Development of a Real-time Airfare Price Index for India through Automated Web Scraping of Airline and Online Travel Aggregator Portals for Augmentation of the Consumer Price Index (CPI). | Software | MoSPI | Travel & Tourism | [View Details &rarr;](#sih26056) |
| 57 | [SIH26057](#sih26057) | AI-Powered Automated Underwater Marine Debris and Anomaly Detection System using Side-Scan Sonar Imagery | Software | Ministry of Earth Sciences (MoES) | Renewable / Sustainable Energy | [View Details &rarr;](#sih26057) |
| 58 | [SIH26058](#sih26058) | Development of a Low-Power, Real-Time Adaptive Software-Defined Sonar Transmitter Payload for Autonomous Underwater Vehicles (AUVs) | Hardware | Ministry of Earth Sciences (MoES) | Blockchain & Cybersecurity | [View Details &rarr;](#sih26058) |
| 59 | [SIH26059](#sih26059) | AI-Enabled Antarctic Sea-Ice, Iceberg Trajectory, and Navigation Decision Support System | Software | Ministry of Earth Sciences (MoES) | Smart Education | [View Details &rarr;](#sih26059) |
| 60 | [SIH26060](#sih26060) | Digital Platform for efficient remote management of Indian Antarctic Research Stations | Software | Ministry of Earth Sciences (MoES) | Disaster Management | [View Details &rarr;](#sih26060) |
| 61 | [SIH26061](#sih26061) | AI-Driven Smart Energy Management System for Polar Research Stations | Software | Ministry of Earth Sciences (MoES) | Miscellaneous | [View Details &rarr;](#sih26061) |
| 62 | [SIH26062](#sih26062) | Integrated Polar Expedition Logistics and Asset Management System | Software | Ministry of Earth Sciences (MoES) | Toys & Games | [View Details &rarr;](#sih26062) |
| 63 | [SIH26063](#sih26063) | Integrated Polar Science Outreach, Knowledge Repository and Media Dissemination Portal | Software | Ministry of Earth Sciences (MoES) | Space Technology | [View Details &rarr;](#sih26063) |
| 64 | [SIH26064](#sih26064) | Low-Cost Deployable Seafloor Metal Detection Sensor for Ocean Resource Exploration | Hardware | Ministry of Earth Sciences (MoES) | Smart Resource Conservation | [View Details &rarr;](#sih26064) |
| 65 | [SIH26065](#sih26065) | Autonomous Low-Cost Ocean Observation Platform for Polar and Southern Oceans | Hardware | Ministry of Earth Sciences (MoES) | Smart Automation | [View Details &rarr;](#sih26065) |
| 66 | [SIH26066](#sih26066) | OceanEmbed - Satellite Embedding-Based Deep Learning Framework for Reconstruction of Subsurface Ocean Temperature from Surface Satellite Observations. | Software | Ministry of Earth Sciences (MoES) | Space Technology | [View Details &rarr;](#sih26066) |
| 67 | [SIH26067](#sih26067) | Develop a web-based interactive 3D visualization platform that integrates numerical ocean model outputs and in-situ observations. | Software | Ministry of Earth Sciences (MoES) | Smart Automation | [View Details &rarr;](#sih26067) |
| 68 | [SIH26068](#sih26068) | WeatherGPT: Conversational AI for Weather Forecasting, Alerts, and Climate Information | Software | Ministry of Earth Sciences (MoES) | Disaster Management | [View Details &rarr;](#sih26068) |
| 69 | [SIH26069](#sih26069) | National Weather Big Data Analytics Platform | Software | Ministry of Earth Sciences (MoES) | Disaster Management | [View Details &rarr;](#sih26069) |
| 70 | [SIH26070](#sih26070) | To develop an Artificial Intelligence (AI) / Machine Learning (ML) based system for identification, classification, and prediction of different tropical cyclone patterns using multi-source satellite data. | Software | Ministry of Earth Sciences (MoES) | Smart Education | [View Details &rarr;](#sih26070) |
| 71 | [SIH26071](#sih26071) | AI/ML-Based Integrated heavy rainfall Early Warning and Inundation Prediction System using Satellite, Radar, observational Weather and numerical weather prediction model data. | Software | Ministry of Earth Sciences (MoES) | Disaster Management | [View Details &rarr;](#sih26071) |
| 72 | [SIH26072](#sih26072) | AIML based Nowcasting of thunderstorm and lightning using atmospheric observation including multiple radars, satellite, lightning and model data. | Software | Ministry of Earth Sciences (MoES) | Disaster Management | [View Details &rarr;](#sih26072) |
| 73 | [SIH26073](#sih26073) | AI/ML-Based Intelligent Anomaly Detection for Automatic Weather Stations (AWS) | Software | Ministry of Earth Sciences (MoES) | Disaster Management | [View Details &rarr;](#sih26073) |
| 74 | [SIH26074](#sih26074) | Downscaling of weather forecast from Block level to Panchayat level: Inferring high-resolution plots/ data/ information from low-resolution plot /data /information /variables for agro-meteorological advisory services. | Software | Ministry of Earth Sciences (MoES) | Disaster Management | [View Details &rarr;](#sih26074) |
| 75 | [SIH26075](#sih26075) | Participants are invited to design and develop **CAPACITY CONNECT A Digital Capacity Building and Learning Management Portal** to support organizational training, competency development, and knowledge sharing through a centralized web-based platform. | Software | Ministry of Earth Sciences (MoES) | Smart Education | [View Details &rarr;](#sih26075) |
| 76 | [SIH26076](#sih26076) | Development of personalized homepage for 'Mausam' mobile application: | Software | Ministry of Earth Sciences (MoES) | Miscellaneous | [View Details &rarr;](#sih26076) |
| 77 | [SIH26077](#sih26077) | AI-Driven Hyper-Local Early Warning System for Severe Weather Nowcasting | Software | Ministry of Earth Sciences (MoES) | Disaster Management | [View Details &rarr;](#sih26077) |
| 78 | [SIH26078](#sih26078) | AI-Driven Spatio-Temporal Tracking of Extreme Weather Anomalies in Medium-Range Forecasts | Software | Ministry of Earth Sciences (MoES) | Disaster Management | [View Details &rarr;](#sih26078) |
| 79 | [SIH26079](#sih26079) | AI-Based Forecast Bust Detection for Medium-Range Weather Forecasts | Software | Ministry of Earth Sciences (MoES) | Disaster Management | [View Details &rarr;](#sih26079) |
| 80 | [SIH26080](#sih26080) | Regime-Aware AI Post-Processing of Monsoon Rainfall Forecasts | Software | Ministry of Earth Sciences (MoES) | Disaster Management | [View Details &rarr;](#sih26080) |
| 81 | [SIH26081](#sih26081) | Hybrid AINWP Multi-Model Forecast Blending System | Software | Ministry of Earth Sciences (MoES) | Miscellaneous | [View Details &rarr;](#sih26081) |
| 82 | [SIH26082](#sih26082) | Air PollutionWeather Coupled Forecasting System (Delhi NCR Focus) | Software | Ministry of Earth Sciences (MoES) | Disaster Management | [View Details &rarr;](#sih26082) |
| 83 | [SIH26083](#sih26083) | Extreme Heatwave Early Warning and Human Thermal Stress Index | Software | Ministry of Earth Sciences (MoES) | Disaster Management | [View Details &rarr;](#sih26083) |
| 84 | [SIH26084](#sih26084) | Convective scale nowcasting for Thunderstorms, Hail & Cloudbursts (06 hr) | Software | Ministry of Earth Sciences (MoES) | Disaster Management | [View Details &rarr;](#sih26084) |
| 85 | [SIH26085](#sih26085) | Urban Flood Nowcasting System (Drainage and Rainfall Coupling) | Software | Ministry of Earth Sciences (MoES) | Disaster Management | [View Details &rarr;](#sih26085) |
| 86 | [SIH26086](#sih26086) | Hyperlocal Monsoon Onset & Break Prediction System (Block/Village Scale) | Software | Ministry of Earth Sciences (MoES) | Miscellaneous | [View Details &rarr;](#sih26086) |
| 87 | [SIH26087](#sih26087) | AI-Enabled Cooperative Capacity Building, ERP & Employment Ecosystem | Hardware | Ministry of Cooperation | Smart Education | [View Details &rarr;](#sih26087) |
| 88 | [SIH26088](#sih26088) | Multilingual Cooperative Governance & Legal Assistance Chatbot | Hardware | Ministry of Cooperation | Smart Automation | [View Details &rarr;](#sih26088) |
| 89 | [SIH26089](#sih26089) | Cooperative Gig Services Platform for Household & Community Services | Software | Ministry of Cooperation | Smart Automation | [View Details &rarr;](#sih26089) |
| 90 | [SIH26090](#sih26090) | AI-Driven Market Linkage and Smart Cataloging Mobile Application for Marginalized Artisans | Software | Ministry of Social Justice and Empowerment (MoSJE) | Miscellaneous | [View Details &rarr;](#sih26090) |
| 91 | [SIH26091](#sih26091) | AI-Driven Hyper-Local Business Advisory and Financial Structuring Assistant for Rural Micro-Entrepreneurs | Software | Ministry of Social Justice and Empowerment (MoSJE) | Miscellaneous | [View Details &rarr;](#sih26091) |
| 92 | [SIH26092](#sih26092) | AI-Driven Scheme Matching for Marginalized Entrepreneurs | Software | Ministry of Social Justice and Empowerment (MoSJE) | Miscellaneous | [View Details &rarr;](#sih26092) |
| 93 | [SIH26093](#sih26093) | AI-Based Real-Time Stress and Trauma Assessment Module for Victims/Complainants Accessing NHAA (14566) and Integrated Portal | Software | Ministry of Social Justice and Empowerment (MoSJE) | Smart Automation | [View Details &rarr;](#sih26093) |
| 94 | [SIH26094](#sih26094) | AI-Powered Dynamic Mental Health Monitoring and Distress Prediction System for Victims of Atrocities | Software | Ministry of Social Justice and Empowerment (MoSJE) | MedTech / BioTech / HealthTech | [View Details &rarr;](#sih26094) |
| 95 | [SIH26095](#sih26095) | Smart Real-Time Monitoring & Inspection Mobile App | Software | Ministry of Social Justice and Empowerment (MoSJE) | Miscellaneous | [View Details &rarr;](#sih26095) |
| 96 | [SIH26096](#sih26096) | Digital Heritage Archive for Memorials, Manuscripts & Ambedkar: AI-Powered Institutional Archive and Audio-Visual Knowledge Platform | Hardware | Ministry of Social Justice and Empowerment (MoSJE) | Heritage & Culture | [View Details &rarr;](#sih26096) |
| 97 | [SIH26097](#sih26097) | AI-Driven voice Assistant for livelihood Mapping and NSQF-Aligned Skilling Recommendations for SC Communities under GIA component of PM-AJAY | Software | Ministry of Social Justice and Empowerment (MoSJE) | Smart Education | [View Details &rarr;](#sih26097) |
| 98 | [SIH26098](#sih26098) | Development of a Low-Cost Precision Guidance and Smart Electronic Fuze System for a 155 mm Artillery Shell | Hardware | Ministry of Defence (MoD) | Miscellaneous | [View Details &rarr;](#sih26098) |
| 99 | [SIH26099](#sih26099) | AI-Driven Standardization and Harmonization of Material Codes Across CPSEs | Software | Ministry of Petroleum & Natural Gas | Smart Automation | [View Details &rarr;](#sih26099) |
| 100 | [SIH26100](#sih26100) | AI-Powered Integrated Bid Compliance Verification Platform for GeM Procurement | Software | Ministry of Petroleum & Natural Gas | Smart Automation | [View Details &rarr;](#sih26100) |
| 101 | [SIH26101](#sih26101) | Develop an AI enabled learning platform that identifies competency gaps, recommends personalized training through integration with the iGOT Karmayogi ecosystem, and capable of generating Quizzes and Multiple choice questions (MCQs) from uploaded learning materials to strengthen capacity building in India's Official Statistical System. | Software | MoSPI | Smart Education | [View Details &rarr;](#sih26101) |
| 102 | [SIH26102](#sih26102) | Development of an AI-powered system to detect anomalies, fraud, and inefficiencies in MPLAD Scheme implementation regd. | Software | MoSPI | Miscellaneous | [View Details &rarr;](#sih26102) |
| 103 | [SIH26103](#sih26103) | Use case on web-based integrated project-monitoring platform | Software | MoSPI | Smart Automation | [View Details &rarr;](#sih26103) |
| 104 | [SIH26104](#sih26104) | AI-Powered Real-Time Detection and Prevention of Voice Cloning Impersonation Attacks | Software | All India Council for Technical Education (AICTE) | Miscellaneous | [View Details &rarr;](#sih26104) |
| 105 | [SIH26105](#sih26105) | AI-Powered Continuous Cyber Risk Quantification and Investment Optimization Platform | Software | All India Council for Technical Education (AICTE) | Blockchain & Cybersecurity | [View Details &rarr;](#sih26105) |
| 106 | [SIH26106](#sih26106) | AI-Powered Email Threat Detection, GeoLocation and Forensic Intelligence Platform | Software | All India Council for Technical Education (AICTE) | Blockchain & Cybersecurity | [View Details &rarr;](#sih26106) |
| 107 | [SIH26107](#sih26107) | Al-powered Intelligent Assistant for Indian Standards and BIS Services for Industries and Consumers | Software | Ministry of Consumer Affairs, Food & Public Distribution | Smart Automation | [View Details &rarr;](#sih26107) |
| 108 | [SIH26108](#sih26108) | AI-Powered Recommendation Engine for Identifying Applicable Indian Standards for Procurement Specifications | Software | Ministry of Consumer Affairs, Food & Public Distribution | Smart Automation | [View Details &rarr;](#sih26108) |
| 109 | [SIH26109](#sih26109) | Al-Based Predictive Modelling for Early Forecasting of Bovine Mastitis in lndian Dairy Farms | Hardware | Ministry of Fisheries, Animal Husbandry & Dairying | Agriculture, FoodTech & Rural Development | [View Details &rarr;](#sih26109) |
| 110 | [SIH26110](#sih26110) | Development of a Low-Cost Light-weight Milk Chilling Can for Small-Scale Dairy Farmers | Hardware | Ministry of Fisheries, Animal Husbandry & Dairying | Agriculture, FoodTech & Rural Development | [View Details &rarr;](#sih26110) |
| 111 | [SIH26111](#sih26111) | Smart Al-Enabled Rapid Feed and Silage Quality Testing System for Dairy Farmers | Software | Ministry of Fisheries, Animal Husbandry & Dairying | Agriculture, FoodTech & Rural Development | [View Details &rarr;](#sih26111) |
| 112 | [SIH26112](#sih26112) | Design and Develop a Modular Autonomous Mobile Robot (AMR) Platform for Smart Warehouse Automation | Hardware | Autodesk | Robotics and Drones | [View Details &rarr;](#sih26112) |
| 113 | [SIH26113](#sih26113) | Human augmentation technologies are transforming healthcare,rehabilitation, industrial ergonomics, assistive living, sports, and personal mobility by improving human capabilities and enhancing quality of life. | Hardware | Autodesk | MedTech / BioTech / HealthTech | [View Details &rarr;](#sih26113) |
| 114 | [SIH26114](#sih26114) | Smart City Site Planning using Autodesk Forma Site Design | Software | Autodesk | Smart Automation | [View Details &rarr;](#sih26114) |
| 115 | [SIH26115](#sih26115) | Design and Develop a Smart Mobile Medical-Waste Collection and Segregation System | Software | Autodesk | MedTech / BioTech / HealthTech | [View Details &rarr;](#sih26115) |
| 116 | [SIH26116](#sih26116) | Urban Mixed-Use Design Challenge-Design a centrally located mixed-use building in Autodesk Revit with commercial spaces (Ground + 1st floor) and residential units (up to 8 floors). 1 Level of Basement (Car Parking + EV Charging), Total (B+G+9)(Note: Plot size and all required dimensions may be assumed by students (in mm units). | Software | Autodesk | Smart Education | [View Details &rarr;](#sih26116) |
| 117 | [SIH26117](#sih26117) | Sovereign On-Premise Agentic AI Workbench using Open-Weight Multimodal LLMs for Confidential Industrial Work | Software | Mangalore Refinery and Petrochemicals Limited (MRPL) | Smart Automation | [View Details &rarr;](#sih26117) |
| 118 | [SIH26118](#sih26118) | Passive Colorimetric H2S Exposure-Dosimeter Wristband with AI-Based Quantitative Reading | Hardware | Mangalore Refinery and Petrochemicals Limited (MRPL) | Miscellaneous | [View Details &rarr;](#sih26118) |
| 119 | [SIH26119](#sih26119) | Indigenous GPU-Accelerated Optimization Solver (Sovereign Alternative to Express / CEPLEX) | Software | Mangalore Refinery and Petrochemicals Limited (MRPL) | Miscellaneous | [View Details &rarr;](#sih26119) |
| 120 | [SIH26120](#sih26120) | Digital Twin for Well-to-Surface Optimization of Cyclic Steam Stimulation (CSS) and Sucker Rod Pump (SRP) Operations for Heavy Oil Wells of Baghewala Field. | Software | Oil India Limited | Smart Automation | [View Details &rarr;](#sih26120) |
| 121 | [SIH26121](#sih26121) | eRTMAC-NWIS (Nearby Wells Intelligence System): An AI-Powered Offset Well Knowledge and Decision Support Platform for Drilling Operations | Software | Oil India Limited | Smart Automation | [View Details &rarr;](#sih26121) |
| 122 | [SIH26122](#sih26122) | Intelligent Data Capture & Schedule-Linking Layer for Infrastructure Project Management: Real-Time Actual Progress Tracking (Planning-to-Execution Bridge) | Software | Oil India Limited | Smart Automation | [View Details &rarr;](#sih26122) |
| 123 | [SIH26123](#sih26123) | Edge-AI Based Distributed Fleet Coordination for Autonomous Mobile Robots (AMRs) in Smart Warehouses | Software | Bharat Electronics Limited | Robotics and Drones | [View Details &rarr;](#sih26123) |
| 124 | [SIH26124](#sih26124) | AI-Powered Mobile Urban Intelligence Platform Using Public Transport Fleet | Software | Bharat Electronics Limited | Fitness & Sports | [View Details &rarr;](#sih26124) |
| 125 | [SIH26125](#sih26125) | Blockchain-Based Secure Platform for Identity,Access Control, and Digital Asset Management | Software | Bharat Electronics Limited | Blockchain & Cybersecurity | [View Details &rarr;](#sih26125) |
| 126 | [SIH26126](#sih26126) | Vision Based Autonomous Navigation for Unmanned Ground Vehicle for Outdoor environment | Software | Bharat Electronics Limited | Robotics and Drones | [View Details &rarr;](#sih26126) |
| 127 | [SIH26127](#sih26127) | City-Wide AI Engine for Multi-Camera ANPR Trajectory Tracking and Urban Traffic Analytics | Software | Bharat Electronics Limited | Transportation & Logistics | [View Details &rarr;](#sih26127) |
| 128 | [SIH26128](#sih26128) | Efficient systems for early detection,prevention,and management of livestock diseases and animal health issues | Software | Government Of Maharashtra | Agriculture, FoodTech & Rural Development | [View Details &rarr;](#sih26128) |
| 129 | [SIH26129](#sih26129) | System integration and interoperability among government digital platforms,resulting in fragmented service delivery | Software | Government Of Maharashtra | Smart Automation | [View Details &rarr;](#sih26129) |
| 130 | [SIH26130](#sih26130) | Efficiency in streamlining industrial approvals,compliance processes,and access to government support services | Software | Government Of Maharashtra | Smart Automation | [View Details &rarr;](#sih26130) |
| 131 | [SIH26131](#sih26131) | Early detection and management of crop diseases and pest infestations | Software | Government Of Maharashtra | Agriculture, FoodTech & Rural Development | [View Details &rarr;](#sih26131) |
| 132 | [SIH26132](#sih26132) | Strengthening market linkages and price discovery for farmers | Software | Government Of Maharashtra | Agriculture, FoodTech & Rural Development | [View Details &rarr;](#sih26132) |
| 133 | [SIH26133](#sih26133) | Accessibility and quality of public healthcare services,particularly in rural and underserved areas | Software | Government Of Maharashtra | MedTech / BioTech / HealthTech | [View Details &rarr;](#sih26133) |
| 134 | [SIH26134](#sih26134) | Challenges in aligning skill development programs with industry requirements and emerging job market demands | Software | Government Of Maharashtra | Miscellaneous | [View Details &rarr;](#sih26134) |
| 135 | [SIH26135](#sih26135) | Difficulties in tracking employment outcomes,skill gaps, and the impact of skilling initiatives | Software | Government Of Maharashtra | Smart Education | [View Details &rarr;](#sih26135) |
| 136 | [SIH26136](#sih26136) | Startup friendly public procurement mechanism that enables government departments to identify,pilot, procure,and scale innovative solutions from eligible startups | Software | Government Of Maharashtra | Smart Automation | [View Details &rarr;](#sih26136) |
| 137 | [SIH26137](#sih26137) | Quantum-Inspired Intelligent Traffic Route Optimization in Transportation Systems Using Metaheuristic Optimization | Software | Egreen Quanta | Fitness & Sports | [View Details &rarr;](#sih26137) |
| 138 | [SIH26138](#sih26138) | Quantum-Inspired Fuel Consumption Prediction and Green Fleet Optimization | Software | Egreen Quanta | Smart Vehicles | [View Details &rarr;](#sih26138) |
| 139 | [SIH26139](#sih26139) | Hybrid Quantum Machine Learning Platform for Early Disease Detection | Software | Egreen Quanta | MedTech / BioTech / HealthTech | [View Details &rarr;](#sih26139) |
| 140 | [SIH26140](#sih26140) | AI-Based Interactive Quantum Algorithm Learning Platform | Software | Egreen Quanta | Smart Education | [View Details &rarr;](#sih26140) |
| 141 | [SIH26141](#sih26141) | Quantum-Inspired Cyber Threat Detection for Digital Signature Security | Software | Egreen Quanta | Blockchain & Cybersecurity | [View Details &rarr;](#sih26141) |
| 142 | [SIH26142](#sih26142) | Deep Learning Based Super Resolution Mapping (SRM) from Medium Resolution Satellite Imageries | Software | National Technical Research Organisation (NTRO) | Smart Education | [View Details &rarr;](#sih26142) |
| 143 | [SIH26143](#sih26143) | Leveraging satellite imagery to determine Oil spills at sea along with AIS data correlations to identify vessel responsible for the spill. | Software | National Technical Research Organisation (NTRO) | Space Technology | [View Details &rarr;](#sih26143) |
| 144 | [SIH26144](#sih26144) | Design & Development of a High-Sensitivity Micro barometer Infrasound sensor | Hardware | National Technical Research Organisation (NTRO) | Miscellaneous | [View Details &rarr;](#sih26144) |
| 145 | [SIH26145](#sih26145) | AI-Based Detection of Cyber Threats in Unidirectional IP Traffic | Software | National Technical Research Organisation (NTRO) | Blockchain & Cybersecurity | [View Details &rarr;](#sih26145) |
| 146 | [SIH26146](#sih26146) | AI-Powered Monitoring & Analysis of Bitcoin Transaction Traffic | Software | National Technical Research Organisation (NTRO) | Transportation & Logistics | [View Details &rarr;](#sih26146) |
| 147 | [SIH26147](#sih26147) | Automated model for analysis of .IQ and .wav files along with signal parameter extraction | Software | National Technical Research Organisation (NTRO) | Miscellaneous | [View Details &rarr;](#sih26147) |
| 148 | [SIH26148](#sih26148) | Creation of scripts/functions with new programming language to commence Computer & Network forensic analysis without triggering security solutions | Software | National Technical Research Organisation (NTRO) | Blockchain & Cybersecurity | [View Details &rarr;](#sih26148) |
| 149 | [SIH26149](#sih26149) | Design and Development of an Integrated Secure Data Erasure and Advanced File Recovery Tool for Digital Forensics and Data Sanitization | Software | National Technical Research Organisation (NTRO) | Blockchain & Cybersecurity | [View Details &rarr;](#sih26149) |
| 150 | [SIH26150](#sih26150) | Development of a Multi-Vendor DVR/NVR Forensic Analysis Tool for Standardized Acquisition, Recovery, and Analysis of Surveillance Evidence. | Software | National Technical Research Organisation (NTRO) | Blockchain & Cybersecurity | [View Details &rarr;](#sih26150) |
| 151 | [SIH26151](#sih26151) | Dark web threat actor de-anonymization | Software | National Technical Research Organisation (NTRO) | Blockchain & Cybersecurity | [View Details &rarr;](#sih26151) |
| 152 | [SIH26152](#sih26152) | Social Media Analytics | Software | National Technical Research Organisation (NTRO) | Miscellaneous | [View Details &rarr;](#sih26152) |
| 153 | [SIH26153](#sih26153) | AI based Network Attack Forecasting from Network Traffic Data | Software | National Technical Research Organisation (NTRO) | Blockchain & Cybersecurity | [View Details &rarr;](#sih26153) |
| 154 | [SIH26154](#sih26154) | Gen AI Platform for Automated Content Transformation | Software | National Technical Research Organisation (NTRO) | Smart Automation | [View Details &rarr;](#sih26154) |
| 155 | [SIH26155](#sih26155) | AI-Driven Multi-Vendor Network Security Compliance Auditor | Software | National Technical Research Organisation (NTRO) | Blockchain & Cybersecurity | [View Details &rarr;](#sih26155) |
| 156 | [SIH26156](#sih26156) | Universal Log Pre-processing Framework | Software | National Technical Research Organisation (NTRO) | Miscellaneous | [View Details &rarr;](#sih26156) |
| 157 | [SIH26157](#sih26157) | Supervisory Analytics Tool for SOC Assessment (SAT-SA) | Software | National Technical Research Organisation (NTRO) | Miscellaneous | [View Details &rarr;](#sih26157) |
| 158 | [SIH26158](#sih26158) | Single-Pass Drone Video to Accurate 3D Model Generation System | Software | National Technical Research Organisation (NTRO) | Robotics and Drones | [View Details &rarr;](#sih26158) |
| 159 | [SIH26159](#sih26159) | SecureMailScope: AI-Assisted Cryptographic Security Posture Assessment for Secure Email Communications | Software | National Technical Research Organisation (NTRO) | Blockchain & Cybersecurity | [View Details &rarr;](#sih26159) |
| 160 | [SIH26160](#sih26160) | AI-Powered IPsec VPN Protocol Analyzer and Security Assessment Framework | Software | National Technical Research Organisation (NTRO) | Blockchain & Cybersecurity | [View Details &rarr;](#sih26160) |
| 161 | [SIH26161](#sih26161) | Dam Break Inundation Modelling Using Hydrodynamic Modelling of any River | Software | National Technical Research Organisation (NTRO) | Disaster Management | [View Details &rarr;](#sih26161) |
| 162 | [SIH26162](#sih26162) | AI-Based Detection and Classification of Industrial Fires and Persistent Thermal Sources Using NASA FIRMS, OSM & Satellite Data | Software | National Technical Research Organisation (NTRO) | Miscellaneous | [View Details &rarr;](#sih26162) |
| 163 | [SIH26163](#sih26163) | Security Assessment of the World Monitor application | Software | National Technical Research Organisation (NTRO) | Miscellaneous | [View Details &rarr;](#sih26163) |
| 164 | [SIH26164](#sih26164) | Enterprise Cryptographic Discovery & Analysis Tool (ECDAT) | Software | National Technical Research Organisation (NTRO) | Blockchain & Cybersecurity | [View Details &rarr;](#sih26164) |
| 165 | [SIH26165](#sih26165) | AI/NLP Engine to Detect Serious Injury & Fatality (SIF) Precursors in OIL's Unsafe-Act/Unsafe-Condition and Near-Miss Reports | Software | Oil India Limited | Miscellaneous | [View Details &rarr;](#sih26165) |
| 166 | [SIH26166](#sih26166) | Multi-modal, Sun angle and scale invariant image correspondence using Chandrayaan-2 optical images (OHRC, TMC and IIRS) | Software | Indian Space Research Organisation(ISRO) | Space Technology | [View Details &rarr;](#sih26166) |
| 167 | [SIH26167](#sih26167) | SatQuery AI - An Interactive Vision-Language Assistant for Multimodal Remote Sensing Image Analysis through Text Queries | Software | Indian Space Research Organisation(ISRO) | Space Technology | [View Details &rarr;](#sih26167) |
| 168 | [SIH26168](#sih26168) | AI-ML based Intelligent Dead Reckoning system for seamless navigation | Software | Indian Space Research Organisation(ISRO) | Miscellaneous | [View Details &rarr;](#sih26168) |
| 169 | [SIH26169](#sih26169) | Development of an AI-Based Virtual Camera Tracking System for Coarse Alignment of Mobile Free Space Optical Communication (FSOC) Terminals | Software | Indian Space Research Organisation(ISRO) | Miscellaneous | [View Details &rarr;](#sih26169) |
| 170 | [SIH26170](#sih26170) | AI-Driven Anomaly Detection in Component Burn-In & Screening | Software | Indian Space Research Organisation(ISRO) | Smart Automation | [View Details &rarr;](#sih26170) |
| 171 | [SIH26171](#sih26171) | On-device Visual Perception for Light-weight Browser Agents | Software | Indian Space Research Organisation(ISRO) | Miscellaneous | [View Details &rarr;](#sih26171) |
| 172 | [SIH26172](#sih26172) | Low Latency and Efficient Voice Activator for Edge Devices | Hardware | Indian Space Research Organisation(ISRO) | Miscellaneous | [View Details &rarr;](#sih26172) |
| 173 | [SIH26173](#sih26173) | iTantra -Indian Multilingual TTS & STT Aided Neural Transceiver Radio Access for low bitrate links | Software | Indian Space Research Organisation(ISRO) | Miscellaneous | [View Details &rarr;](#sih26173) |
| 174 | [SIH26174](#sih26174) | AI Human Activity Recognition for On-board BAS Experiments | Software | Indian Space Research Organisation(ISRO) | Miscellaneous | [View Details &rarr;](#sih26174) |
| 175 | [SIH26175](#sih26175) | DepthWizard - Single-View Height Estimation and 3D Flythrough | Software | Indian Space Research Organisation(ISRO) | Miscellaneous | [View Details &rarr;](#sih26175) |
| 176 | [SIH26176](#sih26176) | ORCA Marine EcOsystem Reasoning with Collaborative Agents | Software | Indian Space Research Organisation(ISRO) | Miscellaneous | [View Details &rarr;](#sih26176) |
| 177 | [SIH26177](#sih26177) | A deployable AI-powered autonomous drone that aids search-and-rescue operations by detecting people and hazards, thereby improving responder safety and reducing victim discovery time. | Hardware | Qualcomm Inc | Robotics and Drones | [View Details &rarr;](#sih26177) |
| 178 | [SIH26178](#sih26178) | A resilient, AI-powered environmental monitoring network that provides early detection, localized intelligence, and actionable alerts for floods, forest fires, pollution events, and other environmental hazards common in India, enabling authorities and communities to shift from reactive disaster response to proactive risk prevention. | Hardware | Qualcomm Inc | Disaster Management | [View Details &rarr;](#sih26178) |
| 179 | [SIH26179](#sih26179) | To build an AI-powered retail intelligence platform that delivers real-time shopper analytics, automated inventory visibility, and proactive queue management through on-device AI,enabling retailers to reduce stock-outs, improve customer experience, optimize staffing, and increase operational efficiency while maintaining privacy and minimizing cloud dependency. | Hardware | Qualcomm Inc | Smart Automation | [View Details &rarr;](#sih26179) |
| 180 | [SIH26180](#sih26180) | A field-deployable AI-powered Smart Farming Assistant that helps farmers detect crop diseases, pests, nutrient deficiencies, and irrigation needs at an early stage, while improving resilience against droughts, floods, heat waves, and other agricultural risks common in India. The solution should enable higher yields, lower input costs, more efficient water usage, and faster response to emerging threats through real-time on-device intelligence. | Hardware | Qualcomm Inc | Disaster Management | [View Details &rarr;](#sih26180) |
| 181 | [SIH26181](#sih26181) | A secure, AI-powered Personal Health Companion that delivers real-time, privacy-preserving health monitoring and early warning capabilities, helping individuals recognize health risks before they become emergencies. The solution should improve resilience during heat waves, floods, pollution events, and other disasters common in India while enabling continuous health support through on-device intelligence. | Hardware | Qualcomm Inc | MedTech / BioTech / HealthTech | [View Details &rarr;](#sih26181) |
| 182 | [SIH26182](#sih26182) | Automated Attribution of Unknown Cryptocurrency Wallets to Nearest Virtual Asset Service Providers (VASPs) through Blockchain Intelligence APIs | Software | Ministry of Home Affairs | Blockchain & Cybersecurity | [View Details &rarr;](#sih26182) |
| 183 | [SIH26183](#sih26183) | Real-Time Identification of Fraud-Linked Cryptocurrency Exchanges from Victim-Reported Suspect Wallet Addresses through Automated Blockchain Analytics | Software | Ministry of Home Affairs | Blockchain & Cybersecurity | [View Details &rarr;](#sih26183) |
| 184 | [SIH26184](#sih26184) | Development of a Predictive Analytics Framework for Cybercrime Complaints to Forecast Likely Cash Withdrawal Locations in Advance, Enabling Generation of Actionable Intelligence for Timely and Proactive Cybercrime Intervention. | Software | Ministry of Home Affairs | Blockchain & Cybersecurity | [View Details &rarr;](#sih26184) |
| 185 | [SIH26185](#sih26185) | Helmet mounted conformal antenna for tactical communications in urban CQB environments. | Hardware | Ministry of Home Affairs | Miscellaneous | [View Details &rarr;](#sih26185) |
| 186 | [SIH26186](#sih26186) | AI-Based Predictive Personnel Stress and Welfare Monitoring System for Uniformed Forces | Software | Ministry of Home Affairs | MedTech / BioTech / HealthTech | [View Details &rarr;](#sih26186) |
| 187 | [SIH26187](#sih26187) | AI-Based Intelligent Video Analytics Platform for Border Surveillance using existing CCTV Infrastructure. | Software | Ministry of Home Affairs | Smart Automation | [View Details &rarr;](#sih26187) |
| 188 | [SIH26188](#sih26188) | Al-Based Fake Identity & Document Screening System | Software | Ministry of Home Affairs | Miscellaneous | [View Details &rarr;](#sih26188) |
| 189 | [SIH26189](#sih26189) | AI-Powered Criminal Network Analysis System | Software | Ministry of Home Affairs | Blockchain & Cybersecurity | [View Details &rarr;](#sih26189) |
| 190 | [SIH26190](#sih26190) | Secure Digital Document Management System for Legal and Investigation Documents | Software | Ministry of Home Affairs | Miscellaneous | [View Details &rarr;](#sih26190) |
| 191 | [SIH26191](#sih26191) | Intelligent Identification of Hazard-Based Red Zones, Carrying Capacity Assessment, and Immediate Relocation Needs for Vulnerable Habitations | Software | Ministry of Home Affairs | Disaster Management | [View Details &rarr;](#sih26191) |
| 192 | [SIH26192](#sih26192) | Flash Flood Prediction System for Hilly Regions using Multi-Source Data Theme | Software | Ministry of Home Affairs | Disaster Management | [View Details &rarr;](#sih26192) |
| 193 | [SIH26193](#sih26193) | Student Innovation | Software | AICTE | Smart Resource Conservation | [View Details &rarr;](#sih26193) |
| 194 | [SIH26194](#sih26194) | Student Innovation | Software | AICTE | Fitness & Sports | [View Details &rarr;](#sih26194) |
| 195 | [SIH26195](#sih26195) | Student Innovation | Software | AICTE | Heritage & Culture | [View Details &rarr;](#sih26195) |
| 196 | [SIH26196](#sih26196) | Student Innovation | Software | AICTE | MedTech / BioTech / HealthTech | [View Details &rarr;](#sih26196) |
| 197 | [SIH26197](#sih26197) | Student Innovation | Software | AICTE | Agriculture, FoodTech & Rural Development | [View Details &rarr;](#sih26197) |
| 198 | [SIH26198](#sih26198) | Student Innovation | Software | AICTE | Transportation & Logistics | [View Details &rarr;](#sih26198) |
| 199 | [SIH26199](#sih26199) | Student Innovation | Software | AICTE | Fitness & Sports | [View Details &rarr;](#sih26199) |
| 200 | [SIH26200](#sih26200) | Student Innovation | Software | AICTE | MedTech / BioTech / HealthTech | [View Details &rarr;](#sih26200) |
| 201 | [SIH26201](#sih26201) | Student Innovation | Software | AICTE | Smart Resource Conservation | [View Details &rarr;](#sih26201) |
| 202 | [SIH26202](#sih26202) | Student Innovation | Software | AICTE | Travel & Tourism | [View Details &rarr;](#sih26202) |
| 203 | [SIH26203](#sih26203) | Student Innovation | Software | AICTE | Renewable / Sustainable Energy | [View Details &rarr;](#sih26203) |
| 204 | [SIH26204](#sih26204) | Student Innovation | Software | AICTE | Miscellaneous | [View Details &rarr;](#sih26204) |
| 205 | [SIH26205](#sih26205) | Student Innovation | Software | AICTE | Smart Education | [View Details &rarr;](#sih26205) |
| 206 | [SIH26206](#sih26206) | Student Innovation | Software | AICTE | Disaster Management | [View Details &rarr;](#sih26206) |
| 207 | [SIH26207](#sih26207) | Student Innovation | Software | AICTE | Travel & Tourism | [View Details &rarr;](#sih26207) |
| 208 | [SIH26208](#sih26208) | Student Innovation | Software | AICTE | Heritage & Culture | [View Details &rarr;](#sih26208) |
| 209 | [SIH26209](#sih26209) | Student Innovation | Software | AICTE | Space Technology | [View Details &rarr;](#sih26209) |
| 210 | [SIH26210](#sih26210) | Student Innovation | Hardware | AICTE | Smart Resource Conservation | [View Details &rarr;](#sih26210) |
| 211 | [SIH26211](#sih26211) | Student Innovation | Hardware | AICTE | Fitness & Sports | [View Details &rarr;](#sih26211) |
| 212 | [SIH26212](#sih26212) | Student Innovation | Hardware | AICTE | Heritage & Culture | [View Details &rarr;](#sih26212) |
| 213 | [SIH26213](#sih26213) | Student Innovation | Hardware | AICTE | MedTech / BioTech / HealthTech | [View Details &rarr;](#sih26213) |
| 214 | [SIH26214](#sih26214) | Student Innovation | Hardware | AICTE | Agriculture, FoodTech & Rural Development | [View Details &rarr;](#sih26214) |
| 215 | [SIH26215](#sih26215) | Student Innovation | Hardware | AICTE | Transportation & Logistics | [View Details &rarr;](#sih26215) |
| 216 | [SIH26216](#sih26216) | Student Innovation | Hardware | AICTE | Fitness & Sports | [View Details &rarr;](#sih26216) |
| 217 | [SIH26217](#sih26217) | Student Innovation | Hardware | AICTE | MedTech / BioTech / HealthTech | [View Details &rarr;](#sih26217) |
| 218 | [SIH26218](#sih26218) | Student Innovation | Hardware | AICTE | Smart Resource Conservation | [View Details &rarr;](#sih26218) |
| 219 | [SIH26219](#sih26219) | Student Innovation | Hardware | AICTE | Travel & Tourism | [View Details &rarr;](#sih26219) |
| 220 | [SIH26220](#sih26220) | Student Innovation | Hardware | AICTE | Renewable / Sustainable Energy | [View Details &rarr;](#sih26220) |
| 221 | [SIH26221](#sih26221) | Student Innovation | Hardware | AICTE | Miscellaneous | [View Details &rarr;](#sih26221) |
| 222 | [SIH26222](#sih26222) | Student Innovation | Hardware | AICTE | Smart Education | [View Details &rarr;](#sih26222) |
| 223 | [SIH26223](#sih26223) | Student Innovation | Hardware | AICTE | Disaster Management | [View Details &rarr;](#sih26223) |
| 224 | [SIH26224](#sih26224) | Student Innovation | Hardware | AICTE | Travel & Tourism | [View Details &rarr;](#sih26224) |
| 225 | [SIH26225](#sih26225) | Student Innovation | Hardware | AICTE | Heritage & Culture | [View Details &rarr;](#sih26225) |
| 226 | [SIH26226](#sih26226) | Student Innovation | Hardware | AICTE | Space Technology | [View Details &rarr;](#sih26226) |

---

## Detailed Problem Statements

### <a id="sih26001"></a>[1] SIH26001: AI-Based early warning and landslide Risk Monitoring System in NER

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26001` (SIH26001) |
| **Problem Statement Title** | AI-Based early warning and landslide Risk Monitoring System in NER |
| **Organization** | Ministry of Development of North Eastern Region (MDoNER) |
| **Department** | Ministry of Development of North Eastern Region (MDoNER) |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

The North Eastern Region (NER) frequently faces landslides, flash floods, road blockages, and slope failures due to heavy rainfall, fragile terrain, and unplanned hill cutting. These incidents often disrupt connectivity, damage infrastructure, delay emergency response, and isolate remote villages for days. Currently, monitoring of vulnerable zones is mostly reactive and dependent on manual reporting. There is limited use of real-time predictive systems for identifying high-risk zones and issuing early warnings to authorities and local communities. With increasing climate vulnerability in the region, there is a need for an AI-enabled real-time monitoring and prediction system that can help authorities take preventive action before disasters occur.

**Description:**

This problem statement proposes the development of an Al-powered early warning and monitoring platform capable of predicting and tracking landslide-prone areas in real time across the North Eastern Region. The solution should:

a. Collect and analyse data from: Rainfall patterns Soil moisture sensors Satellite imagery Terrain/slope data Historical landslide records b. Use AI/ML models to identify high-risk zones and predict possible landslide events.

c. Provide real-time alerts to district administrations, disaster management authorities, and local communities.

d. Integrate GIS mapping for visualization of vulnerable roads, villages, and infrastructure.

e. Allow citizens/field officials to upload geo-tagged photos/videos of cracks, slope movement or blocked roads.

**f. Generate dashboards showing:**

- Risk severity levels

- Road connectivity status

- Weather-linked risk forecasts

- Emergency response prioritisation. Support multilingual notifications and low-network/offline functionality for remote areas.

**Expected Solution:**

**A scalable Al-based software platform with:**

- Real-time GIS dashboard and risk heatmaps

- AI/ML-based predictive analytics engine

- Mobile/web application for field reporting and alerts.

- Integration with IMD weather APIs, satellite feeds, and sensor data

- Automated SMS/app-based early warning system

- Cloud-based architecture with offline sync support for remote regions The solution should improve disaster preparedness, reduce loss of life and infrastructure damage, and strengthen climate-resilient governance in the North Eastern Region.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26002"></a>[2] SIH26002: Al-Based Smart Logistics and Accessibility Intelligence Platform for North Eastern Region (NER)

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26002` (SIH26002) |
| **Problem Statement Title** | Al-Based Smart Logistics and Accessibility Intelligence Platform for North Eastern Region (NER) |
| **Organization** | Ministry of Development of North Eastern Region (MDoNER) |
| **Department** | Ministry of Development of North Eastern Region (MDoNER) |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

The North Eastern Region (NER) faces major logistics and accessibility challenges due to difficult terrain, extreme weather conditions, limited transport connectivity, and frequent road disruptions caused by landslides, floods, and infrastructure gaps. Transportation of essential goods such as medicines, food supplies, construction materials, and agricultural produce to remote districts often gets delayed, leading to supply shortages, increased costs, and disruption in public service delivery. Currently, there is no integrated intelligent platform that can provide real-time logistics visibility, route accessibility status, predictive disruption alerts, and optimized transportation planning for the region. To strengthen regional connectivity and support infrastructure-led development initiatives, there is a need for an Al-enabled logistics intelligence system tailored for the unique geographical and operational challenges of NER.

**Description:**

This problem statement seeks the development of an Al-powered Smart and in Logistics Accessibility Intelligence Platform for the North Eastern Region (NER) to address challenges related to difficult terrain, weather-induced disruptions, and limited transport connectivity remote areas. The platform should use Artificial Intelligence (Al), Machine Learning (ML), GIS mapping, weather data, and real-time field inputs to monitor transportation networks and improve movement of essential goods and services across the region. The platform should:

a. Monitoring real-time road, bridge, and transport accessibility across districts and remote locations b. Predicting possible route disruptions caused by landslides, floods, heavy rainfall, road damage, or traffic congestion c. Providing Al-based alternate route suggestions and estimated travel delays d. Tracking movement of vehicles carrying essential commodities, medicines, agricultural produce, and construction materials through GPS integration e. Generating automated alerts for blocked roads, inaccessible regions, delayed deliveries, and high-risk transport corridors f. Enabling field officials and local authorities to upload geo-tagged updates, photographs, and incident reports from remote locations g. Creating centralized dashboards for visualizing:

- District-wise connectivity status

- Logistics bottlenecks and supply chain gaps Emergency and disaster-time accessibility routes

- Real-time movement and delivery status of essential supplies h. Supporting multilingual notifications and offline data synchronization for low-network areas The platform should help improve regional connectivity, strengthen emergency response systems, reduce supply chain disruptions, and support efficient planning and monitoring of logistics operations in the North Eastern Region.

**Expected Solution:**

- A scalable Al-based software platform integrated with GIS and real-time analytics featuring:

- Al-powered route prediction and optimization engine

- GIS-enabled accessibility monitoring dashboard

- GPS-based vehicle tracking system

- Real-time alert and notification mechanism

- Mobile/web application for field-level reporting and monitoring Integration capability with weather APIs, transport databases, and government monitoring systems

- Cloud-based infrastructure with secure data management and offline support The platform should improve regional logistics efficiency, reduce supply disruptions, strengthen emergency response capability, and support infrastructure and economic development across the North Eastern Region.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26003"></a>[3] SIH26003: AI-Based Cognitive Gaming and Memory Assistance Platform for Elderly Dementia Patients in North Eastern Region (NER)

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26003` (SIH26003) |
| **Problem Statement Title** | AI-Based Cognitive Gaming and Memory Assistance Platform for Elderly Dementia Patients in North Eastern Region (NER) |
| **Organization** | Ministry of Development of North Eastern Region (MDoNER) |
| **Department** | Ministry of Development of North Eastern Region (MDoNER) |
| **Category** | Software |
| **Theme** | Space Technology |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

The North Eastern Region (NER) is witnessing a gradual rise in age-related cognitive disorders such as dementia and memory loss among the elderly population. Many families in remote and rural areas face challenges in accessing specialized neurological care, cognitive therapy, and long-term elderly support services due to limited healthcare infrastructure and geographical barriers.

Elderly patients suffering from dementia often experience memory decline, confusion, anxiety, and social isolation, while caregivers face difficulties in continuous monitoring and engagement. There is limited availability of affordable and culturally inclusive digital therapeutic solutions tailored for elderly individuals in the North-Eastern Region.

To strengthen elderly healthcare and improve cognitive well-being, there is a need for an accessible, engaging, and Al-enabled cognitive gaming solution designed specifically for dementia patients in NER.

**Description:**

This problem statement seeks the development of an AI-powered cognitive gaming and memory assistance platform for elderly dementia patients in the North Eastern Region.**The solution should:****a. Include interactive cognitive games and activities focused on:**

- Memory improvement

- Attention and concentration 0 Daily routine recall

- Pattern and object recognition of emotional and mental engagement b. Use AI/ML algorithms to adapt difficulty levels based on patient performance and cognitive condition c. Support multilingual and voice-assisted interaction suitable for elderly users in NER Include culturally familiar themes, visuals, sounds, and regional language support for d. better engagement e. Provide reminders for:

- Medicines

- Hydration

- Daily activities

- Medical appointments.

f. Enable caregivers and healthcare workers to monitor patient progress through dashboards and activity levels g. Work in low-connectivity environments with offline functionality support h. Be accessible through mobile/tablet devices with a simple and elderly-friendly interface The platform should encourage long-term cognitive engagement, emotional well-being, and social interaction among elderly users.

**Expected Solution: A user-friendly Al-enabled cognitive assistance platform with:**

- Adaptive gaming and memory training modules

- Voice-enabled multilingual interface

- Cognitive performance tracking and analytics dashboard

- Caregiver monitoring and alert system

- Offline synchronization support for remote areas

- Secure patient data management system

- Simple and accessible UI/UX designed for elderly users The solution should support early cognitive intervention, improve quality of life for elderly dementia patients, and strengthen digital healthcare accessibility across the North Eastern Region.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26004"></a>[4] SIH26004: Al-Assisted Early Detection System for Osteoarthritis (OA) Risk Markers in North Eastern Region (NER)

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26004` (SIH26004) |
| **Problem Statement Title** | Al-Assisted Early Detection System for Osteoarthritis (OA) Risk Markers in North Eastern Region (NER) |
| **Organization** | Ministry of Development of North Eastern Region (MDoNER) |
| **Department** | Ministry of Development of North Eastern Region (MDoNER) |
| **Category** | Hardware |
| **Theme** | Space Technology |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Osteoarthritis (OA) is one of the most common musculoskeletal disorders affecting elderly individuals and physically active populations, leading to chronic pain, joint stiffness, mobility issues, and reduced quality of life.

In the North Eastern Region (NER), difficult terrain, physically demanding livelihoods, aging population, and limited access to specialized orthopaedic care further increase the burden of undiagnosed and untreated osteoarthritis cases. Early identification of OA risk markers is critical for timely intervention and preventive healthcare management.

However, healthcare facilities in many remote and rural areas of NER lack affordable screening tools, specialist support, and diagnostic infrastructure for early-stage detection of osteoarthritis. There is a need for a technology-driven solution that can assist healthcare workers in identifying early OA indicators and supporting preventive screening in low-resource settings across the North Eastern Region.

**Description:**

This problem statement seeks to develop an AI-assisted screening and detection system for identifying early risk markers and symptoms associated with Osteoarthritis (OA) in the North Eastern Region. The solution should:

a. Assist in early detection of OA-related risk markers through

- Joint movement analysis

- Gait and posture assessment

- Pain and mobility screening inputs

- Medical imaging or sensor-based assessment (if applicable)

b. Use AI/ML techniques to analyse patient data and identify high-risk cases for early intervention c. Support screening in primary healthcare centres, rural health camps, and community outreach programs d. Provide preliminary OA risk assessment and severity indication e. Enable healthcare workers to digitally record patient symptoms and screening reports f. Include multilingual and easy-to-use interfaces suitable for rural healthcare settings in NER g. Work in low-connectivity environments with offline data collection capability h. Provide awareness and preventive guidance related to joint care, physical activity, nutrition, and lifestyle management The solution should be portable, affordable, and suitable for deployment in remote and underserved areas.

**Expected Solution:**

**A scalable Al-enabled healthcare screening solution with:**

- Al-based OA risk analysis and screening module

- Portable assessment interface or sensor-assisted screening mechanism

- Digital patient record and report generation system

- Mobile/web-based healthcare worker interface

- Offline synchronization capability for remote areas

- Multilingual support and simplified workflow for field deployment

- Secure patient data management and analytics dashboard The solution should support early diagnosis, preventive healthcare intervention, and improved accessibility to musculoskeletal healthcare services in the North Eastern Region.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26005"></a>[5] SIH26005: Solar-Powered Smart Mini Cold Storage System for Fresh Vegetables in North Eastern Region (NER)

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26005` (SIH26005) |
| **Problem Statement Title** | Solar-Powered Smart Mini Cold Storage System for Fresh Vegetables in North Eastern Region (NER) |
| **Organization** | Ministry of Development of North Eastern Region (MDoNER) |
| **Department** | Ministry of Development of North Eastern Region (MDoNER) |
| **Category** | Hardware |
| **Theme** | Smart Vehicles |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

The North Eastern Region (NER) produces a substantial quantity of fresh vegetables and horticultural crops. However, due to inadequate cold storage infrastructure, unreliable electricity supply, difficult terrain, and transportation delays, farmers often face heavy post-harvest losses. Most remote farming areas lack access to affordable small-scale cold storage facilities near production clusters and local markets. As a result, fresh vegetables deteriorate rapidly before reaching consumers, reducing farmer income and affecting supply chain efficiency. There is a need for a low-cost, energy-efficient, and decentralized cold storage solution suitable for rural and remote regions of NER.

**Description:**

This problem statement seeks the development of a Solar-Powered Smart Mini Cold Storage System for farmers and vegetable producers in the North Eastern Region (NER) to reduce postharvest losses of perishable vegetables. Due to poor cold-chain infrastructure, difficult transportation routes, frequent power cuts, and long travel durations from remote villages to markets, fresh vegetables often spoil within a short time after harvest. Farmers are forced to sell produce at low prices or suffer financial losses due to lack of nearby storage facilities. The proposed system should function as a decentralized mini cold storage unit that can be installed at village-level collection centres, local markets, farmer cooperatives, and farm-gate aggregation points.**The system should:**

a. Preserve fresh vegetables such as tomatoes, cabbage, beans, leafy vegetables, chilli, and other horticultural produce under suitable storage conditions b. Operate using solar energy with battery backup support for off-grid and low-electricity areas c. Maintain controlled temperature and humidity levels for extending shelf life of vegetables d. Include smart monitoring features for:

- Temperature fluctuation

- Humidity variation

- Power failure alerts

- Storage condition status e. Be compact, modular, and suitable for deployment in remote hilly terrain and rural agricultural clusters f. Be energy-efficient, weather-resistant, and capable of operating under varying climatic conditions of NER g. Support easy operation and low maintenance for farmer groups, cooperatives, and local vendors h. Help reduce spoilage during temporary storage before transportation to larger markets The solution should strengthen local agricultural supply chains, reduce vegetable wastage, improve market accessibility, and enhance income opportunities for farmers in the North Eastern Region.

**Expected Solution:**

A functional hardware-based smart mini cold storage system suitable for rural and remote agricultural areas of the North Eastern Region. The proposed solution should include:

a. Solar-powered cooling system with energy-efficient operation b. Insulated cold storage chamber for preserving fresh vegetables and horticultural produce c. Battery backup support for uninterrupted operation during power outages or low sunlight conditions d. Temperature and humidity monitoring mechanism for maintaining suitable storage conditions e. Smart alert/indicator system for:

- Temperature fluctuations

- Power failure

- Unsafe storage conditions f. Compact and modular design suitable for village-level deployment and difficult terrain g. Weather-resistant and durable structure for varying climatic conditions in NER h. Low-maintenance and cost-effective system suitable for farmer cooperatives, local markets, and collection centres i. Basic digital monitoring/display interface for storage status and system performance The solution should help reduce post-harvest vegetable spoilage, improve shelf life of produce, strengthen local cold-chain infrastructure, and enhance income opportunities for farmers in the North Eastern Region.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26006"></a>[6] SIH26006: Development of an Intelligent Freight Forecasting Model for Optimized Vessel Chartering and Bulk Cargo Procurement from overseas to East Coast of India

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26006` (SIH26006) |
| **Problem Statement Title** | Development of an Intelligent Freight Forecasting Model for Optimized Vessel Chartering and Bulk Cargo Procurement from overseas to East Coast of India |
| **Organization** | Ministry of Steel |
| **Department** | SAIL |
| **Category** | Software |
| **Theme** | Transportation & Logistics |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

The current approach to vessel chartering for bulk cargo procurement to India's East Coast ports often involves daily market exploration, leading to reactive decision-making and likely missed opportunities for cost savings and efficiency. The highly volatile nature of global freight markets, coupled with varying supply and demand dynamics from key origins like Australia, the US, Mozambique, Russia and Indonesia, makes it challenging to identify optimal entry points for short-term or mid-term charter contracts. Furthermore, without a robust future forecasting mechanism, determining the most suitable vessel type (e.g., Handysize, Supramax, Panamax,Capesize) for specific cargo parcels and routes, while accounting for port infrastructure limitations at both origin and destination, results in suboptimal utilization and increased idle time. This manual, market-dependent approach requires analytics to mitigate risks associated with freight fluctuations and port-specific constraints, directly impacting overall logistics costs and supply chain reliability. Detailed Description:

The problem statement addresses the critical need for a sophisticated freight forecasting model to revolutionize vessel chartering and bulk cargo procurement for East Coast Indian ports. Currently, our operations are heavily reliant on daily engagements with the freight market. This traditional method leads to several inefficiencies: a lack of predictive insight into future freight rates, making it difficult to secure favorable short-term or mid-term charter contracts; an inability to proactively identify the optimal time to enter the market for specific vessel types and cargo sizes; and significant challenges in minimizing vessel idle time due to inadequate planning regarding port-specific infrastructure restrictions.

For instance, procuring bulk cargo (such as coal) from Australia, the US,Mozambique, and Indonesia presents unique logistical challenges. Each origin-destination pair has distinct sailing distances, trade lane dynamics, and, crucially,varying port capabilities. East Coast Indian ports, like Paradip, Vizag, Gangavaram,Gopalpur, Dhamra, Sagar- Sandheads and Haldia, each possess specific draft restrictions, berthing limitations, and cargo handling capacities that dictate the maximum permissible vessel size and turnaround time.The proposed system should therefore integrate multiple data points for comprehensive analysis. This includes historical freight rate data for various vessel sizes across relevant trade routes, global economic indicators, commodity price trends, seasonal variations in demand and supply, and real-time port congestion information for both origin and destination ports. Furthermore, it must incorporate detailed infrastructure constraints of Indian East Coast ports, such as maximum LOA (Length Overall), beam, draft, and cargo handling rates, along with similar data for the loading ports in Australia, the US, Mozambique, and Indonesia.

**Expected Solution:**

The expected solution is the development and implementation of an intelligent, datadriven Freight Forecasting Model. This model should leverage advanced analytical techniques, potentially including machine learning algorithms (e.g., time series forecasting, regression models) and artificial intelligence, to predict future freight rates with a high degree of accuracy for various vessel types and trade routes. The solution should offer actionable insights by providing recommendations on:

a. Optimal Market Entry Timing: Identify ideal windows to secure short-term or mid-term vessel charter contracts for specific cargo requirements, minimizing freight costs.

b. Vessel Type Optimization: Recommend the most suitable vessel type (e.g.,Handysize, Supramax, Panamax, Capesize) for a given cargo volume and origin-destination pair, considering all known port infrastructure limitations at both loading and discharge ports on India's East Coast. This includes factoring in draft restrictions, LOA, and cargo handling capabilities to prevent idle time and ensure efficient turnaround.

c. Idle Scenario Management: Propose strategies for minimizing vessel idle time by forecasting periods of low demand and suggesting alternative employment opportunities or optimized positioning to reduce deadheading.

d. Risk Mitigation: Provide early warnings for potential market volatility, port congestion, or other disruptions that could impact chartering decisions.

The model should be user-friendly, perhaps with a dashboard interface, allowing logistics managers to input cargo details, origin/destination ports, and desired contract duration to receive comprehensive freight forecasts and actionable recommendations.The ultimate goal is to move from a reactive, daily market approach to a proactive, predictive chartering strategy, leading to significant cost reductions, improved supply chain efficiency, and enhanced decision-making capabilities.

**Objective:**

Development of model to facilitate moving from multiple single spot contracts being entered into currently to short term / medium term multiple voyage contracts.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26007"></a>[7] SIH26007: Safe and Efficient Operation of Mine Vehicles in Fog and Low-Visibility Conditions in Open Cast Iron Ore Mines.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26007` (SIH26007) |
| **Problem Statement Title** | Safe and Efficient Operation of Mine Vehicles in Fog and Low-Visibility Conditions in Open Cast Iron Ore Mines. |
| **Organization** | Ministry of Steel |
| **Department** | NMDC |
| **Category** | Hardware |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

NMDC Limited is India's largest Iron Ore producer, currently producing approximately 53 Million Tonnes Per Annum (MTPA) from its three fully mechanized mining complexes, namely BIOM-Kirandul Complex, BIOM-Bacheli Complex in Chhattisgarh, and Donimalai Complex in Karnataka. The Bailadila Region alone contributes nearly 37 MTPA of Iron Ore production. In line with the National Steel Policy, NMDC has set a target of achieving 100 MT production capacity by 2030, with approximately 80 MT expected from the Bailadila Sector.

The Bailadila mining region experiences severe monsoon conditions from June to October, including heavy rainfall, strong winds, high humidity, dense clouds, and thick fog. During this period, visibility on mine haul roads, particularly in hilltop mining areas, often reduces to as low as 3–5 meters. These conditions significantly affect the safe and efficient movement of Heavy Earth Moving Machinery (HEMM), especially dumpers engaged in ore transportation.

**Problem Description:**

Dense fog and extremely low visibility during the monsoon season create major operational and safety challenges in the Bailadila iron ore mines. Poor visibility restricts dumper movement, forcing operators to reduce speed or temporarily halt operations to avoid accidents and unsafe conditions.This results in increased haul cycle times, reduced fleet productivity, lower ore evacuation, and production losses. The risk of vehicle collision, road accidents, and operational disruptions also increases substantially during such conditions. Existing visibility aids and operational controls have limited effectiveness in dense fog environments.There is a need for an intelligent, reliable, and technology-driven solution that can enable safe and efficient movement of mine vehicles under low-visibility conditions while ensuring continuity of operations and maintaining production levels. Expected Solution:

The proposed solution should improve operator situational awareness, assist in vehicle guidance and collision avoidance, and support real-time monitoring and decision-making for safe haul road operations during adverse weather conditions.

**The solution may leverage technologies such as:**

- AI/ML-based analytics

- Computer vision and thermal imaging

- LiDAR and radar-based sensing

- GPS/DGPS-based vehicle tracking

- Vehicle-to-Vehicle (V2V) and Vehicle-to-Infrastructure (V2I) communication

- Autonomous or driver-assistance systems

- IoT-enabled monitoring systems

- Centralized command and control platforms

- Digital Twin-based operational monitoring Expected Outcomes

- Improved safety of dumper operations during foggy conditions

- Reduction in collision risks and operational accidents

- Improved haulage efficiency and reduced cycle times

- Enhanced fleet utilization and continuity of mining operations during monsoon

- Reduction in production losses caused by low visibility

- Real-time monitoring and decision support for operators and control rooms

- Scalable and deployable solution for large-scale mechanized open cast mines

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26008"></a>[8] SIH26008: Belt Joint Rupture and Conveyor Belt Damages in Iron Ore Mining Industry: Intelligent Monitoring and Prediction of Conveyor Belt Joint Rupture and Damages in Iron Ore Mining Industry.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26008` (SIH26008) |
| **Problem Statement Title** | Belt Joint Rupture and Conveyor Belt Damages in Iron Ore Mining Industry: Intelligent Monitoring and Prediction of Conveyor Belt Joint Rupture and Damages in Iron Ore Mining Industry. |
| **Organization** | Ministry of Steel |
| **Department** | NMDC |
| **Category** | Hardware |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

In the iron ore mining industry, conveyor belt systems are the backbone of material transportation, enabling continuous movement of iron ore from mining faces to crushing, screening, stockyard, and dispatch areas. One of the major operational challenges is conveyor belt joint rupture and belt damage, as belt joints are highly vulnerable to failure due to excessive tension,misalignment, wear, overloading, and maintenance deficiencies. Unexpected belt failures can cause production downtime, safety risks, high maintenance costs, delays in ore transportation, and damage to associated equipment.Traditional maintenance practices are mostly reactive or schedule based, which often fail to detect early-stage degradation of conveyor belts and joints. As mining operations increasingly move toward Industry 4.0 and smart mining, there is a growing need for intelligent, real-time, predictive systems that can proactively identify belt health deterioration and prevent catastrophic failures. Detailed Description:

Conveyor belt joints in iron ore mines are continuously exposed to heavy loads, high tension, dust, moisture, and frequent start-stop operations. These harsh working conditions gradually damage the belt joints and conveyor belt through cracks, wear, edge damage, rubber weakening, and splice failure. If these issues are not detected early, they can lead to sudden belt rupture and major operational breakdowns.

Mostly inspections are done manually and only at fixed intervals, making it difficult to identify early signs of failure. In normal practices, maintenance is mostly reactive, meaning repairs are performed only after visible damage or breakdown occurs. This results in unexpected shutdowns, emergency repairs, and increased maintenance costs. The major impacts on mining operations are as below:

- Production- Loss of ore transportation capacity

- Maintenance- Increased repair and spare cost

- Safety- Risk of accidents during belt rupture

- Energy- Higher power consumption due to misalignment & friction

- Asset Life- Reduced conveyor and pulley lifespan

- Sustainability- Material spillage and wastage Therefore, belt joint rupture and conveyor belt damage remain major operational and financial challenges in iron ore mining industries. Conventional maintenance approaches are insufficient for ensuring high conveyor reliability in modern mining operations.

Expected Solution: To develop an Intelligent Conveyor Belt Health Monitoring and Predictive Maintenance System using digitalization, IoT, AI, and machine learning technologies to detect early signs of belt joint deterioration and damages.

**The proposed digitalized system architecture may include the following:**

1. IoT-Based Sensor Integration for real-time monitoring using vibration, temperature, belt tracking, acoustic, load, speed, and tension sensors.

2. AI-Based Vision Monitoring using smart cameras and thermal imaging systems to detect cracks, tears, overheating, misalignment, and abnormal belt conditions.

3. Drone and Camera-Based Inspection Systems.

4. Digital Twin of Conveyor System to simulate conveyor operations, monitor equipment health, and analyse behaviour in real time.

5. Integration with Existing SCADA, PLC, and other pre-existed Conveyor Monitoring Systems.

6. AI/ML-Based Predictive Analytics 7. Others The proposed solution aims to reduce unplanned downtime, improve safety, minimize maintenance costs, and enhance conveyor reliability and operational efficiency in iron ore mining industries.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26009"></a>[9] SIH26009: Using AI/ML and Space Technology to Identify Manganese Reserves and Overcome Production Shortfalls.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26009` (SIH26009) |
| **Problem Statement Title** | Using AI/ML and Space Technology to Identify Manganese Reserves and Overcome Production Shortfalls. |
| **Organization** | Ministry of Steel |
| **Department** | MOIL Ltd. |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background: MOIL Limited is the largest producer of Manganese Ore in India. To meet future demand, it is important to accurately identify available reserves and avoid production shortfalls. At present, reserve estimation and production planning are mainly based on manual surveys, drilling results, and production records. These methods are time-consuming and sometimes lead to a mismatch between expected and actual ore production. Detailed Description: The challenge is to develop an AI/ML-based solution that uses geological data,historical production, equipment performance, and satellite/space technology inputs (such as rainfall, soil moisture, vegetation index, and land temperature) to:

- Identify and map manganese reserves more accurately using surface and sub-surface indicators.

- Predict shortfalls in production by analysing constraints like equipment downtime, weather conditions, or blasting delays.

- Suggest corrective actions such as adjusting mine schedules, optimizing blasting, or re-deploying equipment to ensure continuous ore availability. Expected Solution: The expected solution is a user-friendly dashboard that shows predicted reserves, production trends, possible risks of shortfall, and recommended corrective steps.

This will help MOIL improve planning, reduce losses, and ensure steady ore supply to customers.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26010"></a>[10] SIH26010: Survey/Resurvey of Rural Agricultural Land in lndia

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26010` (SIH26010) |
| **Problem Statement Title** | Survey/Resurvey of Rural Agricultural Land in lndia |
| **Organization** | Ministry of Rural Development |
| **Department** | Dept of land resources (DoLR) |
| **Category** | Hardware |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background: Historically, land surveys in rural lndia were conducted using conventional chain and tape methods, many of which date back several decades or even the colonial period. Over time, multiple issues emerged such as Boundary changes due to inheritance and informal partition, Unrecorded land transactions, Encroachments and overlapping claims, Errors in cadastral maps, Mismatch between textual records and spatial maps, Absence of updated mutation records and inconsistent land classifications. These deficiencies have resulted in prolonged legal disputes, reduced agricultural productivity, and administrative inefficiencies. Land-related disputes reportedly account for a major share of civil litigation in lndia. Detailed Description: A comprehensive survey/resurvey program is necessary to establish accurate land ownership, Update cadastral maps, Reduce land disputes,Enable transparent land governance, Support precision agriculture, lmprove rural planning, Facilitate digital land administration and Ensure effective implementation of government schemes.Modern technologies such as Drone mapping, Differential GPS (DGPS), GIS platforms, Satellite imagery, CORS, Mobile-based field verification can significanfly improve accuracy, speed, and transparency in rural land management.

Expected Solution: Technology-Driven Land Survey and Resurvey be implemented using modern survey technologies for accurate mapping of agricultural land parcels such as Drone-based aerial surveys, Real-Time Kinematic (RTK) GPS and DGPS systems, GIS-enabled cadastral mapping and Geo-referenced parcel identification. Developing a unified digital land information system integrating Record of Rights(RoR), Mutation records, Registration databases, Survey maps, Ownership history,precise Geo-coordinates of land parcels. This integration should enable real-time updating and verification of land ownership.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26011"></a>[11] SIH26011: 3D ULPIN Generation and vertical Property Mapping SYstem

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26011` (SIH26011) |
| **Problem Statement Title** | 3D ULPIN Generation and vertical Property Mapping SYstem |
| **Organization** | Ministry of Rural Development |
| **Department** | Dept of land resources (DoLR) |
| **Category** | Software |
| **Theme** | Space Technology |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

With rapid urbanization and vertical growth of cities, conventional 2D land record Systems are becoming inadequate for managing modern urban properties.Existing land administration systems are primarily designed to identify surface-level land parcels and are unable to uniquely define ownership rights associated with multi- storey apartments, underground infrastructure, elevated transport corridors, parking spaces, air-rights, and subsurface utility networks.

**Description:**

The proposed solution Should develop an advanced 3D ULPIN(Unique Land Parcel ldentification Number) Generation and vertical Property Mapping system capable of creating unique spatial identities for:

. Surface land parcels . Multi-storey apartments . Underground infrastructure The system should integrate:

. Drone imagery . LiDAR/3D Point cloud data . GIS parcel layers . Building floor Plans . GNSS/CORS-based coordinates . Digital Elevation Models (DEM/DSM) The solution should also incorporate AI/ML capabilities for:

. Automated building extraction . Floor segmentation . Vertical Parcel delineation . lntelligent topology validation Expected Solution: The expected outcome is development of a scalable and interoperable 3D cadastral framework capable of:

. Generating standardized 3D ULPINs . Mapping vertical and underground ownership rights . Supporting volumetric cadastre systems . Enabling accurate urban property governance . Reducing ownership conflicts and ambiguities . lmproving infrastructure planning and utility management

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26012"></a>[12] SIH26012: AI-Based Automated Urban Parcel Mapping and Cadastral Feature Extraction System using Drone lmagery

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26012` (SIH26012) |
| **Problem Statement Title** | AI-Based Automated Urban Parcel Mapping and Cadastral Feature Extraction System using Drone lmagery |
| **Organization** | Ministry of Rural Development |
| **Department** | Dept of land resources (DoLR) |
| **Category** | Software |
| **Theme** | Robotics and Drones |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Accurate and up-to-date urban land records are essential for effective land governance, urban planning, taxation, infrastructure development, and delivery of citizen-centric services. At present, preparation of cadastral maps and delineation of urban parcel boundaries is largely dependent on manual interpretation of drone imagery and field-based Ground Truthing (GT) activities. The process is time- consuming, resource intensive, and requires extensive human intervention for extraction of parcel boundaries, building footprints, road networks, and other cadastral features.Further, dense urban settlements, irregular parcel geometries, encroachments,overlapping structures, narrow access roads, and mixed land-use patterns create significant challenges in preparation of accurate parcel maps. Manual digitization and validation of parcel boundaries often lead to delays in completion of cadastral surveys and generation of urban land records.With availability of high-resolution orthorectified lmagery (ORl), Digital surface Models (DSM), Digital Terrain Models (DTM), and drone datasets, there exists significant potential for leveraging Artificial lntelligence (Al), computer Vision, and GeoAl technologies for automated extraction of cadastral features and preparation of preliminary urban Parcel maps. Description:**The system should be capable of:**

. Automatic extraction of parcel boundaries . ldentification and delineation of building footprints . Detection of roads, pathways, and access corridors . Classification of land-use features in urban areas The proposed solution should utilize:

. High-resolution Drone lmagery . Orthorectified lmagery (ORl)

. DSM/DTM datasets . Existing GIS Parcel layers . Ground Truthing (GT) datasets . GNSS/CORS-enabled surveY data The platform should incorporate:

1. Al-based image segmentation models for parcel delineation.

2. Deep learning techniques for feature extraction and object detection.

3. Automated topology generation and parcel polygon creation.

4. Detection of overlapping or inconsistent parcel geometries.

5. Web-GlS visualization and editing interface.

**Expected Solution:**

The expected outcome is development of an Al-enabled automated cadastral mapping platform capable of significantly reducing manual efforts involved in urban parcel mapping and cadastral preparation.

The final solution should: . Automatically generate preliminary urban parcel maps . lmprove speed and efficiency of cadastral surveys . Reduce manual digitization efforts . Enhance accuracy of parcel boundary extraction . Support Ground Truthing and field verification activities The solution should include:

. Al/ML-based parcel extraction engine . GIS-ready cadastral outputs . Web-based visualization dashboard . Automated topology validation module

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26013"></a>[13] SIH26013: Automated lntegration and lntelligent Harmonization of Multi-source Geospatial Data for urban Land Record Management.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26013` (SIH26013) |
| **Problem Statement Title** | Automated lntegration and lntelligent Harmonization of Multi-source Geospatial Data for urban Land Record Management. |
| **Organization** | Ministry of Rural Development |
| **Department** | Dept of land resources (DoLR) |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background: Urban land administration and cadastral management involve integration of multiple spatial and non-spatial datasets generated from various departments,agencies,and survey mechanisms. Under modern land governance programmes such as the NAKSHA Programme, large volumes of geospatial data are being generated through drone surveys, Orthorectified lmagery (ORl), DSM/DTM datasets, Ground Truthing (GT),GNSS surveys,municipal records,utility databases, and revenue land records.

At present,harmonization and integration of these datasets largely depend on manual GIS workflows,which are time-consuming and prone to errors.With increasing availability of Al, GeoAl, and automated spatial processing technologies, there is significant scope for development of an intelligent system capable of automatically integrating and synchronizing multi-source geospatial datasets with feature-extracted cadastral data. Description:

The proposed solution should develop an Al-enabled geospatial integration platform capable of automatically integrating, harmonizing, validating, and synchronizing multiple land-related datasets with Al-generated feature extraction outputs.

**The system should support integration of:**

. Drone imagery . Orthorectified lmagery (ORl)

. DSM/DTM datasets . Existing cadastral maps . Revenue records . Municipal GIS layers . Utility network data . Ground Truthing (GT) datasets . GNSS/CORS survey data . Building footPrint datasets The solution should incorPorate:

. Al/ML-based spatial matching algorithms . Automated topology correction . lntelligent attribute mapping . Geo-referencing and coordinate transformation engine . Change detection mechanisms . Spatial conflict resolution framework . Confidence scoring for integrated outputs Expected Solution:

. The expected outcome is development of an intelligent geospatial integration framework capable of automatically harmonizing multi-source land-related datasets with Al-generated feature extraction outputs. .The final solution should:

. Reduce manual GIS integration efforts . lmprove accuracy and consistency of urban land records . Enable seamless inter-departmental spatial data exchange . Accelerate cadastral finalization processes . lmprove interoperability of urban land information systems . Support standardized digital land governance Suggested Technologies:

. Artificial lntelligence (Al)

. Machine Learning (ML)

. GeoAl . GIS & Web-GlS . Spatial Databases . ETL Automation . Computer Vision . Cloud Computing . Spatial Analytics . API lntegration Frameworks

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26014"></a>[14] SIH26014: An lntegrated GIS-based Digital Public lnfrastructure for Land Governance

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26014` (SIH26014) |
| **Problem Statement Title** | An lntegrated GIS-based Digital Public lnfrastructure for Land Governance |
| **Organization** | Ministry of Rural Development |
| **Department** | Dept of land resources (DoLR) |
| **Category** | Software |
| **Theme** | Robotics and Drones |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Land governance in lndia involves multiple institutions maintaining land-related information in fragmented and disconnected systems. Core datasets such as cadastral maps, Record of Rights (RoR), registration records, land use information, Master Plan, Building Permission, Restrictions, property taxation records, utility infrastructure, and other land-related databases are often managed Independently by different departments and agencies with limited interoperability. This results in duplication of effort, inconsistencies in records, delays in obtaining ownership information, lack of transparency in transactions, and inconvenience to citizens seeking land-related services.

The growing scale of urbanization, increasing land transactions, demand for efficient governance, and the need for transparent and citizen-centric public service delivery require a modern digital approach to land administration. With advances in GIS technologies, Digital Public lnfrastructure (DPl), cloud computing, interoperable APls, Al/ML analytics, and geospatial standards, there is an opportunity to transform land governance through a unified digital ecosystem.Land Stack is envisaged as an integrated GIS-based digital platform that brings together all land-related datasets, workflows, and services into a single interoperable framework. Built upon georeferenced cadastral maps and linked with record of rights(land ownership records), Land Stack can serve as foundational digital infrastructure for efficient land governance, informed decision making, improved service delivery.The proposed platform should support both rural and urban contexts and enable seamless coordination across departments, institutions, and citizen interfaces.

**Detailed Description:**

The Department of Land Resources has initiated the development and deployment of Land Stack in pilot locations of Chandigarh and Tamil Nadu, launched on 31 December 2025. Following successful implementation, the platform is proposed to be expanded across lndia by covering one city and one village in every State and Union Territory, and subsequently scaled to achieve nationwide coverage.One of the major challenges in lndia is that land is a State subject, resulting in significant diversity in land administration systems across states. Variations exist in land record formats, database structures, units of measurement, number and type of fields, language, terminology, and administrative workflows.

Therefore, the challenge is to conceptualize and develop a scalable prototype of Land Stack capable of integrating diverse land-related datasets, workflows, and services into a common interoperable State-level framework.

The proposed Land stack solution should organize information into three broad categories of spatial layers. The base layer should comprise georeferenced cadastral maps, parcel boundaries, and unique parcel identifiers such as ULPIN.

This foundational layer should provide the spatial framework upon which all governance and service-related datasets can be integrated.The essential layers should include core governance datasets linked to each parcel,such as Record of Rights (RoR), registration data, master plans, building permissions and approvals, encumbrance and mortgage records, land use and zoning information.These layers should collectively define ownership, rights,restrictions, liabilities, and permissible land use associated with each parcel.Beyond this, additional or use-case layers should extend the platform's governance and citizen service capabilities by integrating datasets such as utility infrastructure, property taxation records, valuation references, infrastructure networks,environmental or restriction zones, and other service linkages. Each land parcel should be uniquely identifiable and linked with multiple layers of governance and administrative information, with ULPIN serving as the suggested common identifier.The prototype should demonstrate integration of multiple land-related domains through parcel-level GlS visualization and data exploration tools. The system should support interoperability between departmental systems through open APls, standardized metadata structures, secure authentication mechanisms, role-based access controls, audit trails, and scalable digital architecture. Citizen-facing capabilities such as parcel search, ownership verification, transaction status tracking, service requests, and access to land-related information should also be incorporated.

Participants are encouraged to integrate innovative technologies including Artificial lntelligence (Al), Machine Learning (ML), satellite imagery-based change detection, predictive analytics, workflow automation, and decision-support dashboards to improve transparency, operational efficiency, and governance outcomes.The overall solution should be modular, scalable, configurable for different administrative contexts, and capable of serving as a replicable national framework for integrated digital land governance.

**Expected Solution:**

The expected outcome is a functional prototype demonstrating the concept of Land stack as an integrated Gls-based Digital Public lnfrastructure for land governance.The solution should provide a unified digital platform capable of integrating multiple land-related datasets around a parcel-centric spatial framework and enabling seamless interaction between governance institutions, land administration agencles, and citizens. The prototype should demonstrate GIS-based parcel visualization,integration of mock or sample land-related datasets, role-based administrative dashboards, citizen-facing service interfaces, and interoperable workflows between land records, registration, dispute, planning, and fiscal systems.

The proposed solution should showcase efficient parcel-level information access, real-time or simulated workflow integration, cross-departmental data interoperability, analytics-driven governance insights, and transparent citizen service delivery mechanisms.lnnovative solutions that leverage Al/ML, geospatial intelligence, predictive analytics,workflow automation, API-based integration, mobile accessibility, and secure cloud- native architecture will be preferred.

The final prototype should demonstrate how fragmented land governance systems can be transformed into a unified, scalable, transparent, and citizen-centric Land Stack platform capable of improving land administration, enabling citizens to take informed decisions, accelerating transactions, strengthening planning, and enabling data-driven governance.

Further, participants are expected to prepare a Standard Technical Document containing details of API standards, interoperability standards, data schemas, system architecture, GIS standards, security frameworks, UI/UX guidelines, color schemas, and deployment and scalability considerations.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26015"></a>[15] SIH26015: Application of Geospatial Techniques for visualization and analysis to interpret Geo-Coded lmages to enhance watershed Development Outcomes.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26015` (SIH26015) |
| **Problem Statement Title** | Application of Geospatial Techniques for visualization and analysis to interpret Geo-Coded lmages to enhance watershed Development Outcomes. |
| **Organization** | Ministry of Rural Development |
| **Department** | Dept of land resources (DoLR) |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Watershed development plays a vital role in sustainable management of land, water, and natural resources, particularly in rural and semi-arid regions of lndia. Effective watershed planning and monitoring require accurate spatial information on land use, drainage patterns, vegetation cover, soil moisture, water bodies, and changes occurring over time. Traditional monitoring approaches often rely on field surveys and manual reporting, which are time-consuming, resource-intensive, and limited in spatial coverage. ln recent years, advancements in Geographic lnformation systems (GlS), Remote Sensing (RS), and geospatial technologies have created new opportunities for scientific watershed assessment and evidence-based decision- making.Geo-coded images, integrated with satellite-based spatial datasets, provide location- specific visual information that can significantly improve watershed monitoring and interpretation. The availability of 30 m spatial resolution satellite data through the SRISHTI-DRISHTI platform offers a valuable opportunity to develop analytical frameworks for visualization, interpretation, and assessment of watershed characteristics. Through thematic mapping and spatial analysis, geo-coded images can support identification of land degradation, water conservation structures, vegetation changes, drainage conditions, and other watershed-related parameters.

The proposed study focuses on the application of geospatial techniques for visualization and analysis to interpret geo-coded images for enhancing watershed development outcomes. The study aims to develop a systematic and scalable approach for image-based watershed analysis using GIS and remote sensing tools.

By integrating geo-coded imagery with satellite datasets from the SRISHTI-DRISHTI platform, the research seeks to improve planning, monitoring, interpretation, and scientific assessment of watershed interventions in a focused and cost-effective manner.

**Description of the Study:**

Despite significant investments in watershed development programs, effective monitoring and interpretation of watershed activities remain major challenges.

Existing assessment methods are often fragmented, dependent on manual observations, and lack spatial integration. Many watershed projects face difficulties in accurately visualizing field conditions, tracking spatial changes, identifying intervention impacts, and generating reliable evidence for decision-making. Although geo-coded images are increasingly being collected during watershed implementation and monitoring, their analytical utilization remains limited. ln many cases, geo-tagged photographs are used only for documentation purposes rather than for integrated spatial analysis and interpretation. There is insufficient use of advanced GIS and remote sensing techniques to systematically visualize, analyse, and interpret these geo-coded datasets in relation to watershed characteristics and satellite-derived information.

Furthermore, the absence of standardized visualization frameworks restricts the ability of planners and administrators to derive actionable insights from geo-coded imagery. Challenges also exist in integrating field-level geo-coded images with satellite data, thematic layers, and watershed boundaries for meaningful analysis.

Limited technical approaches for image interpretation reduce the effectiveness of watershed monitoring systems and hinder scientific evaluation of land and water resource interventions.

The SRISHTI-DRISHTI platform provides an opportunity to address these challenges by offering consistent 30 m spatial resolution satellite data that can support integrated geospatial analysis. However, there is a need to develop specialized methodologies and visualization techniques that can effectively interpret geo-coded images and generate meaningful watershed insights. Therefore, the study aims to bridge this gap through a focused analytical framework combining GlS, remote sensing, thematic mapping, and geo-coded image interpretation for enhanced watershed development outcomes. Scope of the Study: Table to be Added here Expected Solutions:

The proposed study is expected to provide a structured geospatial framework for visualization and interpretation of geo-coded images in watershed development programs. The key expected solutions include:

**a)Development of an lntegrated Geospatial Visualization Framework:**Thes tudy will develop a GIS and remote sensing-based framework for integrating geo-coded images with satellite data from the SRISHTI-DRISHTI platform to support watershed analysis and monitoring.**b) lmproved Geo-Coded lmage lnterpretation:**Advanced spatial interpretation techniques will help convert geo-coded imagery into meaningful analytical information related to land use, Vegetation status, water resources, watershed interventions, and environmental changes.**c) Generation of Thematic Maps and Visualization Products:**

The study will visualize outputs such as land use maps,drainage maps, vegetation maps, watershed intervention maps, and spatial change detection products for better interpretation and planning.

d) Enhanced Watershed Monitoring and Assessment: lntegration of geo-coded images with satellite-based datasets will improve the accuracy and efficiency of monitoring watershed activities and assessing development outcomes.

**e) Scientific Support for Decision-Making:**The proposed framework will support evidence-based planning and policy decisions by providing spatially validated and visually interpretable watershed information.**f) Scalable and Cost-Effective Monitoring Approach:**The methodology will offer a focused, scalable, and economically viable approach for watershed monitoring that can be replicated across different regions and watershed programs.**g) Strengthening Use of the SRISHTI-DRISHTI Platform:**

The study will enhance the practical utilization of the SRISHTI-DRISHTI platform as a dedicated source for satellite-based geospatial analysis and watershed interpretation.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26016"></a>[16] SIH26016: Real-Time National Land Acquisition & Management System for End-to-End Digital Monitoring and Decision Support

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26016` (SIH26016) |
| **Problem Statement Title** | Real-Time National Land Acquisition & Management System for End-to-End Digital Monitoring and Decision Support |
| **Organization** | Ministry of Rural Development |
| **Department** | Dept of land resources (DoLR) |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Land acquisition is a critical component of infrastructure development and public welfare projects in India. It facilitates the implementation of highways, railways, industrial corridors, irrigation projects, urban development, renewable energy initiatives, and other strategic infrastructure. The process involves multiple stakeholders, including land requiring bodies, land acquiring authorities, district administrations, state governments, and central ministries.**Description of the Study:**

Web-based National Land Acquisition & Management System that digitizes the complete land acquisition lifecycle—from project proposal submission to final possession of land. The proposed platform should provide standardized workflows for different stakeholders and enable seamless coordination among Central Ministries, State Governments, District Authorities, and Project Implementing Agencies. The system should facilitate online submission and approval of proposals, digital scrutiny, document management, automated workflow routing, and status tracking at every stage.The platform should support geo-tagging of acquired land parcels using GIS technology, enabling visualization of project locations on interactive maps. It should also maintain real-time information on key land acquisition parameters such as:

7. Land proposed and acquired 8. Notifications issued 9. Awards declared 10. Compensation assessed and disbursed 11. Possession status 12. Rehabilitation and Resettlement (R&R) progress 13. Number of affected and displaced families 14. Project-wise and state-wise progress 15. Timeline monitoring and milestone tracking The platform should be scalable for nationwide implementation across all States and Union Territories while ensuring data security, interoperability, and compliance with government standards.

Add 'Scope of Study' Table here Problems:

At present, land acquisition activities are managed through fragmented systems, manual documentation, and state-specific processes. The absence of a unified national digital platform results in inconsistent data collection, duplication of efforts, delays in approvals, limited transparency, and inadequate monitoring. Decision-makers often lack access to real-time information on the progress of land acquisition, compensation disbursement, possession status, and rehabilitation measures.

**Expected Solution:**

The solution should incorporate role-based access control, automated alerts and notifications, API-based integration with relevant government systems, customizable dashboards, analytical reports, and predictive analytics to support policy formulation and efficient project execution.**The system should provide:**

7. End-to-end digital workflow for land acquisition processes;

8. Online submission, verification, approval, and tracking of proposals;

9. GIS-enabled geo-tagging and spatial visualization of land parcels;

10. Interactive national dashboard displaying: Area notified, Area acquired, Compensation assessed and paid, Number of affected and displaced families, Rehabilitation & Resettlement status, Project progress, Possession status, Timeline adherence 11. API-based integration with land records, cadastral maps, and relevant government portals.

12. Mobile-responsive interface for field-level data collection and verification.

13. Secure document repository with version control and audit history.

14. Customizable MIS reports and executive dashboards for decision-makers.

The solution should significantly enhance transparency, accountability, efficiency, and data-driven governance in land acquisition while reducing processing time and improving inter-agency coordination.

Add 'Suggested components-wise technology' table here

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26017"></a>[17] SIH26017: Predictive Analytics System for Early Detection of Land Acquisition Delays

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26017` (SIH26017) |
| **Problem Statement Title** | Predictive Analytics System for Early Detection of Land Acquisition Delays |
| **Organization** | Ministry of Rural Development |
| **Department** | Dept of land resources (DoLR) |
| **Category** | Software |
| **Theme** | Agriculture, FoodTech & Rural Development |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Land acquisition is one of the most critical and time-sensitive phases of infrastructure development. Delays in acquiring land significantly impact the execution of national and state-level projects. The causes of land acquisition delays are multifaceted, including prolonged administrative approvals, legal disputes, delayed compensation disbursement, incomplete documentation, pending notifications, land ownership conflicts, rehabilitation and resettlement challenges, and inter-departmental coordination issues.**Description of the Study:**

Develop an AI-powered Predictive Analytics System capable of identifying land acquisition projects that are at risk of delay by analyzing historical and real-time project data.

The proposed solution should utilize machine learning algorithms to study patterns from completed and ongoing land acquisition cases, considering parameters such as project type, land area, number of affected families, compensation status, approval timelines, legal disputes, possession status, rehabilitation progress, stakeholder responsiveness, and historical performance.

The system should generate a risk score for each project and predict the probability of delays at different stages of the land acquisition lifecycle. It should also identify the key contributing factors responsible for the predicted delay and provide actionable recommendations for mitigating those risks.

Interactive dashboards should enable policymakers and administrators to monitor high-risk projects, visualize delay trends across districts and states, and prioritize interventions based on predictive insights. The solution should support continuous learning by updating prediction models as new project data becomes available, thereby improving prediction accuracy over time.

Add 'Scope of Study' Table here Problems:

There is no intelligent mechanism capable of identifying projects that are likely to experience delays before they occur.

With the availability of large volumes of historical land acquisition data, project timelines, administrative records, and geospatial information, Artificial Intelligence (AI) and Machine Learning (ML) techniques can be leveraged to predict potential delays, identify risk factors, and enable proactive interventions. Such a predictive system would significantly improve planning, monitoring, resource allocation, and decision-making for infrastructure projects across the country.

**Expected Solution:**

The proposed solution should be an AI-enabled decision support platform capable of predicting potential land acquisition delays before they adversely impact project implementation.**The solution should provide:**

7. AI/ML-based predictive models for forecasting project delays.

8. Automated identification of projects with high probability of delay.

9. Project-wise risk scoring and prioritization based on multiple parameters.

10. Identification of key delay drivers such as pending approvals, compensation delays, legal disputes, incomplete documentation, rehabilitation status, and administrative bottlenecks.

11. Explainable AI techniques to ensure transparency in prediction results.

- Interactive dashboards displaying: Delay probability, Risk categorization, District-wise and State-wise delay trends, Timeline analysis, Performance indicators, Comparative analytics 7. GIS-enabled visualization of high-risk projects on digital maps.

8. Automated alerts and notifications for project managers and administrators.

9. Predictive recommendations suggesting corrective actions to minimize delays.

10. Continuous model learning using newly generated project data for improved prediction accuracy.

11. APIs for integration with existing land acquisition management systems and government databases.

12. Secure, role-based access for various stakeholders with comprehensive audit trails.

The proposed solution should enable proactive governance by shifting project monitoring from reactive reporting to predictive decision-making, thereby reducing project delays, optimizing public expenditure, and accelerating infrastructure development.

Add 'Suggested components-wise technology' table here

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26018"></a>[18] SIH26018: Intelligent Land Record Digitization and Validation System

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26018` (SIH26018) |
| **Problem Statement Title** | Intelligent Land Record Digitization and Validation System |
| **Organization** | Ministry of Rural Development |
| **Department** | Dept of land resources (DoLR) |
| **Category** | Software |
| **Theme** | MedTech / BioTech / HealthTech |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Land records form the backbone of land administration, property ownership, taxation, land acquisition, dispute resolution, and infrastructure planning. Across India, a significant portion of historical land records continues to exist in the form of handwritten registers, scanned documents, maps, cadastral records, and legacy PDF files maintained at various administrative levels.

An intelligent digitization system can significantly improve data quality while accelerating the modernization of India's land administration ecosystem.

**Description of the Study:**

Develop an AI-powered Intelligent Land Record Digitization and Validation System capable of automatically extracting structured information from scanned land records, handwritten documents, maps, and legacy PDF files.

The proposed solution should utilize advanced OCR, Computer Vision, and Natural Language Processing techniques to recognize printed as well as handwritten text in multiple Indian languages. The extracted information should be intelligently classified into predefined fields such as landowner details, survey number, khasra number, khata number, plot area, village, tehsil, district, land classification, ownership details, mutation records, and registration information.

The platform should provide a user-friendly interface for document upload, automated processing, manual verification where required, audit tracking, and seamless integration with existing Land Records Management Systems (LRMS), Digital India Land Records Modernization Programme (DILRMP), GIS platforms, and other government databases.

**Scope of Study:**

Recent advancements in Artificial Intelligence (AI), Optical Character Recognition (OCR), Computer Vision, Natural Language Processing (NLP), and Machine Learning (ML) provide an opportunity to automate the extraction, digitization, and validation of legacy land records with greater speed and accuracy.

Add 'Scope of Study' Table here Problems:

Records often suffer from issues such as poor image quality, inconsistent formats, faded text, damaged pages, multiple regional languages, and handwritten annotations, making manual digitization a time-consuming and error-prone process.

The lack of standardized and accurate digital land records creates challenges in maintaining reliable databases, verifying ownership, integrating records with modern land information systems, and delivering citizen-centric services. Manual data entry not only increases operational costs but also introduces inconsistencies that affect decision-making and governance.

**Expected Solution:**

The proposed solution should be an intelligent AI-based platform capable of automating the digitization and validation of legacy land records while minimizing manual intervention and ensuring high data accuracy.**The system should provide:**

7. Support for multilingual document recognition across major Indian languages.

8. Automatic extraction of structured land record information from scanned PDFs, images, and historical documents.

9. Intelligent classification of extracted data into predefined land record fields.

10. Automated validation using business rules, cross-database verification, and duplicate detection.

11. Confidence scoring for extracted information with automatic identification of uncertain fields.

12. Human-assisted verification workflow for low-confidence records.

13. AI-driven learning mechanism that improves extraction accuracy over time.

14. Integration with existing Land Records Management Systems (LRMS), DILRMP databases, GIS platforms, and cadastral maps.

15. Secure document repository with metadata management and audit trails.

- Interactive dashboards displaying: Number of documents processed, Extraction accuracy, Validation status, Pending verification cases, Error statistics, State-wise and district-wise digitization progress 7. APIs for seamless integration with government applications and digital governance platforms.

8. Role-based access control ensuring secure access to sensitive land record information.

The solution should significantly reduce manual effort, improve the accuracy and reliability of digital land records, accelerate modernization of land administration, and support transparent, data-driven governance.

Add 'Suggested components-wise technology' table here

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26019"></a>[19] SIH26019: National Digital Platform for Research, Policy Innovation, and Evidence-Based Land Governance

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26019` (SIH26019) |
| **Problem Statement Title** | National Digital Platform for Research, Policy Innovation, and Evidence-Based Land Governance |
| **Organization** | Ministry of Rural Development |
| **Department** | Dept of land resources (DoLR) |
| **Category** | Software |
| **Theme** | Blockchain & Cybersecurity |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Land is a finite and strategic resource that underpins economic development, environmental sustainability, food security, urban expansion, and social equity. Effective land governance is therefore critical to achieving sustainable development goals and supporting India's rapidly evolving socio-economic landscape. However, the land administration ecosystem in India remains largely implementation-oriented, with limited institutional focus on applied research, policy experimentation, and evidence-based innovation.

Description:Develop a comprehensive National Digital Platform for Research and Policy Innovation that promotes applied research, policy experimentation, knowledge sharing, and evidence-based decision-making in land governance.

The platform should function as a centralized repository and collaborative ecosystem that integrates datasets, research publications, policy documents, geospatial information, analytical tools, and case studies from various government departments, academic institutions, and research organizations.

**Scope of the Study:**

There is a pressing need for a dedicated digital platform that serves as a national knowledge ecosystem for researchers, policymakers, government agencies, academic institutions, and industry experts to collaborate, conduct research, evaluate policies, and develop innovative solutions for strengthening land governance across the country.

Add 'Scope of Study' Table here Problems:

Emerging challenges such as climate change, rapid urbanization, urban-rural land transitions, increasing land disputes, sustainable land use planning, geospatial governance, and digital transformation require continuous research and innovative policy interventions. Despite the availability of vast datasets generated through land records, cadastral surveys, satellite imagery, GIS platforms, and government programmes, these resources remain underutilized for generating actionable insights and supporting informed policymaking.

**Expected Solution:**

The proposed solution should be a secure, scalable, AI-enabled National Research and Policy Innovation Platform that strengthens evidence-based land governance through collaborative research, advanced analytics, and digital knowledge management.**The platform should provide:**

7. A centralized digital repository for land governance research, policy papers, datasets, legal documents, and case studies.

8. AI-powered search and recommendation engine for discovering relevant research and policy resources.

9. Collaborative workspaces for researchers, policymakers, academic institutions, and government agencies.

10. Interactive GIS-based visualization of land use patterns, climate vulnerability, infrastructure development, and policy impacts.

11. Advanced analytics and decision-support tools for evaluating policy effectiveness and identifying emerging trends.

12. Policy simulation modules to assess the likely outcomes of proposed reforms before implementation.

13. Integration of satellite imagery, remote sensing, land records, socio-economic datasets, and geospatial databases.

14. AI-assisted research tools for trend analysis, literature synthesis, predictive modelling, and scenario analysis.

15. Innovation portal supporting hackathons, research grants, pilot projects, and knowledge competitions.

16. Interactive dashboards displaying: Research outputs, Policy performance indicators, Land use trends, Climate resilience metrics, Land dispute statistics, Project implementation outcomes, Geospatial insights 17. Secure role-based access for researchers, government officials, institutions, and public users with appropriate permissions.

18. APIs for seamless integration with existing government platforms, research databases, GIS systems, and digital governance initiatives.

The platform should establish a sustainable national ecosystem for applied research and policy innovation, enabling evidence-based decision-making, fostering interdisciplinary collaboration, accelerating technological adoption, and supporting resilient, transparent, and future-ready land governance in India.

Add 'Suggested components-wise technology' table here

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26020"></a>[20] SIH26020: Design and Development of Innovative Hand-Spinning Equipment for Enhancing Khadi Artisan Productivity and Income

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26020` (SIH26020) |
| **Problem Statement Title** | Design and Development of Innovative Hand-Spinning Equipment for Enhancing Khadi Artisan Productivity and Income |
| **Organization** | Ministry of MSME |
| **Department** | Coordination Section |
| **Category** | Hardware |
| **Theme** | Blockchain & Cybersecurity |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Khadi is a sustainable rural textile system based on hand-spun yarn and hand-woven fabric produced by decentralized artisans using manually operated Charkhas like the New Model Charkha. While it supports rural livelihoods, especially for women, existing systems still face issues of low efficiency, discomfort, inconsistent yarn quality, and limited productivity.

Therefore, there is a need for an improved manually operated spinning system with better ergonomics, higher productivity, user-friendly design, and enhanced aesthetics, while preserving the traditional and sustainable nature of Khadi production.

**Description:**

To Design and develop an innovative, lightweight, portable, and ergonomic manually operated hand-spinning system to improve yarn production efficiency and quality, reduce manual effort, and enhance livelihood and income opportunities for Khadi women artisans in decentralized production.

**Expected Solution:**

- Development of a prototype manually operated innovative hand-spinning system with improved productivity, ergonomic efficiency, and reduced manual drudgery.

- Comparative evaluation of the developed system with existing Charkha systems in terms of yarn quality, productivity, operational effort, portability, weight, and manufacturing cost.

- Preparation of a deployment and dissemination framework for field trials, artisan adoption, and vendor development in the Khadi sector.

- Cost-benefit analysis, economic impact assessment, and scalability roadmap for large-scale implementation.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26021"></a>[21] SIH26021: Honey Chain: A block chain-based system for honey traceability and smart beekeeping management.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26021` (SIH26021) |
| **Problem Statement Title** | Honey Chain: A block chain-based system for honey traceability and smart beekeeping management. |
| **Organization** | Ministry of MSME |
| **Department** | Coordination Section |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

KVIC's Honey Mission supports rural beekeepers with bee boxes and extraction toolkits for livelihood promotion, but they still face challenges like counterfeit honey, low consumer trust, weak market linkages, and lack of traceability and advanced hive management support.

Hence, there is a need for an integrated block chain, AI, and IoT-based digital ecosystem to improve honey authenticity, traceability, productivity, and market credibility.

**Description:**

Develop 'Honey Chain,' a block chain-based honey traceability and smart beekeeping system with QR-code consumer verification, secure batch tracking, and AI-IoT features for disease detection, environmental monitoring, and productivity prediction to enhance authenticity, transparency, and market access for rural beekeepers.

**Expected Solution:**

- Develop a prototype block chain-based honey traceability and smart beekeeping system with QR-code consumer authentication.

- Integrate IoT-enabled hive monitoring and AI analytics for disease detection, colony health tracking, and productivity optimization.

- Create a scalable deployment framework for implementation across rural beekeeping clusters under KVIC and related institutions.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26022"></a>[22] SIH26022: Design and develop a smart, solar-powered drying and compact packaging system to support home-based agarbatti manufacturing by rural women artisans.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26022` (SIH26022) |
| **Problem Statement Title** | Design and develop a smart, solar-powered drying and compact packaging system to support home-based agarbatti manufacturing by rural women artisans. |
| **Organization** | Ministry of MSME |
| **Department** | Coordination Section |
| **Category** | Hardware |
| **Theme** | Agriculture, FoodTech & Rural Development |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Agarbatti making is a key home-based livelihood for rural women, but traditional drying methods depend on weather and often cause uneven drying, moisture issues, and loss of fragrance, reducing product quality and income. Hence, there is a need for an affordable smart drying and packaging system suitable for rural household-based production.

**Description:**

Traditional agarbatti drying is slow, weather-dependent, and leads to uneven drying, fragrance loss, fungal growth, and breakage, reducing product quality and income for rural women artisans.

Therefore, there is a need for a smart solar-powered drying chamber with temperature and humidity control for uniform, hygienic, all-weather drying, along with a low-cost packaging system to preserve fragrance, improve shelf life, and enhance marketability.

**Expected Solution:**

The proposed solution is a compact, low-cost, solar-powered smart drying chamber for rural home-based agarbatti production, along with a simple packaging/sealing device to ensure moisture resistance, fragrance preservation, and improved product quality and shelf life.**The system should include:**

- Solar-powered controlled drying mechanism

- Temperature and humidity sensors

- Uniform airflow and hygienic enclosed chamber

- Portable and easy-to-operate design

- Fragrance-preserving drying conditions

- Battery backup support

- Optional AI/IoT-based monitoring and alerts Packaging Support

- Low-cost moisture-resistant and aroma-preserving packaging

- Compact sealing/packaging mechanism suitable for SHGs/women artisans

- Eco-friendly packaging options

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26023"></a>[23] SIH26023: AI-Powered Geological, Mining and other Reporting Solution for CMPDI/CIL subsidiaries

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26023` (SIH26023) |
| **Problem Statement Title** | AI-Powered Geological, Mining and other Reporting Solution for CMPDI/CIL subsidiaries |
| **Organization** | Ministry of Coal |
| **Department** | Coal India Limited |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

CMPDI/CIL subsidiaries play a key role in providing geological and mining information to the Ministry of Coal and responding to parliamentary and high-priority administrative inquiries. These reports require compilation of data from scanned PDFs, digital documents, spreadsheets, images, and historical archives. The current workflow is largely manual, resulting in:

- High dependence on individual expertise

- Delay in generating reports and analytics

- Higher probability of manual errors

- Limited ability to quickly retrieve insights when required Objectives:

- Deploy an automated platform for AI-assisted geological, mining and any other production figures document processing and reporting.

- Enhance data validation, consistency, and traceability across historical and contemporary datasets.

- Build an efficient, scalable foundation for future digital transformation initiatives within each CIL subsidiary and the Ministry of Coal.

Desired Outcomes: The solution should be implemented in structured phases, including requirement analysis, data digitization and pre-processing, platform development, system testing, integration with CIL subsidiary workflows, training, and continuous enhancement to ensure scalability and long-term adoption.

1. Automated Report Generation Platform 2. Automated Word Cloud and Topic Identification Module 3. AI-Based Query and Response System Expected Benefits:

- Reduction in report preparation time as less as it can be, quantified in percentage.

- Maximum accuracy, calculated in percentage in structured extraction and report generation.

- Maximum automation, calculated in percentage of repetitive reporting and response workflows.

- Faster response to high-level inquiries and parliamentary questions

- Improved data accessibility, transparency, and standardization

- Strengthened operational efficiency and informed decision-making using historical insights and AI-generated recommendations Impact:

The proposed system should significantly modernize CMPDI/CIL subsidiaries reporting ecosystem, reduce dependency on manual processes, improve response timelines, and strengthen the coal sector's capability to support governance, policy planning, and operational excellence.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26024"></a>[24] SIH26024: AI-Based Smart Governance and Compliance Monitoring System for Coal Mines

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26024` (SIH26024) |
| **Problem Statement Title** | AI-Based Smart Governance and Compliance Monitoring System for Coal Mines |
| **Organization** | Ministry of Coal |
| **Department** | Coal India Limited |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

The Indian coal mining sector involves large-scale operations spread across multiple subsidiaries, mine sites, contractors, regulatory bodies, and field offices. Governance-related activities such as statutory compliance monitoring, inspection tracking, safety observations, production reporting, environmental monitoring, worker attendance, contract management, grievance handling, and regulatory reporting are often managed through fragmented systems, manual documentation, spreadsheets, and delayed reporting mechanisms.

This leads to challenges such as data inconsistency, delayed decision-making, limited transparency, compliance gaps, duplication of records, weak monitoring of field-level activities, and difficulty in obtaining real-time operational insights. With increasing focus on transparency, accountability, sustainability, and digital governance, there is a need for an integrated smart governance platform specifically designed for the coal mining ecosystem.

**Defining the Problem:**Develop a centralized AI-enabled governance and compliance monitoring platform for coal mining operations that can digitally integrate mine-level activities, statutory compliance, inspections, contractor management, and operational reporting.**The proposed solution should:**

- Digitally track statutory compliance requirements related to safety, environment, production, and labour regulations.

- Enable real-time monitoring of inspections, observations, violations, and corrective actions.

- Use AI/analytics to identify high-risk areas, recurring compliance failures, and operational anomalies.

- Provide geo-tagged and time-stamped field reporting through mobile applications.

- Integrate dashboards for mine officials, corporate management, and regulatory authorities.

- Generate automated alerts, reminders, compliance reports, and escalation mechanisms.

- Minimize manual paperwork and improve transparency, accountability, and decision-making.

- Be scalable for deployment across multiple mines and subsidiaries.

- Participants may use AI/ML, mobile applications, GIS mapping, OCR/document digitization, workflow automation, blockchain-based audit trails, or multilingual conversational interfaces as part of the solution.

**The proposed system is expected to:**

- Improve governance efficiency and transparency in coal mining operations.

- Reduce delays and errors in compliance management and reporting.

- Enable data-driven monitoring and faster administrative decision-making.

- Strengthen accountability and real-time tracking of field activities.

- Support digital transformation and paperless governance in the mining sector.

- Create a scalable indigenous e-governance framework for Indian coal mines. Expected Solution:

The proposed solution should be a centralized AI-enabled smart governance platform for coal mines that integrates compliance monitoring, inspection management, operational reporting, contractor management, and field activity tracking into a single digital ecosystem. The system should provide real-time visibility, automated workflows, and data-driven insights through web and mobile applications to improve transparency, accountability, and decision-making across multiple mining sites and subsidiaries.

- Centralized dashboard for mine officials, corporate management, and regulatory authorities with real-time compliance and operational monitoring.

- AI/analytics engine to detect compliance risks, operational anomalies, recurring violations, and generate predictive alerts.

- Geo-tagged mobile application for field inspections, safety observations, attendance, and incident reporting with offline support.

- Automated workflow system for alerts, reminders, escalations, digital approvals, and statutory report generation.

- GIS mapping, OCR-based document digitization, and secure digital audit trails for transparent and paperless governance.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26025"></a>[25] SIH26025: Development of an AI-enabled Low Cost Real Time Mine Subsidence Monitoring, Prediction and Early Warning System for Underground Coal Mines in India

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26025` (SIH26025) |
| **Problem Statement Title** | Development of an AI-enabled Low Cost Real Time Mine Subsidence Monitoring, Prediction and Early Warning System for Underground Coal Mines in India |
| **Organization** | Ministry of Coal |
| **Department** | Coal India Limited |
| **Category** | Hardware |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Surface subsidence caused by underground coal mining poses significant risks to nearby communities, public infrastructure, agricultural land, forest areas, and the surrounding environment. In India, subsidence monitoring is still largely dependent on conventional field observations, periodic surveys, and post facto damage assessments, which often fail to provide timely warning before critical ground failure occurs.

There is a strong need for an indigenous, low cost, intelligent, and real time monitoring solution capable of detecting early signs of ground movement and enabling proactive risk mitigation. Such a system should be affordable, scalable, and deployable across Indian underground coal mines using widely accessible technologies, thereby supporting the national vision of smart and sustainable mining.

**Description:**

The problem envisages development of an AI-enabled smart mine subsidence monitoring and early warning platform based on a localized wireless surface mesh sensor network deployed above underground mine panels.

The proposed solution involves installing a distributed network of low cost smart sensor nodes across the surface over the underground mining area. Each node may be equipped with sensors such as:

- tilt/inclination sensors,

- vibration sensors,

- displacement/stretch sensors,

- crack detection sensors,

- optional low cost positioning modules.

These nodes will communicate through a wireless mesh communication network (such as LoRa/Zigbee/Wi-Fi mesh), enabling continuous real time monitoring of micro ground movements over the mine panel.

**The system should continuously detect:**

- abnormal ground tilt,

- change in relative distance between nodes,

- early crack initiation,

- unusual vibration signatures, which may indicate the onset of subsidence.

**Using Artificial Intelligence / Machine Learning, the platform should:**

- identify abnormal deformation patterns,

- predict possible subsidence zones,

- estimate severity and progression,

- generate automated early warning alerts,

- support timely operational decisions.

The solution should be robust, low power, scalable, and suitable for Indian geo-mining conditions.

**Expected Solution:**

A web/mobile enabled intelligent mine subsidence monitoring platform integrating IoT, wireless mesh networking, AI, and GIS technologies for:

- development of low cost smart sensor nodes using readily available hardware platforms (e.g., Arduino/ESP32/Raspberry Pi);

- deployment of a localized wireless mesh network over underground mine panels for continuous surface deformation sensing;

- real time monitoring of tilt, displacement, vibration, and crack initiation;

- AI/ML-based anomaly detection and subsidence prediction using live and historical data;

- GIS based visualization of live deformation maps and risk zones;

- automated early warning alerts through SMS/email/mobile app notifications;

- interactive dashboards for mine operators, planners, and regulators;

- offline capability with periodic cloud synchronization;

- scalable deployment across multiple underground coalfields.

The proposed solution must be low cost, easy to deploy, energy efficient, scalable, and student prototype friendly, while enabling a Made in India smart mining safety solution for sustainable underground coal mining.

**Now your problem statement has a clear unique innovation hook:**

'Wireless Surface Mesh Network for Real Time Subsidence Detection' that is what will differentiate it from generic AI proposals.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26026"></a>[26] SIH26026: Development of Mobile (Quadruped)/Handheld Device/System for Real-Time Detection of Narcotics and Explosives across Indian Railways.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26026` (SIH26026) |
| **Problem Statement Title** | Development of Mobile (Quadruped)/Handheld Device/System for Real-Time Detection of Narcotics and Explosives across Indian Railways. |
| **Organization** | Ministry of Railways |
| **Department** | Ministry of Railways |
| **Category** | Hardware |
| **Theme** | Robotics and Drones |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Indian Railways is one of the largest rail networks in the world, serving millions of passengers daily across thousands of stations, platforms, and train coaches. Ensuring the safety and security of passengers and railway assets is a critical responsibility of the Railway Protection Force (RPF).Drug trafficking through railway networks and threats arising from explosives and Improvised Explosive Devices (IEDs) have emerged as major security concerns. During the year 2025, RPF recovered narcotic substances worth approximately Rs. 300 Crores in more than 2100 instances.However, as per data of Narcotic Control Bureau (NCB), nearly 15-20% of drug trafficking is routed through the railway network. Similarly, recent incidents involving use of high explosives such as RDX on railway tracks highlight the vulnerability of railway infrastructure to hostile activities.At present, Indian Railways does not possess any dedicated mobile quadruped or handheld system for real-time field detection of narcotics and explosives. This severely limits the capability of RPF personnel to conduct rapid, non-intrusive screening at station entry points, platforms, inside train coaches, and during luggage or parcel screening operations. Therefore, there is an urgent requirement for a modern, technology-driven, ruggedised, and easy-to-operate detection system suitable for Indian Railways operational conditions.

**Description:**

The proposed problem statement envisages development of an AI-enabled Mobile (Quadruped) Device/System and Handheld Device/System for real-time detection of narcotics and explosives across Indian Railways.The Mobile (Quadruped) Device/System should function as an intelligent robotic surveillance platform capable of operating in hazardous, complex, and GPS-denied environments. The system should support autonomous or semi-autonomous navigation using LiDAR-based mapping, sensor fusion, thermal and optical imaging systems, and real-time video surveillance. It should be capable of operating in dusty, humid, high-temperature, low-light, and uneven railway environments including ballast areas, yards, tunnels, platforms, and coaches.The quadruped system should support underframe inspection of coaches/wagons, yard surveillance, night patrolling, bomb detection assistance, narcotics detection, facial recognition and matching, and inspection of luggage and concealed areas inside train coaches. The system should also support secure wireless communication, onboard data logging, real-time transmission to control centres, obstacle detection and avoidance, fail-safe mechanisms, and long-duration deployment capability.The Handheld Device/System should be lightweight, ruggedised, easy to operate, and deployable by RPF personnel with minimal training. It should support offline and online operation, encrypted data storage, real-time alerts, GPS tagging, automatic event logging, multilingual interface, and integration with centralized monitoring systems. The device should enable non-intrusive screening crowded railway environments and support wireless transmission of alerts and threat information to control rooms or designated supervisors. Both systems should be capable of detecting a broad spectrum of narcotics including heroin, cocaine, methamphetamine, cannabis derivatives, opium derivatives, semi-synthetic and synthetic narcotics, as well as explosives including RDX, TNT, PETN, TATP, C4, dynamite, ammonium nitrate compounds, gunpowder, and pyrotechnics.

**Expected Solution:**

A cost-effective, ruggedised, Al-enabled Mobile (Quadruped) Device/System and Handheld Device/System should be developed for real-time detection of narcotics and explosives across Indian Railways.The proposed solution should support rapid, non-intrusive, and real-time detection capability at railway stations, platforms, train coaches, luggage screening points, yards, and other vulnerable railway locations. The system should provide automated alerts through sound, visual indicators, vibration, and centralized monitoring dashboards along with timestamp and GPS-based event logging.The quadruped system should support autonomous patrolling, under-carriage inspection, thermal imaging, facial recognition, bomb detection support, and surveillance operations in hazardous or inaccessible areas. The handheld system should support quick deployment, easy usability, offline data storage, synchronization after network restoration, multilingual operation, and integration with Railway security infrastructure. The overall solution should be operationally sustainable, low-maintenance, scalable for largescale deployment, and suitable for continuous deployment under diverse Indian Railways operational and climatic conditions.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26027"></a>[27] SIH26027: Al-Powered Automatic Block Planning to Maximize Asset Availability for Train Operations on Indian Railways

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26027` (SIH26027) |
| **Problem Statement Title** | Al-Powered Automatic Block Planning to Maximize Asset Availability for Train Operations on Indian Railways |
| **Organization** | Ministry of Railways |
| **Department** | Ministry of Railways |
| **Category** | Software |
| **Theme** | Transportation & Logistics |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background: Railway maintenance for fixed infrastructure of Engineering, Traction Distribution, and Signal & Telecommunication departments is currently planned independently. Each department requests maintenance blocks/disconnections via the BDMS system. This planning process is decentralized and manual. This often leads to inefficient block utilization, poor coordination, and suboptimal scheduling,which may reduce asset availability and impact train operations. Detailed Description: Maintenance data-such as defects and overdue tasks—is maintained separately in systems like Track Management System (TMS), Signalling Maintenance & Management System (SMMS), and Traction Distribution Management System (TDMS). Meanwhile, the Control Office Application (COA) manages block corridor availability. Without integration and coordinated scheduling, maintenance blocks/disconnections are not optimally planned, resulting in asset downtime and reduced availability of fixed infrastructure for train operation.Your task is to develop an Automatic Block Planning system that integrates maintenance, defects and corridor data to generate optimized block schedules. The system should prioritize maintenance activities to minimize asset downtime and maximize the availability of critical infrastructure, ensuring uninterrupted train operations. Expected Solution: Participants should build an Al system that includes:

1. Integration of maintenance data (defects, overdue maintenance) from TMS, SMMS, and TDMS with corridor block and block availability as per the Train Time Table and the goods trains forecast from the Control Office.

2. Uses AI/ML algorithms to prioritize and schedule maintenance tasks based on criticality, urgency, and impact on asset availability.

3. Optimize block scheduling to maximize asset uptime by minimizing downtime and efficiently coordinating multi-department activities.

4. Provides block plans over multiple time horizons-weekly and monthly—to support both short-term and long-term maintenance.

The solution should transform current decentralized and manual block planning into a data-driven, coordinated process that maximizes asset availability, improves safety, and supports reliable train operations.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26028"></a>[28] SIH26028: Dynamic Forecast of Expected Time of Arrival (ETA) for Coaching Trains

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26028` (SIH26028) |
| **Problem Statement Title** | Dynamic Forecast of Expected Time of Arrival (ETA) for Coaching Trains |
| **Organization** | Ministry of Railways |
| **Department** | Ministry of Railways |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background: Accurate forecasting of the Expected Time of Arrival (ETA) for coaching trains is vital for improving passenger satisfaction and operational efficiency in Indian Railways. Currently, ETA is often estimated using static schedules, current delays and in-built recovery times, which may not reflect real-time ground realities such as speed restrictions, congestion, unscheduled stoppages or historical patterns. As a result, passengers, station staff, and downstream logistics services face uncertainty and planning difficulties. With the growing demand for real-time train information and forecast, there is a pressing need to shift towards a data-driven, dynamic ETA prediction system that continuously adapts to actual train running conditions. Detailed Description: Indian Railways operates a vast network of passenger trains across diverse geographies, weather conditions, and traffic patterns. These coaching trains often face variability in journey times due to multiple real-world factors such as signal halts, congestion on busy routes, delays in preceding trains, temporary speed restrictions, unscheduled maintenance blocks, level crossing gates and operational bottlenecks.Despite this, ETA predictions at intermediate and destination stations are still often based on the train schedule, current delays and in-built recovery times, which lack accuracy and responsiveness.This limitation affects not just passengers but also impacts station planning, crew scheduling, platform allocation, cleaning operations, and feeder transport services. For long-distance trains with multi-day journeys, even a small deviation can cascade and lead to significant uncertainty. In an era where passengers expect real-time updates through mobile apps and station displays, inaccurate or outdated ETA predictions undermine service quality and trust.

The challenge is to create a system that can dynamically forecast the ETA of trains at various points in their journey using real-time data feeds. These may include GPS-based location data, signal aspects, average sectional running times, weather conditions, historical delay patterns, and congestion levels on downstream tracks.

The system must also be scalable to cover thousands of trains simultaneously and adaptable to the Indian Railways diverse operational zones. It should account for temporal and spatial variability in train performance and continuously refine its predictions using machine learning or statistical models. Such a system can serve as a foundation for better passenger communication, resource planning, and delay management. Expected Solution: The expected solution is a real-time ETA prediction system for coaching trains using data-driven models.It should integrate live train location data, operational parameters, historical delay trends, and network conditions to forecast arrival times at upcoming stations.The system must dynamically update ETAs in response to real-time events and delays. Machine learning or statistical forecasting techniques should be employed to improve accuracy over time. The solution should feature APIs for integration with mobile apps, station displays, and control room dashboards, ensuring that passengers and staff receive reliable, up-to-date information to support decision-making and planning.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26029"></a>[29] SIH26029: Automated High-Current Short-Circuit Test System for IEC 60898-1:2015 MCB Compliance.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26029` (SIH26029) |
| **Problem Statement Title** | Automated High-Current Short-Circuit Test System for IEC 60898-1:2015 MCB Compliance. |
| **Organization** | Ministry of Consumer Affairs, Food & Public Distribution |
| **Department** | Department of Consumer Affairs (DoCA) |
| **Category** | Hardware |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background: The safety of electrical installations hinges on reliable Miniature Circuit Breakers (MCBs). IEC 60898-1:2015 mandates rigorous short-circuit breaking capacity tests, crucial for ensuring MCBs perform correctly under severe fault conditions.

Existing Problem: Current manual or semi-automated testing methods for MCBs introduce significant challenges. These include imprecise R (resistive) and XL (inductive) circuit configurations, increased test times, and elevated safety risks for personnel during high-energy fault current generation (up to 10,000A). This impacts test accuracy, repeatability, and overall safety in the MCB certification process.

Detailed Description: This proposal outlines an automated machine to precisely control test currents, voltages, and circuit impedance, executing high-current short-circuit tests on single pole, SPN, DP, TP, and FP MCBs (0.5A-63A) per IEC 60898-1:2015. It features an Automated R and XL Circuit Combination Module with high-power, automatically switched banks for precise power factor control. A High-Current Power Source (transformer-based) delivers up to 10,000A. The Test Station includes universal MCB mounting and a critical arc chute for safety A sophisticated Control and Data Acquisition System (PLC/Industrial PC) manages tests captures high-speed waveforms, and analyzes data (Ip, I2t). A user-friendly HMI allows parameter input and automatic report generation. Comprehensive safety systems are integrated.

Expected Solution: The automated machine will perform MCB breaking capacity tests with unprecedented accuracy and repeatability, fully adhering to IEC 60898-1:2015. This automation will ensure precise parameter control, significantly reduce test times, and enhance safety by minimizing human intervention during high-energy fault conditions. This state-of- he-art facility will provide a reliable platform for MCB certification, contributing directly to electrical safety and quality assurance.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26030"></a>[30] SIH26030: Automated Cable Specimen Preparation System for IS 10810 and IS 7098 Compliance.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26030` (SIH26030) |
| **Problem Statement Title** | Automated Cable Specimen Preparation System for IS 10810 and IS 7098 Compliance. |
| **Organization** | Ministry of Consumer Affairs, Food & Public Distribution |
| **Department** | Department of Consumer Affairs (DoCA) |
| **Category** | Hardware |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background: Accurate and consistent preparation of cable specimens is vital for reliable testing according to Indian Standards like IS 10810 (Parts 2, 7, 33) and IS 7098 (Parts 1 & 2). These tests, including conductor resistance, insulation/sheath thickness, and flame retardance, are crucial for ensuring cable safety and quality. Existing Problem: Currently, cable sample preparation involves significant manual intervention. The cable sample is manually cut by the operator and then straightened manually.Subsequently, these straightened PVC/XLPE/HDPE cable samples are cut into slices using electrically/pneumatically operated machines. Further, the samples are shaped as dumbbells by a dumbbell cutting machine. These manual and semi-automated steps are time-consuming,prone to human error, and introduce inconsistencies that compromise the accuracy and repeatability of critical test results.

Detailed Description: This project develops an automated machine designed to precisely cut insulation and outer sheaths from cables, preparing specimens that strictly adhere to the aforementioned IS standards. Key features include an Automated Cable Feeding and Clamping System utilizing motor-driven rollers and adjustable clamps for secure, straightened cable handling. The Cutting and Stripping Module employs precision blades with programmable depths for clean, circumferential cuts and linear stripping, fulfilling specific length requirements for various tests. An integrated diameter sensor will auto-adjust settings. A Control System (PLC/HMI) manages operations, allows test method selection, monitors status, and provides closed-loop feedback. Automated specimen ejection and waste management further streamline workflow. Robust safety features like enclosed areas and interlocks will protect operators.

Expected Solution: The automated machine will eliminate human error, guaranteeing consistent and repeatable specimen quality while significantly reducing preparation time and costs. By ensuring strict adherence to IS standards, the solution will yield more reliable test results and simplify product certification. This advancement will markedly improve accuracy,efficiency, and safety in cable testing, supporting high-quality control in the cable manufacturing industry.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26031"></a>[31] SIH26031: Quality assessment and grading of onions are often subjective and vary across procurement centers, resulting in disputes and inconsistencies.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26031` (SIH26031) |
| **Problem Statement Title** | Quality assessment and grading of onions are often subjective and vary across procurement centers, resulting in disputes and inconsistencies. |
| **Organization** | Ministry of Consumer Affairs, Food & Public Distribution |
| **Department** | Department of Consumer Affairs (DoCA) |
| **Category** | Software |
| **Theme** | Fitness & Sports |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Expected Solution: Develop an AI-based mobile application that:

- Uses image processing to assess onion quality.

- Identifies damaged, rotten, sprouted, or undersized onions.

- Estimates Grade A and URS percentages.

- Generates a digital quality report instantly.

- Reduces human bias and improves transparency.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26032"></a>[32] SIH26032: Farmers often face long waiting times, lack of information regarding procurement schedules, and uncertainty about procurement status.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26032` (SIH26032) |
| **Problem Statement Title** | Farmers often face long waiting times, lack of information regarding procurement schedules, and uncertainty about procurement status. |
| **Organization** | Ministry of Consumer Affairs, Food & Public Distribution |
| **Department** | Department of Consumer Affairs (DoCA) |
| **Category** | Software |
| **Theme** | Heritage & Culture |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Expected Solution: Develop a platform that:

- Enables farmer registration and slot booking.

- Provides real-time queue management.

- Sends SMS/app notifications.

- Tracks procurement and payment status.

- Reduces congestion and waiting time at procurement centres.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26033"></a>[33] SIH26033: Multiple intermediaries reduce farmers earnings and increase consumer prices.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26033` (SIH26033) |
| **Problem Statement Title** | Multiple intermediaries reduce farmers earnings and increase consumer prices. |
| **Organization** | Ministry of Consumer Affairs, Food & Public Distribution |
| **Department** | Department of Consumer Affairs (DoCA) |
| **Category** | Software |
| **Theme** | MedTech / BioTech / HealthTech |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Expected Solution: Create a digital marketplace that:

- Connects farmers/FPOs directly with consumers and bulk buyers.

- Provides logistics support.

- Uses AI for demand forecasting and route optimization.

**Benefits:**

- Better prices for farmers.

- Lower prices for consumers.

- Reduced supply chain inefficiencies.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26034"></a>[34] SIH26034: Software System to check compliance of Packaged Commodities under Legal Metrology(Packaged Commodities) Rules, 2011 by scanning products, images and labels.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26034` (SIH26034) |
| **Problem Statement Title** | Software System to check compliance of Packaged Commodities under Legal Metrology(Packaged Commodities) Rules, 2011 by scanning products, images and labels. |
| **Organization** | Ministry of Consumer Affairs, Food & Public Distribution |
| **Department** | Department of Consumer Affairs (DoCA) |
| **Category** | Software |
| **Theme** | Agriculture, FoodTech & Rural Development |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Packaged commodities are widely sold through retail stores, supermarkets and e-commerce platforms across India. Under the Legal Metrology Act, 2009 and the Legal Metrology(Packaged Commodities) Rules, 2011, every packaged commodity is required to bear mandatory declarations such as name and address of manufacturer/packer/importer, net quantity, Maximum Retail Price (MRP), month and year of manufacture/packing/import,consumer care details and other prescribed declarations in a specified format and manner.These declarations are important for ensuring transparency, fair trade practices and consumer protection. However, due to the large volume and variety of packaged products available in the market, manual inspection and compliance checking by enforcement agencies becomes time-consuming and resource intensive. Non-compliance such as missing declarations, incorrect font sizes, improper MRP declarations and other such practices are frequently observed.There is scope to develop a compliance checking system capable of scanning product labels,package images and product listings to identify violations under the Legal Metrology(Packaged Commodities) Rules, 2011. Accordingly, a software system capable of automatically detecting, extracting and validating mandatory declarations and identifying noncompliances in packaged commodities through image and label analysis can be developed.

**Description:**

Develop a software application capable of scanning packaged commodity labels, product images and product information to automatically assess compliance with the Legal Metrology(Packaged Commodities) Rules, 2011.**The system should be capable of:**

- Scanning and analyzing images of packaged commodities.

- Detecting mandatory declarations prescribed under Legal Metrology rules.

- Checking correctness, completeness and placement of declarations.

- Identifying missing or non-compliant declarations.

- Checking readability and font size requirements.

- Generating compliance reports and violation summaries.

- Maintaining a repository of scanned products and compliance history.

- Providing dashboards for enforcement officials.

**Expected Solution:**

**The proposed solution should include:**

- User-friendly web and/or mobile-based software application.

- Automated extraction and validation of mandatory declarations.

- Rule-based compliance checking for Legal Metrology (Packaged Commodities)

Rules, 2011.

- Generation of digital compliance reports in PDF and editable formats.

- Dashboard for monitoring inspections, violations and product compliance details.

- Search and retrieval facility for previously scanned products and reports.

- Technical documentation describing software architecture and deployment framework.

**Key Functional Requirements:**

- Image upload and product scanning functionality.

- Extraction of declarations from labels and packaging and detection of mandatory declarations

- Font size and readability analysis.

- Detection of missing, misleading or non-standard declarations.

- Generation of compliance/non-compliance reports.

- Attachment of photographs and supporting evidence.

- Repository of scanned products and inspection history.

- Role-based user access and secure authentication.

- Dashboard for monitoring compliance status and enforcement activities.

- Export of reports to PDF and editable formats.

#### Dataset & Reference Links

https://consumeraffairs.gov.in/pages/legal-metrology-act and the Legal Metrology (Packaged commodities) Rules, 2011

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26035"></a>[35] SIH26035: Development of a Software Program/Application for Generation of Test Reports for Non-Automatic Weighing Instruments (NAWI) as per OIML Recommendation R- 76

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26035` (SIH26035) |
| **Problem Statement Title** | Development of a Software Program/Application for Generation of Test Reports for Non-Automatic Weighing Instruments (NAWI) as per OIML Recommendation R- 76 |
| **Organization** | Ministry of Consumer Affairs, Food & Public Distribution |
| **Department** | Department of Consumer Affairs (DoCA) |
| **Category** | Software |
| **Theme** | Smart Vehicles |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Non-Automatic Weighing Instruments (NAWIs), such as electronic weighing scales, platform scales and weighbridges, are widely used in trade, commerce, healthcare, agriculture and industry where accurate measurement is essential for fair transactions and consumer protection.Under the Legal Metrology Act, 2009 and the Legal Metrology (General) Rules, 2011, such instruments used for transaction and protection are required to conform to prescribed standards,obtain model approval, and undergo verification and stamping before being put into use.

For granting model approval, NAWIs are evaluated by designated laboratories in accordance with OIML Recommendation R 76 – Non-Automatic Weighing Instruments, which specifies internationally accepted technical, metrological and performance requirements. The evaluation involves various metrological and functional tests, the results of which are compiled into detailed test reports.At present, these test reports are largely prepared manually using spreadsheets or document templates, making the process time-consuming, prone to calculation errors and lacking uniformity. Hence, there is a requirement to develop a software application that automates test data recording, compliance evaluation and generation of standardized test reports as per OIML R 76, thereby improving accuracy, consistency, and efficiency in the model approval process.

**Description:**

Develop a software application capable of generating complete test reports for Non-Automatic Weighing Instruments based on test observations recorded during type evaluation as per OIML R 76.

The system should be capable of: - Capturing instrument details and technical specifications.

- Recording laboratory and environmental conditions.

- Entering observations from various OIML R 76 test procedures.

- Automatically calculating permissible errors, and compliance status.

- Performing validation checks for entered test data.

- Automatically determining pass/fail criteria based on OIML R 76 requirements.

- Generating standardized digital test reports in printable formats.

- Maintaining a digital repository of completed test reports.

- Providing secure user access with role-based permissions.

- Supporting future updates whenever OIML recommendations are revised.

**Expected Solution:**

**The proposed solution should include:**

- User-friendly desktop and/or web-based application.

- Digital data entry forms for all applicable OIML R 76 tests.

- Automated calculations and compliance verification.

- Standardized test report generation in PDF and editable formats MS Word etc.

- Instrument-wise test history and report repository.

- Dashboard for monitoring testing activities and report status.

- Search and retrieval facility for previously generated reports.

- Technical documentation describing software architecture, calculation methodology and deployment framework.

**Key Functional Requirements:**

- Entry of manufacturer details, Instrument specifications, Model information and technical parameters

- Compliance determination as per OIML R-76

- Entry of observations for all prescribed tests

- Automatic validation of input data and related calculations

- Automatic preparation of standardized test reports with auto-population of laboratory and instrument details

- Attachment of photographs and supporting documents

- Digital signatures (optional)

- Export to PDF and editable formats

- Dashboard for test report management (completed, in process, history access etc.)

#### Dataset & Reference Links

https://consumeraffairs.gov.in/pages/legal-metrology-act and the Legal Metrology (General)

Rules, 2011

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26036"></a>[36] SIH26036: Development of an Online Verification System for Weighing and Measuring Instruments

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26036` (SIH26036) |
| **Problem Statement Title** | Development of an Online Verification System for Weighing and Measuring Instruments |
| **Organization** | Ministry of Consumer Affairs, Food & Public Distribution |
| **Department** | Department of Consumer Affairs (DoCA) |
| **Category** | Software |
| **Theme** | Transportation & Logistics |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Under the Legal Metrology Act, 2009 and the Legal Metrology (General) Rules, 2011, every weighing and measuring instrument used in transaction or protection is required to be periodically verified and stamped before being put into use. Verification activities are carried out by Legal Metrology Officers (LMOs) of the State Legal Metrology Departments and Government Approved Test Centres (GATCs) notified by the Government.These verification activities presently involve substantial manual processes including submission of applications, scheduling of verification, recording of observations, issuance of verification certificates, maintenance of records and monitoring of validity periods. In many cases, records are maintained physically or through isolated local systems, resulting in delays,and difficulty in monitoring verification status across jurisdictions. There is also a need for digital verification certificates, centralized databases, and online access to verification history for consumers, regulators and businesses.

Accordingly, there is a requirement for development of a unified online verification and digital certification system for weighing and measuring instruments to improve transparency,efficiency, and ease of compliance within the Legal Metrology ecosystem.

**Description:**

Develop a secure web-based and/or mobile-enabled software platform for online verification,certification and lifecycle management of weighing and measuring instruments used under Legal Metrology regulations.**The system should be capable of:**

- Online registration of stakeholders - users of weights and measures, State LMOs, GATCs etc.

- Online submission of applications for verification and re-verification of weighing and measuring instruments.

- Scheduling and allocation of verification activities to Legal Metrology Officers or GATCs.

- Generation of digital verification certificates with QR codes.

- Recording inspection observations and verification results digitally.

- Tracking validity and due dates for re-verification.

- Generating alerts and reminders for expiring verification validity. - - Providing dashboard for monitoring verification status, pendency and enforcement activities.

- Supporting integration with mobile devices for field verification activities.

**Expected Solution:**

**The proposed solution should include:**

- User-friendly web and mobile application for all stakeholders.

- Online workflow management for verification and re-verification processes.

- Digital repository of verification certificates and instrument records.

- Digital verification certificates with QR code and authentication system.

- Automated alerts for verification expiry and renewal.

- Dashboards for users, LMOs, GATCs and administrators etc.

- Search and retrieval facility for verification records and certificates.

- Role-based secure login system for different stakeholders.

- Technical documentation describing software architecture, security framework and deployment methodology.

**Key Functional Requirements:**

- Online registration and profile management for stakeholders.

- Application submission for verification/re-verification of instruments.

- Verification scheduling and workflow management.

- Entry of instrument specifications and verification details.

- Generation of QR-enabled digital verification certificates.

- Dashboard for monitoring applications, verification status and pendency.

- Upload and attachment of photographs and supporting documents.

- Export and printing facility for certificates and reports.

- Mobile application support for field verification officers.

#### Dataset & Reference Links

https://consumeraffairs.gov.in/pages/legal-metrology-act and the Legal Metrology (General) Rules,2011

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26037"></a>[37] SIH26037: Adaptive Path Planning and Collision Avoidance for Autonomous Vehicles on Unstructured Indian Roads

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26037` (SIH26037) |
| **Problem Statement Title** | Adaptive Path Planning and Collision Avoidance for Autonomous Vehicles on Unstructured Indian Roads |
| **Organization** | MathWorks |
| **Department** | MathWorks |
| **Category** | Software |
| **Theme** | Robotics and Drones |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Most autonomous driving systems are developed for roads with clear lane markings, standard signage, predictable traffic flow, and controlled intersections. Indian roads are often very different. Vehicles of many types share the same space, including cars, buses, trucks, auto-rickshaws, twowheelers, bicycles, pedestrians, pushcarts, and animals. Drivers and pedestrians may change direction suddenly, merge without signalling, drive against traffic, or cross at unmarked locations. In many areas, road edges are unclear, potholes are common, and formal lane discipline is limited. These conditions make it difficult for traditional path planning methods that depend on structured road geometry and predictable motion. India has a large and diverse road network that includes village roads, crowded market areas, urban intersections, and highways. To support the safe deployment of autonomous vehicles in such environments, students must build planning systems that can adapt in real time to uncertainty, mixed traffic, and changing road conditions.

**Description:**

Design and simulate an adaptive path planning system for an autonomous vehicle that operates in unstructured Indian road conditions. The system should perceive the environment using a multi-sensor setup such as camera, LiDAR, and radar, and identify diverse road users and obstacles, including auto-rickshaws, pushcarts, pedestrians, and animals. It should predict the short-term motion of surrounding agents, including non-lane-based and irregular movement patterns, and generate a safe, collision-free path that can be replanned in real time. The solution should also handle practical driving situations such as missing lane markings, informal merging, sudden pedestrian movement, and unexpected obstacles on the road. Teams should validate their solution using at least five realistic Indian road scenarios, such as an unmarked village road, a busy urban intersection without signals, a highway merge involving slow-moving vehicles, a dense market area with mixed traffic, and a sudden cattle-crossing event. Teams are encouraged to use MathWorks tools such as RoadRunner for scenario design, Automated Driving Toolbox for sensor modeling and fusion, Navigation Toolbox and Stateflow for planning and decision logic, Vehicle Dynamics Blockset or a Simulink bicycle model for vehicle behavior, and Deep Learning Toolbox for detection and trajectory prediction.

**Expected Solution:**

The expected solution should include three main parts.First, teams should build a working simulation pipeline that integrates perception, prediction, path planning, decision logic, and vehicle motion in MATLAB and Simulink. Second, teams should create realistic driving scenarios that represent Indian road conditions, including at least two detailed RoadRunner scenes such as a village road and an urban intersection, and use them to test the vehicle across all five required scenarios. Third, teams should present results that show safe and reliable navigation, including collision-free performance, smooth path generation, and timely replanning during changing road conditions. The final submission should include the simulation model, the designed scenarios, performance results with metrics such as replanning latency, path smoothness, and scenario completion rate, a short technical report that explains the approach and design choices, and a demonstration video that shows the vehicle navigating the test scenarios. The solution should demonstrate closed-loop validation of autonomous driving behavior under realistic mixed-traffic conditions.

#### Dataset & Reference Links

Teams may use built-in sensor and scenario datasets available in MathWorks Automated Driving Toolbox, RoadRunner sample scenes, synthetic scenarios created by the team, and publicly available traffic datasets relevant to Indian road conditions.

- Indian Driving Dataset (IDD): https://idd.insaan.iiit.ac.in/

- Mendeley traffic data

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26038"></a>[38] SIH26038: Explainable AI for Diabetic Retinopathy Screening in Rural India

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26038` (SIH26038) |
| **Problem Statement Title** | Explainable AI for Diabetic Retinopathy Screening in Rural India |
| **Organization** | MathWorks |
| **Department** | MathWorks |
| **Category** | Software |
| **Theme** | Clean & Green Technology |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

India has over 77 million diabetic adults - the second highest globally. Diabetic Retinopathy (DR) affects ~18% of this population and is a leading cause of preventable blindness. Early screening can prevent90% of vision loss, but India has only ~1 ophthalmologist per 100,000 rural population, making mass manual screening infeasible. Existing AI solutions function as black boxes, lack clinical validation rigor, and fail with variable image quality from portable fundus cameras in field conditions. A robust, explainable, and validated screening system is essential for deployment in primary healthcare centres across rural India.

**Description:**

Design a MATLAB-based retinal image analysis pipeline for automated DR screening addressing real-world deployment challenges:

1. Image Quality Assessment and Enhancement: Automatically evaluate fundus images for adequacy (focus, illumination, field of view). Apply adaptive enhancement (CLAHE, illumination normalization, denoising) for borderline images; reject ungradeable ones with recapture feedback.

2. Retinal Structure Segmentation: Extract clinically relevant structures - optic disc/fovea localization, vessel segmentation, microaneurysm detection, exudate segmentation, hemorrhage classification, and neovascularization detection.

3. DR Severity Grading: Classify using the International Clinical DR severity scale (Levels 0-4, from no DR to proliferative DR) with clinically acceptable sensitivity (>90%) and specificity (>85%) for referable DR (Level 2+).

4. Explainability Module: Implement Grad-CAM attention maps, lesion-level evidence correlated with clinical criteria, calibrated confidence scores, and automated annotated reports - enabling ophthalmologist validation in under 30 seconds for a human-in-theloop workflow.

5. Simulink Workflow Simulation: Model the telemedicine screening pipeline in Simulink - image acquisition rates, bandwidth constraints, processing throughput, and review capacity - to optimize resource allocation for district-level programs serving 100,000+ patients annually.

This problem demands clinical validation rigor, sub-pixel microaneurysm detection, and clinically meaningful explainability

- Tools: Image Processing Toolbox, Computer Vision Toolbox, Deep Learning Toolbox, Medical Imaging Toolbox, Simulink, Statistics and Machine Learning Toolbox Expected Solution: A working prototype demonstrating: DR classification with >90% sensitivity and >85% specificity for referable DR;

explainable Grad-CAM outputs rated as clinically useful; a Simulink model optimizing screening resource allocation; and validation against published benchmarks showing the integrated pipeline outperforms any single technique approach.

#### Dataset & Reference Links

APTOS 2019 Blindness Detection: https://www.kaggle.com/c/aptos2019- blindness-detection IDRiD (Indian Diabetic Retinopathy Image Dataset): https://ieeedataport.org/open-access/indian-diabetic-retinopathy-image-dataset-idrid DRIVE (Vessel Extraction): https://drive.grand-challenge.org/ Messidor-2: https://www.adcis.net/en/third-party/messidor2/

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26039"></a>[39] SIH26039: Al-Powered Underground Mine Safety, Monitoring and Rescue System.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26039` (SIH26039) |
| **Problem Statement Title** | Al-Powered Underground Mine Safety, Monitoring and Rescue System. |
| **Organization** | Governmcnt of Jharkhand |
| **Department** | Department of Higher & Technical Education |
| **Category** | Hardware |
| **Theme** | Travel & Tourism |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Jharkhand's underground coal mines face significant safety challenges, including toxic gas leaks,tunnel collapses, flooding, and poor visibility. During emergencies, rescue teams often lack real-time information about underground conditions, increasing risks and delaying response efforts.An intelligent robotic system capable of monitoring mine conditions, detecting hazards, and locating trapped workers can significantly improve mine safety and rescue operations while reducing risks to human rescuers.

**Description:**

The Al-Powered Mine Safety and Rescue Rover is an inteltigent robotic system designed to operate in hazardous underground mining environments. The rover is equipped with gas sensors, thermal and night-vision cameras, environmental monitoring sensors, and wireless communication modules to provide real-time information about mine conditions.The system can detect toxic gases, monitor temperature and humidity, identify potential hazards, and assist in locating trapped workers during emergencies. Using Al-based analysis and remote monitoring capabilities, the rover enables rescue teams to assess underground conditions without exposing personnel to dangerous environments. The solution aims to enhance mine safety, improve emergency response efficiency, and reduce the risk of casualties in underground mining operations.

**Expected Solution:**

Develop an Al-powered mine rescue system consisting of a rugged ground rover or a compact aerial drone capable of operating in hazardous underground mining environments. The system should provide real-time monitoring of toxic gases, temperature, humidity, and structural conditions while transmitting live video and thermal imaging data to a surface control station.

The rover and drone will assist rescue teams by exploring inaccessible areas, detecting hazards, locating trapped workers, and providing situational awareness during emergencies. The solution should improve mine safety, reduce risks to rescue personnel, and enable faster, more informed emergency response in underground mines.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26040"></a>[40] SIH26040: Smart Water Purification and Quality Monitoring System for Rural and Mining-Affected Areas.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26040` (SIH26040) |
| **Problem Statement Title** | Smart Water Purification and Quality Monitoring System for Rural and Mining-Affected Areas. |
| **Organization** | Governmcnt of Jharkhand |
| **Department** | Department of Higher & Technical Education |
| **Category** | Hardware |
| **Theme** | Renewable / Sustainable Energy |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Access to safe drinking water remains a significant challenge in many rural and mining-affected regions of Jharkhand. Groundwater and surface water sources are often contaminated by suspended particles, excessive minerals, microbial impurities, and mining-related pollutants, making them unsafe for consumption. Additionally, the lack of real-time water quality monitoring makes it difficult for communities to assess water safety and take timely corrective actions.

There is a need for an affordable and intelligent solution that can both monitor water quality and purify, contaminated water. A smart water purification and quality monitoring system can help ensure access to safe drinking water, improve public health, and support sustainable water management in underserved communities.

**Description:**

The proposed solution is a smart water purification and quality monitoring system designed to provide safe drinking water in rural and mining-affected areas. The system continuously monitors key water quality parameters such as pH, turbidity, TDS, and temperature while utilizing a multi-stage purification process to remove impurities, harmful contaminants, and pathogens. Integrated with IoT and real-time monitoring capabilities, the system provides water quality insights,generates alerts for unsafe water conditions, and ensures the delivery of clean and safe drinking water. The solution aims to improve public health, enhance water accessibility, and support sustainable water resource management in underserved communities.

**Expected Solution:**

Develop a smart, cost-effective, and portable water purification system capable of monitoring and improving water quality in real time. The system should measure key parameters such as pH,turbidity, TDS, and temperature, while employing appropriate filtration and purification technologies to remove contaminants and make water safe for drinking.

The solution should provide real-time water quality information, generate alerts for unsafe conditions,and ensure the delivery of clean drinking water for rural and mining-affected communities. It should be easy to deploy, energy-efficient and suitable for operation in remote areas with limited infrastructure.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26041"></a>[41] SIH26041: AR-Based Vocational Training Simulator for Industrial Safety in Jharkhand's Mining & Manufacturing Sector

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26041` (SIH26041) |
| **Problem Statement Title** | AR-Based Vocational Training Simulator for Industrial Safety in Jharkhand's Mining & Manufacturing Sector |
| **Organization** | Governmcnt of Jharkhand |
| **Department** | Department of Higher & Technical Education |
| **Category** | Software |
| **Theme** | Blockchain & Cybersecurity |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Jharkhand is lndia's leading mineral-producing state, with coal mines, steel plants, and mica processing units employing hundreds of thousands of workers many of them young tribal recruits with no prior industrial exposure. Classroom-based safety training using static manuals has documented retention rates below 20% after one week. Live drills are operationally disruptive, and VR headset simulators are inaccessible to small-scale mines and contract workers.. The DGMS, Dhanbad, recorded 48 fatal mine accidents in Jharkhand in 2022-23, a large share involving workers with under 30 days of orientation. The Factories Act, 1948 and Mines Act, 1952 mandate periodic safety certification, yet no standardised digital training platform exists in regional languages, and physical certificates have no mechanism to verify comprehension.

**Description:**

Design and develop a mobile AR-based vocational training and safety certification platform running on mid-range Android smartphones (Android 10+, no external headset required), accessible to workers across Jharkhand's mining, steel, and mica sectors. The platform must deliver interactive AR training modules covering five industrial safety domains: (l) Fire & Explosion Response-exit identification, extinguisher use, and evacuation sequencing overlaid on real surroundings via phone camera; (2) Gas Leak & Confined Space Protocol-hazard zone recognition, PPE selection, and buddy-system procedures simulated in AR; (3) Machinery.

**Expected Solution:**

A working Android APK demonstrating at least two complete AR training modules, an assessment engine, QR-based certificate generation and verification, Hindi and Santali localisation, offline functionality, and a web admin compliance dashboard- submitted with a demo video and public GitHub repository.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26042"></a>[42] SIH26042: Al-Powered Vernacular Pedagogy and Real-Time Translation Tool for Mother Tongue-Based Primary Education

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26042` (SIH26042) |
| **Problem Statement Title** | Al-Powered Vernacular Pedagogy and Real-Time Translation Tool for Mother Tongue-Based Primary Education |
| **Organization** | Governmcnt of Jharkhand |
| **Department** | Department of Higher & Technical Education |
| **Category** | Software |
| **Theme** | Smart Education |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Jharkhand's PALASH Mother Tongue-Based Multilingual Education (MTB-MLE) programme has demonstrated measurable improvements in foundational literacy among tribal children. However,scaling the programme is severely bottlenecked by a shortage of teachers proficient in tribal languages including Ho, Mundari, and Santhali -languages with limited digital NLP resources. The vast majority of teachers assigned to tribal-area primary schools are Hindi-medium trained and lack the linguistic tools to deliver mother-tongue-based instruction. Without a technology bridge, the pedagogical intent of MTB-MLE cannot be realised at scale, and children in over 5,000 tribal-area primary schools continue to receive instruction in a language they do not comprehend at home.

**Description:**

Develop an Al-assisted translation and curriculum-generation software suite that enables non-nativespeaking primary school teachers to deliver mother-tongue-based instruction in Ho, Mundari, and Santhali without prior language training. The system must include an NLP engine capable of translating standard Hindi Foundational Literacy and Numeracy (FLN) curriculum content- including lesson scripts, activity instructions, and assessment prompts-into contextually accurate text and synthesised audio in target tribal languages. A real-time voice-to-voice translation feature must allow a teacher speaking Hindi to conduct interactive classroom dialogue with tribal-language-speaking students, with latency not exceeding three seconds. The system must auto-generate bilingual worksheets and visual flashcard sets aligned to the NIPUN Bharat learning outcomes framework.Given that most schools in the target deployment areas lack reliable internet, the entire application must function offline on low-cost tablets (?2 GB RAM, Android 9+) after initial content synchronisation.

**Expected Solution:**

A working software application demonstrating Hindi-to-tribal-language translation (minimum one tribal language at prototype stage), real-time voice translation with sub-3-second latency, autogenerated bilingual worksheet output, and full offline operation on a low-end Android tablet submitted with a demo video - and GitHub repository.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26043"></a>[43] SIH26043: A digital platform to crowdsource societal challenges and facilitate collaborative problem solving through universities and industry partnerships

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26043` (SIH26043) |
| **Problem Statement Title** | A digital platform to crowdsource societal challenges and facilitate collaborative problem solving through universities and industry partnerships |
| **Organization** | Governmcnt of Jharkhand |
| **Department** | Department of Higher & Technical Education |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Communities across Jharkhand encounter numerous local challenges related to education,healthcare, agriculture, water management, sanitation, environment, rural livelihoods,accessibility, urban infrastructure, and public service delivery. While citizens are often the first to identify these issues, there is currently no structured mechanism through which they can submit such problems for systematic evaluation and innovation-driven resolution.At the same time, Higher Education lnstitutions (HEIs) possess significant academic expertise,research capabilities, and a large pool of students capable of developing practical solutions.Industries and start-ups also have technical expertise, financial resources, and implementation capabilities that can complement academic research. However, collaboration among citizens,universities, and industry remains largely fragmented and project-specific.The National Education Policy (NEP) 2020 emphasizes experiential learning, multidisciplinary research, innovation, industry collaboration, and community engagement. Establishing a technology-enabled platform that connects societal challenges with academic institutions and industry partners can foster demand-driven innovation while enabling students and researchers to work on real-world problems that create measurable social impact.

**Description:**

Every year, citizens across Jharkhand identiff thousands of local issues that require innovative technological or process-based solutions. These challenges often remain unresolved due to the absence of a centralized platform that enables problem collection, categorization, expert evaluation, institutional assignment, and industry collaboration.There is a need to develop a digital platform capable of:

- Allowing citizens, community organizations, local bodies, and government agencies to submit societal challenges thiough an intuitive web and mobile interface, supported by photographs, videos, location details, and relevant documents.

- Automatically categorizing submitted problems based on thematic domains such as education, agriculture, healthcare, water resources, environment, energy, urban development, accessibility, public administration, and rural livelihoods using Al-enabled classification techniques.

- Routing validated problem statements to appropriate universities based on their academic disciplines, research expertise, innovation centres, incubation facilities, and faculty specialization.

- Enabling universities to evaluate submitted challenges, constitute multidisciplinary student and faculty teams, and prepare solution proposals or research projects.

- Facilitating collaboration between universities and industry partners, startups, MSMEs,CSR organizations, research laboratories, and innovation ecosystems for mentorship,funding, prototyping, testing and deployment of solutions.

- Providing workflow management for problem review, institutional allocation, project monitoring, stakeholder communication, milestone tracking, and solution validation.

- Generating dashboards and analytics for govemment departments to monitor the number of challenges received, domain-wise distribution, institutional participation, industry engagement, project progress, and measurable social outcomes.

The platform should support a transparent and scalable innovation ecosystem that transforms community-driven challenges into research, innovation, entrepreneurship, and deployable solutions.

**Expected Solution:**

**A comprehensive Societal Innovation Collaboration Portal comprising the following components:**

- A citizen engagement module enabling individuals, community groups, Panchayati Raj Institutions, Urban Local Bodies, and government departments to submit societal challenges with multimedia evidence, geographical location, and supporting information.

- An Al-enabled problem management module capable of automatically categorizing, prioritizing, deduplication, and routing validated challenges to appropriate universities based on subject expertise and institutional capabilities.

- A university collaboration module allowing Higher Education Institutions to review assigned challenges, form multidisciplinary project teams, assign faculty mentors, manage project workflows, and submit solution proposals.

- An industry partnership module facilitating participation by industries, startups, MSMEs,CSR organizations, research institutions, and innovation hubs for mentoring, co-development, funding, prototyping, pilot implementation, and technology transfer.

- A project lifecycle management system for monitoring milestones, deliverables, approvals, documentation, testing outcomes, intellectual property generation, and implementation status.

- A visual analytics dashboard providing real-time insights on challenge submissions, university participation, industry collaborations, thematic trends, project completion rates,innovation outcomes, patents, startups created, and community impact across districts and sectors.

- A notification and communication system enabling seamless interaction among citizens,universities, industry partners, mentors, and government departments throughout the project lifecycle.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26044"></a>[44] SIH26044: Portal for Academia - Industry collaboration for Skill Mapping, Internships and Placement

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26044` (SIH26044) |
| **Problem Statement Title** | Portal for Academia - Industry collaboration for Skill Mapping, Internships and Placement |
| **Organization** | Ministry of Ayush |
| **Department** | All India Institute of Ayurveda |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

A significant gap exists between the skills acquired in academic institutions and the competencies expected by industries. Students often struggle to identify the skills required for their desired career paths, while industries face challenges in finding candidates with the right skill sets. Similarly, academicians have limited visibility into industry internship opportunities that could help them gain practical exposure and align teaching with current industry practices. There is a need for a unified platform that connects students, industries, and academicians, enabling seamless collaboration and skill development.

**Description:**

The proposed solution is a centralized Academia–Industry Collaboration Portal that serves as a one-stop platform for students, industries, and academicians.**Key features include:**

- Skill Assessment: Students complete a questionnaire to evaluate their technical and soft skills shared by industry. The system generates a skill profile and identifies strengths and skill gaps based on current industry requirements.

- Skill Mapping: Based on the assessment, the platform recommends relevant industries, job roles, and skill development programs aligned with industry requirements.

- Industry Internship & Job Opportunities: Industries can post internships, projects, apprenticeships, and entry-level job openings with required skills. Students receive recommendations based on their skill profiles and can apply directly.

- Industry Learning Programs: Companies can publish training programs, certification courses, workshops, and mentorship initiatives to help students acquire in-demand skills before applying.

- Allow students to search, apply, and track internship and placement opportunities through a single platform.

- Provide a dedicated portal for academicians to explore faculty internships, industrial training, Faculty Development Programs (FDPs), consultancy opportunities, and collaborative research projects.

- Facilitate industry–academia collaboration through mentorship programs, workshops, guest lectures, innovation challenges, and live industry projects.

- Enable institutions to monitor student skill development, internship participation, and placement progress through dashboards and analytics.

- Maintain a digital portfolio for students containing verified skills, certifications, projects, internships, and achievements to improve employability.

**Expected solution:****The solution should provide:**

The solution should provide a secure, scalable, and intelligent platform that supports the complete lifecycle of skill development, internships, and placements.

- Skill Development-

- Skill assessment through questionnaires and aptitude tests.

- Skill profiling and identification of technical and soft skill gaps.

- Personalized learning recommendations, certification programs, and industry-relevant training.

- Career guidance based on individual skills, interests, and industry demand.

- Student digital portfolios showcasing verified skills, certifications, projects, and achievements.

- Internship-

- Centralized internship portal where industries can post internship opportunities with required skills.

- Matching of students to internships based on their skill profiles and career interests.

- Internship application and tracking system for students.

- Internship opportunities for academicians, industrial training, and Faculty Development Programs (FDPs).

- Progress tracking, mentor feedback, and internship completion records.

- Placement-

- Industry portal for posting job opportunities with required qualifications and skill sets.

- Recommendation engine to match students with relevant placement opportunities.

- Candidate shortlisting based on skill compatibility and eligibility.

- Application tracking and recruitment management for students and recruiters.

- Analytics and reporting dashboards for institutions and industries to monitor placement readiness, recruitment outcomes, and skill demand trends.

Overall Platform Features-

- Role-based access for students, academicians, industries, and institutions.

- Secure document management for resumes, certificates, internship reports, and academic records.

- Collaboration features for industry mentorship, live projects, workshops, and research partnerships.

- Integration with learning platforms, certification providers, and institutional databases.

- Comprehensive analytics to support data-driven decisions for institutions, industries, and policymakers.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26045"></a>[45] SIH26045: IP-SAKTI Sahayak a multilingual, RAG-based (source-cited) AI assistant for Intellectual Property and regulatory guidance in Ayurveda, across national and international regimes.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26045` (SIH26045) |
| **Problem Statement Title** | IP-SAKTI Sahayak a multilingual, RAG-based (source-cited) AI assistant for Intellectual Property and regulatory guidance in Ayurveda, across national and international regimes. |
| **Organization** | Ministry of Ayush |
| **Department** | All India Institute of Ayurveda |
| **Category** | Software |
| **Theme** | Toys & Games |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Ayurveda rests on a vast corpus of codified and community-held traditional knowledge (TK) and on therapeutics derived from plant, microbial and animal sources. Protecting and commercialising an Ayurvedic product means navigating several overlapping regimes at once: patents, geographical indications (GI), trademarks, copyright, designs, trade secrets and plant-variety rights; the Access-and-Benefit-Sharing duties that flow from India's sovereignty over its biological resources; and the drug-regulatory framework that decides whether a formulation is a classical medicine, a proprietary medicine, a new drug, a phytopharmaceutical, a food or a cosmetic. Practitioners, researchers, AYUSH startups and MSMEs and cultivators routinely struggle with this. The result is twofold: legitimate Ayurvedic innovation is under-protected and under-commercialised, while India's traditional knowledge remains exposed to misappropriation abroad. Recent shifts — the 2024 patent and biodiversity rules, the WIPO Treaty on Genetic Resources and Associated Traditional Knowledge (2024) and a fast-moving advertising and regulatory landscape — make authoritative, plain-language guidance more necessary than ever, yet no such tool exists for the AYUSH community.

**Description:**

The assistant answers IPR questions specific to Ayurveda with accuracy, source citation and jurisdictional clarity, keeping the national and the international layers distinct through an explicit jurisdiction switch so that answers are never conflated.

Because intellectual property for an Ayurvedic product is inseparable from how the product is regulated, the assistant first helps classify the formulation. It asks the minimum clarifying questions to determine whether the product is a classical/generic medicine (formulation and method drawn from a First-Schedule authoritative text), a patent-or-proprietary medicine, a new or non-classical drug requiring proof of safety and effectiveness, a phytopharmaceutical, an Ayurveda-Aahar / nutraceutical, or a cosmetic — and then states what each category requires and its very different IP and ABS posture. For example, a classical formulation is largely traditional knowledge that faces the Section 3(p) patenting bar and is defended through the Traditional Knowledge Digital Library, whereas a new drug gains genuine patent potential but must generate clinical evidence.

National coverage spans the Patents Act (and the 2024 Rules), the GI, Trade Marks, Designs, Copyright and Plant-Variety regimes, the Biological Diversity Act (as amended in 2023, with the 2024 Rules) and the allied drug, advertising, labelling and food/cosmetic regimes — the Drugs and Cosmetics Act, the Drugs and Magic Remedies (Objectionable Advertisements) Act and the FSSAI Ayurveda-Aahar regulations. International coverage separately spans TRIPS, the Convention on Biological Diversity and the Nagoya Protocol, the WIPO GRATK Treaty, the PCT, the Madrid and Hague systems, the Budapest Treaty (for micro-organism deposits) and the herbal-product market-access regimes of key export markets.

The assistant also facilitates access to authoritative sources — free official databases directly and the user's own paid subscriptions only with explicit, logged permission — so that a user can move from a question to the right registry, record or form. It must cite the specific statute, rule, treaty article or record it relies on; clearly state that it provides information and not legal advice; keep its corpus current as the law changes; and never fabricate authority.

**Expected solution:**

A deployable, multilingual assistant built on retrieval-augmented generation grounded in a curated, version-tracked corpus of statutes, rules, treaties, pharmacopoeial standards, registry records and case law, so that every answer is traceable to a source and hallucination is minimised. The solution should provide: a jurisdiction toggle (India vs international) with the two answer-sets kept visibly separate; routing across IP types together with the formulation-classification flow; an ABS-compliance helper and a TKDL / prior-art pointer; mandatory source citations with a confidence indicator and a path to escalate to a human IP facilitator; multilingual delivery (leveraging national language infrastructure such as Bhashini); and guardrails, a standing 'information, not legal advice' disclaimer and privacy, audit and security aligned to the Digital Personal Data Protection regime and to recognised AI-application standards. A relational knowledge graph and agentic, multi-source orchestration deepen multi-step reasoning and the build can be staged — a citation-grounded retrieval MVP first, then the graph and agentic layers, then paid-source connectors and the full multilingual and voice experience. The output should be evaluable on answer accuracy, citation correctness, safe abstention on out-of-scope or uncertain queries and multilingual quality.

#### Dataset & Reference Links

**The corpus can be assembled from open, authoritative public sources; representative examples:**

- Traditional Knowledge Digital Library (TKDL) — tkdl.res.in

- Statutes & rules — India Code, indiacode.nic.in

- IP India public databases (patents/InPASS, trade marks, designs, GI Registry) — ipindia.gov.in

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26046"></a>[46] SIH26046: AIIA Clinical Trials Dashboard - a real-time, cloud-based, GCP-compliant Clinical Trial Management System (CTMS) for Ayurveda research, with CDISC/FHIR-interoperable data, role-based KPIs, and integrated ethics, regulatory (CTRI / NDCT Rules 2019) and pharmacovigilance tracking.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26046` (SIH26046) |
| **Problem Statement Title** | AIIA Clinical Trials Dashboard - a real-time, cloud-based, GCP-compliant Clinical Trial Management System (CTMS) for Ayurveda research, with CDISC/FHIR-interoperable data, role-based KPIs, and integrated ethics, regulatory (CTRI / NDCT Rules 2019) and pharmacovigilance tracking. |
| **Organization** | Ministry of Ayush |
| **Department** | All India Institute of Ayurveda |
| **Category** | Software |
| **Theme** | Space Technology |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

The All India Institute of Ayurveda (AIIA) conducts and coordinates a growing portfolio of clinical research in Ayurveda — interventional and observational studies, multi-centre trials — and, as the host of the National Pharmacovigilance Coordination Centre (NPvCC) for ASU&H drugs, it also anchors nationwide safety surveillance. This activity is governed by a demanding compliance framework: mandatory prospective registration in the Clinical Trials Registry – India (CTRI); the Good Clinical Practice guidelines for ASU medicine (GCP-ASU) and the ICMR National Ethical Guidelines; the New Drugs and Clinical Trials Rules, 2019 where applicable; Institutional Ethics Committee oversight; and timely Adverse-Event / Serious-Adverse-Event reporting. Yet study status, recruitment, milestones, data quality and safety signals are typically tracked across spreadsheets and disconnected tools, with no single, real-time, auditable view. The result is delayed decisions, missed reporting timelines and avoidable compliance risk — precisely as Ayurveda research scales and seeks global scientific credibility.

**Description:**

The platform is a real-time, cloud-based Clinical Trial Management System (CTMS) and monitoring dashboard that gives AIIA a single, role-based, auditable view of its entire clinical-research portfolio.It tracks each study across its lifecycle — protocol and Institutional Ethics Committee approval, CTRI registration, site activation, screening, enrolment and randomization against target, visit and protocol-deviation compliance, data-query and data-quality status, study milestones and timelines, and close-out — surfaced as real-time Key Performance Indicators (KPIs) with configurable alerts (for example, enrolment lag, an ethics approval or CTRI update due, or an overdue monitoring visit).Because AIIA hosts the NPvCC, the dashboard integrates pharmacovigilance: it captures and routes Adverse Drug Reaction / Adverse-Event / Serious-Adverse-Event reports against regulatory reporting timelines, coded to standard dictionaries (MedDRA, WHODrug), and feeds aggregate safety signals to the Data Safety Monitoring Board and institutional leadership.Data must follow recognised clinical-research standards — CDISC (CDASH for data collection, SDTM for tabulation, ADaM for analysis) and HL7 FHIR R4 for interoperability with Electronic Data Capture (EDC), the hospital information system and Ayushman Bharat Digital Mission (ABDM) building blocks — with full ALCOA+ data integrity and an immutable, time-stamped audit trail. Access is strictly role-based (Principal Investigator, study coordinator, monitor, Ethics Committee, pharmacovigilance, administration, and read-only regulator views).The platform must comply with GCP-ASU, the ICMR ethical guidelines, the NDCT Rules 2019 and CTRI requirements, and with the Digital Personal Data Protection Act, 2023 and its 2025 Rules — including informed-consent management, data minimisation, encryption, and hosting on compliant, data-resident cloud infrastructure secured to ISO/IEC 27001 and CERT-In norms, since clinical-trial data is sensitive personal data.**Expected solution:**

A deployable, cloud-based CTMS-and-analytics dashboard providing: a real-time portfolio view with per-study drill-down; configurable KPIs and alerting; strictly role-based access and an immutable, ALCOA+-compliant audit trail; CDISC-aligned data models and HL7 FHIR R4 / ABDM interoperability with EDC and the hospital information system; an integrated pharmacovigilance module (AE/SAE capture, MedDRA/WHO Drug coding, regulatory-timeline tracking) reflecting AIIA's NPvCC role; CTRI and ethics/regulatory milestone tracking; informed-consent and privacy controls aligned to the DPDP regime; electronic-signature and data-integrity controls consistent with GCP; and the ability to export submission-ready datasets (SDTM / ADaM, Define-XML). It should present tailored dashboards for Investigators, the Ethics Committee, pharmacovigilance and institutional leadership, and be hosted on secure, data-resident cloud infrastructure (ISO/IEC 27001, CERT-In). The build can be staged — a core study-tracking and KPI MVP first, then EDC/FHIR integration and the pharmacovigilance module, then full CDISC submission export and advanced analytics. The system should be evaluable on data accuracy and integrity, timeliness of safety and regulatory reporting, interoperability conformance, and access-control and audit completeness.

#### Dataset & Reference Links

Clinical-trial data is sensitive personal data, so development should use synthetic / de-identified datasets; representative standards and public sources:

- Clinical Trials Registry – India (public trial records) — ctri.nic.in

- CDISC standards & controlled terminology (CDASH, SDTM, ADaM, Define-XML) — cdisc.org

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26047"></a>[47] SIH26047: Patient Case-Taking Software

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26047` (SIH26047) |
| **Problem Statement Title** | Patient Case-Taking Software |
| **Organization** | Ministry of Ayush |
| **Department** | All India Institute of Ayurveda |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

1.1 The Clinical History-Taking Bottleneck in Indian Hospitals History taking — the structured elicitation of a patient's presenting complaints, history of present illness, past medical and surgical history, drug and allergy history, family and personal history, and a review of systems — is the single most important diagnostic activity in clinical medicine. Classical teaching holds that a well-conducted history yields the correct diagnosis in 70–80% of cases, even before examination or investigation. Yet in India's overburdened public hospital outpatient departments (OPDs), the time available for this critical interaction has collapsed to unsustainable levels.

India operates one of the most patient-dense healthcare systems in the world. Tertiary government hospitals and apex institutions routinely register 4,000–10,000 OPD patients per day, with a doctor-to-patient consultation time frequently reported between 2 and 5 minutes — among the shortest globally (study published in BMJ Open, 2017, across 67 countries placed India's average primary-care consultation at just over 2 minutes). Within this window, the physician must simultaneously elicit history, examine the patient, review prior records, formulate a diagnosis, counsel, and prescribe. The result is systematic under-elicitation of history, missed comorbidities, repeated questioning across visits, and diagnostic error.

AYUSH institutions face an additional layer of complexity. Ayurvedic history taking (Trividha, Ashtavidha, and Dashavidha Pariksha) requires detailed assessment of Prakriti (constitution), Vikriti (current imbalance), Agni (digestive capacity), Koshtha (bowel nature), Ahara-Vihara (diet and lifestyle), Nidana (causative factors), and Samprapti (pathogenesis) — a far more extensive history framework than allopathic intake. Capturing this depth manually within OPD time constraints is effectively impossible, forcing practitioners to abbreviate the very assessment that defines personalized Ayurvedic care.

1.2 The Documentation and Records Fragmentation Problem Compounding the time problem is the fragmentation of patient records. Patients in India typically carry physical paper prescriptions, laboratory reports, discharge summaries, and imaging films from multiple prior providers. During consultation, the physician must manually scan through these unstructured documents — often handwritten, in varying languages, and chronologically disordered — consuming a significant fraction of the already-scarce consultation time. There is no point-of-entry mechanism to digitize, structure, and chronologically organize a patient's prior medical documents before they reach the consultation room.

The Ayushman Bharat Digital Mission (ABDM) has established the national digital health infrastructure — ABHA (Ayushman Bharat Health Account) IDs, the Health Information Exchange, and FHIR-based interoperability standards. However, the 'first-mile' problem remains unsolved: there is no efficient, patient-facing software platform that captures structured history and digitizes documents into the ABDM ecosystem before the clinical encounter begins.

1.3 The Opportunity: AI-Powered Digital Clinical Intake Platform Self-service kiosks have transformed high-throughput service industries — ATMs in banking, self-check-in terminals in aviation, and ordering kiosks in quick-service restaurants — by offloading structured data-entry tasks from human staff to the user, dramatically improving throughput and accuracy. In healthcare, patient check-in kiosks are now widespread in developed-country hospitals, but these are limited to administrative check-in. None perform deep, AI-driven, multimodal clinical history acquisition with medical document digitization.

The convergence of mature enabling technologies — robust automatic speech recognition (ASR) for Indian languages and accents (Bhashini / AI4Bharat models), large language models for conversational clinical history elicitation, high-accuracy OCR for handwritten and printed medical documents, and ABDM's FHIR interoperability — now makes it feasible to build an AI-powered clinical history software platform.

**Description:**

2.1 The Problem in Precise Terms There is no purpose-built, patient-facing software platform that enables patients to independently and comprehensively record their medical history — through both natural spoken conversation and guided touchscreen interaction — and simultaneously digitize their existing physical medical documents, generating a structured, physician-ready clinical history summary that integrates with the hospital information system and the ABDM ecosystem before the patient enters the consultation room.

2.2 Why Existing Solutions Fall Short

- Existing hospital registration systems (currently deployed in some Indian hospitals) capture only demographic and appointment data — name, age, department, token number. They do not elicit any clinical history or process medical documents.

- Mobile health apps and tele-triage chatbots require smartphone literacy, stable connectivity, and patient enrolment ahead of the visit — excluding the large elderly, rural, low-literacy, and first-visit patient populations who form the bulk of government hospital OPD load.

- Manual nurse-led triage / history desks are themselves human-resource-limited, do not scale to 5,000+ daily patients, and reintroduce the same time and transcription bottleneck the system is trying to eliminate.

- Generic document scanners digitize images but do not extract, structure, or chronologically organize clinical content, nor link it to a structured history or ABHA record.

2.3 Specific Challenges a Solution Must Overcome

- Multilingual, multi-accent voice capture in noisy hospital environments across Hindi, English, and major regional languages, for patients of varying literacy and digital comfort.

- Accessibility for low-literacy and elderly users through intuitive icon-driven UI, audio prompts, and conversational guidance — the software platform must be usable by a first-time, non-tech-savvy patient with zero training.

- Accurate clinical history structuring converting free-form patient narration into a standardized, physician-readable history (chief complaint, HPI, past history, drug/allergy, family, personal, review of systems) — and, for AYUSH settings, Dashavidha Pariksha parameters.

- Reliable medical document digitization OCR of handwritten and printed prescriptions, lab reports, and discharge summaries in multiple languages, with intelligent extraction of diagnoses, medications, and investigation values.

- Privacy, consent, and data security compliance with the Digital Personal Data Protection Act 2023 and ABDM consent framework — handling sensitive health data within a secure software environment.

**Expected solution:**

3.1 Solution Overview — 'MediKiosk' AI Clinical History Software Platform The proposed solution — tentatively designated MediKiosk — a software platform for an AI-powered clinical history software platform that allows any patient to record a comprehensive medical history through natural voice conversation and guided touchscreen interaction, scan and digitize their existing physical medical documents, and generate a structured, physician-ready clinical history summary that is pushed to the hospital information system (HIS) and linked to the patient's ABHA record — all completed before the consultation, with minimal staff assistance required.

- Insert Table*3.2 3.3 Software & AI Stack (Integrated)

Module A — Conversational Multimodal History Engine A conversational AI engine that conducts a structured clinical history interview through both voice and touch. The patient speaks naturally in their preferred language; the engine asks intelligent follow-up questions (e.g., on stating 'chest pain', it probes onset, character, radiation, aggravating/relieving factors — the SOCRATES framework) and simultaneously offers touch-based multiple-choice options for patients who prefer tapping. Built on Indian-language ASR, a dialogue manager constrained by a clinical history ontology, and text-to-speech for audio prompts.

- Adaptive questioning: dynamically branches based on chief complaint and prior answers, mirroring a physician's clinical reasoning to elicit a complete HPI and review of systems

- Dual-mode input: every question answerable by speaking OR tapping, ensuring usability across literacy and comfort levels

- AYUSH history mode: for Ayurvedic OPDs, an extended interview capturing Dashavidha Pariksha (Prakriti, Vikriti, Sara, Samhanana, Pramana, Satmya, Sattva, Ahara Shakti, Vyayama Shakti, Vaya) and Ahara-Vihara assessment

- Red-flag detection: AI flags emergency symptoms (e.g., acute chest pain with dyspnoea, stroke symptoms) and triggers immediate priority alert to triage staff rather than routine queueing Module B — Medical Document Digitization & Intelligence An integrated scanning and document-AI pipeline that allows the patient to upload prior prescriptions, lab reports, and discharge summaries. The system performs high-accuracy OCR (printed and handwritten, multilingual), then extract and structure clinical entities.

- Intelligent extraction: diagnoses, prescribed medications with dosages, investigation results with values and reference ranges, and procedure/surgery history

- Chronological organization: automatically dates and orders documents into a coherent medical timeline for the physician

- Abnormal-value highlighting: flags out-of-range lab values and potential drug interactions for physician attention Module C — Structured History Summary Generator An AI summarization engine that synthesizes the conversational history and the digitized documents into a single, concise, physician-ready clinical summary in standard format — presented on the consultation screen the moment the patient enters the room. The physician reads a complete, structured history in seconds rather than spending minutes eliciting it, and can edit/confirm before saving.

- Standard clinical format: Chief complaint ? HPI ? Past medical/surgical ? Drug & allergy ? Family ? Personal ? ROS ? Prior investigations summary

- Editable & verifiable: physician retains full control — the summary is a draft to accept, amend, or reject, never an autonomous diagnosis

- Bilingual output: patient-facing audio confirmation in local language; physician-facing summary in English/Hindi Module D — Consent, Privacy & ABDM Integration A robust consent and security layer compliant with the Digital Personal Data Protection Act 2023 and the ABDM consent framework. The patient authenticates via ABHA ID, grants explicit consent for data capture and sharing, and the structured history is pushed to the hospital HIS/EMR and linked to the ABHA Personal Health Record via FHIR APIs.

- Secure processing: voice and document AI are processed securely within the software platform

- Session termination: temporary session data is cleared immediately after submission

- Consent-first design: granular, revocable consent with audio explanation for low-literacy patients 3.4 End-to-End Patient Journey

- Step 1 — Identify: Patient logs into the software platform, enters/scans ABHA ID or Aadhaar details or registers as new; selects language; grants consent (audio-guided)

- Step 2 — Converse: AI conducts adaptive voice + touch history interview, capturing chief complaint, HPI, and full history; red flags trigger priority triage

- Step 3 — Scan: Patient uploads prior prescriptions, lab reports, and discharge summaries; AI digitizes, structures, and timelines them

- Step 4 — Summarize & Route: AI generates structured history summary, links to ABHA, pushes to HIS, updates the patient's digital record; summary appears on physician's screen at consultation

- Step 5 — Consult: Physician reviews complete history in seconds, edits/confirms, and devotes the full consultation to examination, reasoning, and counselling

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26048"></a>[48] SIH26048: iKwath - a pod-based smart Kwatha (Kadha) maker that prepares a fresh, AFI/API-standardized decoction from coarse powder (yavaku?a c?r?a) on demand, in the shortest practical time without altering the decoctions quality or yield

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26048` (SIH26048) |
| **Problem Statement Title** | iKwath - a pod-based smart Kwatha (Kadha) maker that prepares a fresh, AFI/API-standardized decoction from coarse powder (yavaku?a c?r?a) on demand, in the shortest practical time without altering the decoctions quality or yield |
| **Organization** | Ministry of Ayush |
| **Department** | All India Institute of Ayurveda |
| **Category** | Hardware |
| **Theme** | Fitness & Sports |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Kwatha (kashaya / kadha) is among the most widely used Ayurvedic dosage forms and is most effective when freshly prepared, yet a fresh decoction must be consumed within a few hours, is laborious to make correctly, and needs a slow reduction step that limits convenience. Consumers therefore depend on concentrated, shelf-stable products that lose potency and are prone to adulteration. Preparing a standardized decoction at home — with the correct powder grade, water proportion, gentle heat and reduction defined by the pharmacopoeia — is impractical by hand, and no appliance does it for the range of Ayurvedic formulations in use.

**Description:**

The system is a compact, pod-based countertop appliance that prepares one fresh dose of Kwatha on demand for any formulation, for use at home or in Ayurvedic clinics. Each single-dose pod contains the standardized coarse powder (yavaku?a c?r?a) of one formulation and serves as the brew-bag, so the decoction stays clear and the spent powder is removed with the pod; a different formulation is handled simply by changing the pod.

To prepare a dose, the user adds water and inserts a pod; the appliance soaks the powder, boils it at a controlled mild temperature (~85–90 °C), reduces the liquid to one-fourth, filters it, and dispenses a single fresh, warm decoction, ready to drink. The water volume, boil profile and dose follow the formulation's AFI/API specification encoded on the pod, and the appliance monitors weight and extract density so every dose is consistent. Because each dose is brewed only when needed, it is always consumed fresh.

A central objective is to shorten the preparation cycle as far as practical while delivering a decoction identical to the classical preparation in both its constituent profile (qualitative) and its extractive yield (quantitative).

Each cycle uses about 400 mL of water to yield a single ~100 mL dose, in a boiling chamber of about 1 litre. Pods are single-dose and supplied in course packs.

The appliance is designed for easy cleaning: a removable, dishwasher-safe boiling chamber and filter, a disposable spent-powder pod, smooth food-grade stainless-steel contact surfaces, and a rinse cycle. It includes anti-boil-over and dry-run protection and uses potable water meeting the API Jala standard.

**Expected solution:**

A deployable, pod-based Kwatha appliance that reads each single-dose pod's formulation profile and automatically prepares a fresh, standardized dose — soaking, boiling at controlled mild heat (~85–90 °C), reducing the liquid to one-fourth, filtering, and dispensing — with easy, tool-free cleaning. The solution must minimise the preparation time without altering the final decoction: any acceleration has to be validated to reproduce the classically prepared decoction's extract density and constituent profile, holding the AFI/API water proportion and reduction endpoint constant. Acceptable approaches are those that preserve the mild process temperature and the dissolved extractive — for example, a larger evaporating surface, gentle removal of surface vapour, continuous stirring or recirculation, or reduced-pressure (lower-temperature) evaporation — while methods that could change the phytochemical profile are avoided. Pods of standardized coarse powder (yavaku?a c?r?a) are certifiable against the API/AFI by AIIA/PCIM&H. The solution should be evaluable on dose consistency and conformance to the AFI/API specification, temperature control, cycle time, ease of cleaning, and food-grade safety.

#### Dataset & Reference Links

**Standards and references for the pod profiles and the extraction logic; representative sources:**

- PCIM&H AYUSH Kv?tha C?r?a formulary specifications (coarse-powder grade, water proportion, dose, reduction) — pcimh.gov.in

- Ayurvedic Pharmacopoeia of India (API) & Ayurvedic Formulary of India (AFI) kwatha-churna m

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26049"></a>[49] SIH26049: Modifications to improve the reliability, efficiency,and lifespan of electrical and electronic equipment and systems in the ambient condition of subzero temperature and low pressure of High Altitude Areas(HAA) and Super High Altitude Areas (SHAA) of Ladakh region.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26049` (SIH26049) |
| **Problem Statement Title** | Modifications to improve the reliability, efficiency,and lifespan of electrical and electronic equipment and systems in the ambient condition of subzero temperature and low pressure of High Altitude Areas(HAA) and Super High Altitude Areas (SHAA) of Ladakh region. |
| **Organization** | DRDO |
| **Department** | Department of Defence Production /IDEX |
| **Category** | Hardware |
| **Theme** | Heritage & Culture |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

High Altitude Areas (HAA) and Super High Altitude Areas (SHAA) of Ladakh region presents one of the harshest operating environments for electronic equipment and systems because of its extreme cold, low atmospheric pressure, intense solar/UV radiation and large temperature variations between day and night. These environmental conditions strongly affect the reliability, efficiency, and lifespan of electrical and electronic systems.

**Description:**

Ladakh is a cold desert located at elevations of approximately 3000 to 6000m above sea level. There are several environmental challenges viz. very low temperatures (-35°C to 40°C in winters), low atmospheric pressure, lower partial pressure of oxygen, low humidity, snow, ice and occasional moisture condensation. These conditions pose serious operational and storage issues of electrical and electronic equipment and systems and following effects on same is observed:

1. Reduced Cooling Efficiency: At high altitude, air density decreases significantly. Thin air removes heat less effectively (degradation of convective cooling), so electronic components run hotter even when ambient temperature is cold. This means overheating of processors, reduced efficiency of cooling fans and heat sinks, thermal stress on semiconductors and premature component failure. Systems being affected are computers and servers, telecom base stations, radar system, power electronics, military communication systems.

2. Insulation Breakdown and Electrical Arcing: Low atmospheric pressure reduces the dielectric strength of air. Air becomes a weaker insulator, increasing the risk of sparking and arcing between conductors.

3. Battery Performance Degradation: Cold temperatures severely affect battery chemistry. Lithium-ion and lead-acid batteries lose capacity and discharge faster in freezing conditions. Owing to this there is reduced backup time, slow charging and voltage instability.

4. Thermal Cycling Damage: Ladakh experiences large temperature variation between day and night. Repeated expansion and contraction develop mechanical stresses in the components. This result in cracking of solder joints, PCB warping etc.

5. Increased Radiation Exposure: Higher altitude means thinner atmospheric shielding, so electrical and electronic components receive more UV radiation and cosmic rays. This means semiconductor degradation, memory bit error and failure of sensitive sensors.

6. Effects on Communication Systems: High Mountains and severe weather affect signal propagation. There are problems like signal attenuation and reflection, antenna icing. Because of these cellular networks, satellite communication and military radio system get affected.

7. Real-World Impact: The Drone Challenge: The Indian Army's extensive use of drones along the LAC highlights these exact issues. In the thin air of Ladakh, drone rotors generate less lift, forcing the electronic motors to work much harder and draw more current. Combined with cold-induced battery drain, drones that fly for an hour at sea level might only manage 20-25 minutes of flight time in Ladakh

**Expected Solution:**

The environment of Ladakh significantly affects electrical and electronic equipment due to low atmospheric pressure, extreme cold, high UV/cosmic radiation, dust and dryness, and large thermal variations. These conditions can cause overheating, insulation failure, battery degradation, display malfunction, communication instability, and reduced reliability. Therefore, electrical and electronic equipment and systems used in Ladakh require specialized design modifications to improve the reliability, efficiency, and lifespan.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26050"></a>[50] SIH26050: High Altitude Performance Optimization and Robust Design of Anti-Drone System.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26050` (SIH26050) |
| **Problem Statement Title** | High Altitude Performance Optimization and Robust Design of Anti-Drone System. |
| **Organization** | DRDO |
| **Department** | Department of Defence Production /IDEX |
| **Category** | Hardware |
| **Theme** | MedTech / BioTech / HealthTech |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Anti-drone systems are deployed for detection, tracking, identification and neutralization of unauthorized drones threatening strategic, defence and critical infrastructure assets. The operational performance of anti-drone systems is generally optimized for standard environmental conditions;

however, their behavior changes significantly in high altitude regions.

High altitude environments are characterized by extreme cold temperatures, low atmospheric pressure, reduced air density, dust, snow, and high wind conditions. These factors influence the performance of mechanical, electrical, electronic, RF, electro-optical and stabilization subsystems. Components such as cables, motors, connectors, bearings, batteries, sensors and precision positioning mechanisms may experience altered material properties, increased rigidity, thermal stresses and degraded operational characteristics.

For precision systems requiring micro-radian level pointing, tracking and stabilization accuracy, even minor changes in cable flexibility, structural dynamics, lubrication properties and component response can lead to significant degradation in system performance. Therefore, there is a requirement to develop an anti-drone system with suitable design methodologies and component selection approaches to ensure reliable performance in harsh high-altitude operational conditions.

**Description:**

The above statement envisages the development of a high-altitude capable antidrone system with robust environmental tolerance and sustained operational effectiveness under extreme climatic and atmospheric conditions.

The system shall assess the impact of low temperature, low pressure, dust ingress, high wind loads, thermal cycling and reduced atmospheric density on overall system performance and develop suitable mitigation methodologies.

- A portable or deployable anti-drone system architecture with optimized mechanical, electrical, RF and electro-optical subsystems shall be developed. The system shall incorporate:

- Robust design methodologies for maintaining detection, tracking and engagement accuracy at high altitude.

- Suitable component selection and qualification for reliable operation in harsh environments.

- Compensation mechanisms for environmental effects impacting system dynamics, stabilization, pointing accuracy and sensor performance.

- Thermal management and environmental protection methodologies for critical components and subsystems.

- Adaptive control algorithms, health monitoring techniques and predictive performance assessment methods to minimize environmental impact on operational capability.

Special emphasis shall be given to understanding and compensating the influence of temperature-induced cable rigidity, component derating, structural deformation, wind disturbances and sensor drift, particularly in systems demanding high precision pointing and tracking performance.

**Expected Solution:**

Development of a robust anti-drone system optimized for high-altitude operation, incorporating:

- Environmental hardening and ruggedized system design suitable for extreme cold, low pressure, dust and high wind conditions.

- Appropriate component selection, qualification and validation methodologies for high-altitude deployment.

- Compensation techniques to minimize environmental effects on system stabilization, pointing accuracy, tracking performance and sensing capability.

- Thermal control, protective packaging and subsystem reliability enhancement measures.

- Modelling, simulation and field evaluation methodologies for assessing antidrone system performance under representative high-altitude operational scenarios.

The final system should demonstrate reliable detection, identification, tracking and neutralization capability with minimal performance degradation under high-altitude environmental conditions, while maintaining the desired operational intent and precision requirements.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26051"></a>[51] SIH26051: Software Based Model Development for Design of Area Specific Shelter for Thermal Comfort Maintenance.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26051` (SIH26051) |
| **Problem Statement Title** | Software Based Model Development for Design of Area Specific Shelter for Thermal Comfort Maintenance. |
| **Organization** | DRDO |
| **Department** | Department of Defence Production /IDEX |
| **Category** | Software |
| **Theme** | Agriculture, FoodTech & Rural Development |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

The ambient atmospheric condition affects the temperature inside the shelter and makes thermal management necessary for maintenance of temperature in the comfortable range. The existing shelters for any region are generally not designed as per the requirements of a particular region and hence not energy efficient thus demands external thermal comfort maintenance system. Area specific designed shelters looks smart and one time solution for thermal management as per the atmospheric condition of the region.

This model development project work is specifically conceptualised keeping in mind the tough climatic condition of High Altitude cold Region like Ladakh and can be used for studying the design requirements of other climatic region shelters as well.

**Description:**

The Ladakh region is blessed with high solar energy irradiance (1900-2100 kwh/m2/year) along with long average sunshine duration of 7.9 hours with 300 plus average annual cloud free days. The temperatures inside the shelters found suitable during day hours even during the winter period due to trapping of thermal energy from solar radiation, but approach nearly the ambient atmospheric temperature after sunset. High thermal losses through the material of the shelter and openings contributed towards such low temperature inside shelters.

A detailed thermal analysis of the shelter including size, shape orientation etc.

along with, study related to application of suitable materials and application of thermal mass storage material, composite multi-material etc. and effect of openings on outcome looks to be a potential solution for development of self-sufficient passive shelter for the region in terms of temperature maintenance.

A general model development in ANSYS software to thermally simulate the shelter for study of heat losses and capture of real time atmospheric ambient climatic condition data will prove to be helpful. The project is conceptualised for the development of general model in ANSYS software. The model should be user friendly and works on user defined values (real time data, material properties etc.)to simulate the cases along with comparative analysis with different materials under same ambient condition to predict the most efficient combination of materials, shape, and size etc.in terms of temperature maintenance.

The primary objective of the work/project is to minimize the energy utilisation for thermal comfort maintenance in particular and minimization of fossil fuel application in general by designing of area specific self-sustained standalone passive shelter at defined atmospheric climatic condition.

**Expected Solution:**

Development of Software based model for predicating the suitable shelter design including suitable material, size, shape etc. with the objective of thermal comfort maintenance in passive shelter installed in different atmospheric conditions. This work involves simple feeding of collected data and material properties in developed model and outcome shows in terms of most efficient design with materials for thermal comfort maintenance in a particular region The Developed Model should be capable of giving/solving the following tasks:

1. Prediction of shelter inside temperature based on the user defined inputs.

2. Prediction of thermal energy generated from solar radiation.

3. Heat flow details as per the temperature difference between ambient and shelter temperature for a defined time period.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26052"></a>[52] SIH26052: To develop an AI/ML-enabled adaptive noise cancellation (ANC) system that effectively suppresses stationary, non-stationary, and impulsive defence noises while maintaining high speech intelligibility and real-time performance on embedded hardware.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26052` (SIH26052) |
| **Problem Statement Title** | To develop an AI/ML-enabled adaptive noise cancellation (ANC) system that effectively suppresses stationary, non-stationary, and impulsive defence noises while maintaining high speech intelligibility and real-time performance on embedded hardware. |
| **Organization** | DRDO |
| **Department** | Department of Defence Production /IDEX |
| **Category** | Hardware |
| **Theme** | Smart Vehicles |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

In defence and mission-critical communication systems, reliable speech transmission is severely affected by diverse acoustic disturbances such as gunshots, artillery fire, helicopter rotor noise, armored vehicle sound and emergency sirens. Traditional signal processing techniques—like spectral subtraction, Wiener filtering, and classical LMS-based ANC—are limited in handling highly dynamic and non-linear noise environments. These methods assume stationary noise characteristics and often introduce artifacts or speech distortion under rapidly changing conditions.

Recent advancements in Artificial Intelligence and Machine Learning (AI/ML)

have transformed the field of speech enhancement and ANC. Deep learning models and time-domain architectures are capable of learning complex spectral-temporal patterns directly from data. These models significantly outperform conventional approaches in terms of perceptual quality (PESQ), intelligibility (STOI), and noise suppression (SNR). Additionally, the rise of edge AI platforms enables deployment of such models on embedded systems for real-time applications.

**Description:**

The proposed system integrates AI/ML-driven noise suppression with adaptive filtering to create a robust ANC pipeline. The development begins with dataset generation, where clean speech data is combined with curated defence noise datasets (gunshots, drones, artillery, vehicle engines, wind, etc.)

at varying SNR levels. This synthetic data generation ensures coverage of both stationary and impulsive noise scenarios.

The training pipeline involves transforming audio into time-frequency representations (e.g., STFT spectrograms) or directly using raw waveform inputs. Models process both full-band and sub-band features to capture global and local dependencies. while its also operates in the complex domain to preserve phase information. Training is performed using loss functions such as SI-SNR, L1/L2 loss, and perceptual loss, with evaluation metrics including SNR, STOI, and PESQ. Data augmentation techniques (random noise mixing, reverberation, clipping) are applied to improve generalization.

During inference, the trained model processes incoming noisy audio in real time, estimating a mask or directly reconstructing enhanced speech. The system can optionally include a lightweight adaptive filter (e.g., LMS) for residual noise suppression.

For prototype demonstration, the trained model is deployed on embedded/edge hardware such as DSPs or AI-enabled SoCs (e.g., NVIDIA Jetson AGX Orin 64GB Developer Kit or similar platforms). Optimization techniques like quantization, pruning, and ONNX / TensorRT conversion are applied to meet latency and power constraints. The system is integrated with microphones (primary + reference) and headphones/communication units to validate real-time ANC performance in practical environments

**Expected Solution:**

The final solution is a hybrid AI-driven ANC system capable of operating in real-time and handling diverse noise environments, including impulsive and highly dynamic defence scenarios. It should include:

- A scalable dataset pipeline for generating realistic noisy-clean speech pairs

- A state-of-the-art AI/ML model trained for robust noise suppression

- A training framework with optimized hyper-parameters and perceptual loss functions

- A real-time inference engine deployable on edge hardware

- A prototype system demonstrating live noise cancellation using microphones / headset integration The system is expected to achieve significant performance improvements, targeting SNR > 15 dB, STOI > 0.85, and PESQ > 2.5, while maintaining low latency suitable for real-time communication. This solution will enable reliable and intelligible communication in defence, aerospace, and high-noise industrial environments.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26053"></a>[53] SIH26053: Adaptive Variable Resolution 2.5D Lidar Mapping for Dynamic Environment Perception

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26053` (SIH26053) |
| **Problem Statement Title** | Adaptive Variable Resolution 2.5D Lidar Mapping for Dynamic Environment Perception |
| **Organization** | DRDO |
| **Department** | Department of Defence Production /IDEX |
| **Category** | Software |
| **Theme** | Transportation & Logistics |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Autonomous navigation depends on the ability of a vehicle to perceive its surroundings with high precision. While 3D Lidar point clouds provide rich spatial data, processing millions of points in real-time creates immense computational bottlenecks and memory latency. Conversely, standard 2D occupancy grids lose critical height information necessary for detecting curbs, potholes, or overhanging obstacles. To balance precision and performance, there is a need for a 'foveated' mapping approach—similar to human vision— where the immediate vicinity is rendered in high detail for safety, and distant areas are simplified to reduce the processing load.

**Description:**

The goal is to build a deep learning pipeline that transforms raw Lidar point clouds into a variable resolution 2.5D grid (an elevation map with semantic layers). The system must perform three primary tasks:

1. Terrain Analysis: Distinguish between drivable surfaces and non-drivable terrain.

2. Object Detection: Identify and classify static obstacles (walls, poles) and dynamic objects (pedestrians, other vehicles).

3. Adaptive Spatial Representation: Implement a non-uniform grid where the cell size increases as the distance from the sensor increases. This requires a sophisticated data structure that can handle variable resolution without causing alignment errors or data loss during the projection from 3D to 2.5D.

**Expected Solution:**

**A software framework consisting of:**

- A Deep Learning Model: A network (e.g., PointNet++ or a Sparse Convolutional Neural Network) capable of semantic segmentation of point clouds into terrain, static obstacles, and moving objects.

- Variable Resolution Grid Engine: An algorithm that projects classified 3D points into a 2.5D grid where the resolution is high (e.g., 5cm cells)

within a 10m radius and decreases (e.g., 50cm cells) up to a 100m radius.

- Real-time Visualization: A dashboard showing the 2.5D map with distinct color-coding for terrain and objects, demonstrating a significant reduction in memory usage compared to a uniform high-resolution 3D map.

- Performance Metrics: Evidence of low latency (high FPS) and high accuracy in object classification across varying distances.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26054"></a>[54] SIH26054: AI-Enabled Real-Time Digital Twin System for Health Monitoring, Fault Prediction and Mission Reliability Enhancement of Aero Piston Engines used in MALE UAVs.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26054` (SIH26054) |
| **Problem Statement Title** | AI-Enabled Real-Time Digital Twin System for Health Monitoring, Fault Prediction and Mission Reliability Enhancement of Aero Piston Engines used in MALE UAVs. |
| **Organization** | DRDO |
| **Department** | Department of Defence Production /IDEX |
| **Category** | Software |
| **Theme** | Robotics and Drones |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Medium Altitude Long Endurance (MALE) UAV are increasingly being deployed for Long-duration intelligence, surveillance, reconnaissance (ISR).

Communication relay maritime surveillance and strategic defence missions Reliability and availability of propulsion systems are critical for mission success because piston-engine failures during flight may lead to mission abort, asset loss, or unsafe recovery conditions.

Conventional engine monitoring systems used in UAVs are primarily thresholdbased and reactive in nature. These systems generally indicate failures only after abnormality has already occurred. Present approaches also have limited capability to estimate remaining useful life (RUL) predict degradation trends, or simulate mission-wise engine behavior under varying environmental and operating conditions.

A Digital Twin (DT) framework for aero piston engines can significantly improve predictive maintenance, operational reliability, mission planning, and life cycle management by creating a continuously synchronized virtual representation of the physical engine using real-time sensor data physics-based models and AI/ML techniques.

The proposed problem aims to develop an indigenous Digital Twin framework suitable for deployment in MALE UAV ground control and health monitoring architecture. The solution should support real-time engine state estimation, anomaly detection degradation tracking, faultprediction, and mission replay capability.

**Description:**

Develop a scalable and modular digital Twin System for an aero piston engine used in MALE UAV applications. The system shall create a real-time virtual representation of the engine by integrating.

- Engine sensor data

- Thermodynamic behavior models

- Engine performance maps

- Failure/degradation logit

- AI/ML based predictive analytics The proposed system should be capable of:

- Real-time engine parameter visualization

- Monitoring of engine health indicators

- Defection of abnormal operating conditions

- Predicting probable failures before occurrence

- Estimating degradation trends and Remaining Useful Life (RUL)

- Simulating engine behavior under different mission profiles and environmental conditions

- Supporting post-flight analysis and mission replay The system may utilize

- CAN bus/Socket CAN-based engine data acquisition

- ECU/FADEC communication interfaces Edge computing architecture Cloud or local server-based analytics

- AI/ML algorithms far anomaly detection

- Physics informed modelling approaches

- Dash board/HMI for operators and maintenance engineers

**Expected Solution:**

The digital twin core framework shall act as the central intelligence layer that continuously mirrors the real aero-piston engine operating onboard the MALE UAV. The framework should establish a dynamic and continuously synchronized virtual representation of the engine using live telemetry, physicsbased models, operational history and AI-Driven analytics. The framework should be designed considering future deployment in defence grade Ground Control Station (GCS), engine test rigs, and fleet-level health monitoring infrastructures. The expected solution should include:

A. Digital Twin Core Framework

- Virtual engine model synchronized with live engine data

- Modular architecture for future scalability

- Real-time data ingestion capability B. Health Monitoring System: The health monitoring system shall continuously assess the condition of engine sub-systems and generate health indices for predictive maintenance. Monitoring of following engine parameter are required:

- RPM

- Cylinder Head Temperature (CHT)

- Exhaust Gas Temperature (EGT)

- Oil Pressure & Temperature

- Fuel flow

- Vibration signatures

- Battery Alternator health

- Injection timing parameters C. Fault Detection & Predictive Analytics: The system should transition from conventional threshold-based monitoring to intelligent predictive diagnostics. The detection/prediction of following parameters are required:

- Misfire conditions

- Injector abnormalities

- Coding degradation

- Lubrication issues

- Sensor drift/ failure

- Combustion instability

- Overheating trends

- Abnormal vibration patterns D. AE/ML Layer: The AI/ML layer shall provide adaptive learning capability for predictive diagnostic and intelligent maintenance planning. Following parameters are required to be captured:

- Anomaly detection algorithms

- Remaining Useful Life (RUL) estimation

- Trend analysis

- Predictive maintenance recommendations E. Simulation & Replay Capability: The system should include simulation tools to reproduce engine behavior and analyses mission scenarios. Following parameters are required to be captured:

- Replay of historical mission data

- Environmental condition simulation

- Engine behavior simulation during

- High Altitude

- Endurance mission

- Hot-weather operation

- Rapid throttle transitions F. Visualization Dashboard: The dashboard shall provide an intuitive operational interface for UAV operators, propulsion engineers and maintenance team. A user Interface displaying dashboard should support following:

- Real-time engine health status

- Fault alerts

- Engine efficiency trends

- Maintenance advisory

- Mission-wise health reports Deliverables Expected from Teams:

- Functional prototype/software demonstrator

- Digital twin architecture design

- Engine Simulation model

- AI/ML-based anomaly detection module

- Visualization dashboard

- Demonstration using simulated or real engine datasets

- Technical documentation and deployment roadmap Desired Innovation Areas: Participants are encouraged to explore:

- Physics-informed AI

- Edge AI for UAV applications

- Lightweight onboard analytics

- Hybrid thermodynamic + data-driven models

- Federated learning approaches

- Explainable AI for fault diagnosis

- Secure telemetry architecture

- Autonomous maintenance advisory systems Technical Expectations from Participants: Teams are expected to demonstrate understanding of:

- IC engine fundamentals

- UAV propulsion systems

- Sensor fusion

- Embedded systems

- CAN communication

- AI/ML analytics

- Data visualization

- Simulation modelling

- Reliability engineering

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26055"></a>[55] SIH26055: Smart Scan strategy for Electronic Warfare

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26055` (SIH26055) |
| **Problem Statement Title** | Smart Scan strategy for Electronic Warfare |
| **Organization** | DRDO |
| **Department** | Department of Defence Production /IDEX |
| **Category** | Software |
| **Theme** | Clean & Green Technology |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Development of Smart Scan Strategy for Electronic Warfare in the absence of prior reliable intelligence of emitters and their operating characteristics.

**Background:**

Detection of hostile communication or radar signals starts with search / scan of a wide frequency spectrum which covers relevant emitters. Sensors with typically high sensitivity but with at least an order lower instantaneous bandwidth compared to overall bandwidth of the system are used to maintain surveillance over the entire spectrum. This requires a receiver / receivers to sweep over frequency bands. Hitherto strategies based on pre mission data / prior data (Open loop) are used. Usually the first priority is to rapidly sweep the entire band with the best speed possible. Open loop strategies focus only on this requirement and may lose time to nonthreatening emitters by not giving time to new or threatening ones.

- Detailed Description This problem statement focusses on development of Smart Scan Strategy for Electronic Warfare. Interception of signals is a two dimensional search problem since it involves adjusting receiver's frequency at correct time. This includes building up figures of merit for interception performance such as probability of detection, probability of false alarm, sensitivity, Avg intercept rate, Avg Reward / cost function, percentage of correct predictions and average intercept time error. A system model for the receiver needs to be developed with measurements obtained from a simulated RF environment which has truth information on status of emitters in each band and at each time slot. The frequency spectrum for own receiver consists of many bands.

The status of environment for each frequency band at each time step can be recorded as a transmission or a non-transmission. The model should enable prediction of intercept time and interception ratio of a scanning receiver against spatially scanning and frequency agile emitters. Development of a robust scheduler using machine learning to minimize intercept time and ensure a high interception rate is the primary objective of the strategy. The model should then be trained based on hits and misses. Further, approaches to intercept a periodic scan receiver optimally should be outlined. Algorithms and techniques for the same need to be developed.

**Expected Solution:**

Machine learning based Electronic Support receiver scheduler software

#### Dataset & Reference Links

JC Wise, Radar emitter Database, 2024 huggingface.co/datasets/alan-turing institute/turing-synthetic radar dataset

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26056"></a>[56] SIH26056: Development of a Real-time Airfare Price Index for India through Automated Web Scraping of Airline and Online Travel Aggregator Portals for Augmentation of the Consumer Price Index (CPI).

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26056` (SIH26056) |
| **Problem Statement Title** | Development of a Real-time Airfare Price Index for India through Automated Web Scraping of Airline and Online Travel Aggregator Portals for Augmentation of the Consumer Price Index (CPI). |
| **Organization** | MoSPI |
| **Department** | Data Informatics & Innovation Division (DIID) |
| **Category** | Software |
| **Theme** | Travel & Tourism |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

The Consumer Price Index (CPI) released by the National Statistical Office (NSO), Ministry of Statistics and Programme Implementation (MoSPI), is the primary measure of retail inflation in India and is used by the Reserve Bank of India (RBI) for setting monetary policy under the flexible inflation-targeting framework. The current CPI framework, however, collects 'Transport and Communication' sub-group prices, including air travel fares, primarily through manual price-collection from a limited set of outlets and ticketing offices. With over 90% of domestic air tickets in India now sold online through airline websites and Online Travel Aggregators (OTAs) such as MakeMyTrip, Yatra, EaseMyTrip, Cleartrip, Ixigo and Goibibo, manual collection no longer captures the highly dynamic, route-specific, and time-sensitive pricing that Indian consumers actually face. Airfares in India follow dynamic pricing where the same sector can vary by 200-400% within a single day depending on advance-booking window, day-of-week, demand surges, festival seasons and fuel-price-linked surcharges. There is therefore an urgent need for an automated, scalable and high-frequency data-collection system that mirrors what a real Indian traveller pays.

- Detailed Description The problem statement envisages development of an end-to-end software platform that automatically web-scrapes airfare data from major Indian airline websites (IndiGo, Air India, Air India Express, Akasa Air, SpiceJet) and leading OTAs, cleans and normalises the collected price quotes, and computes a Real-time Airfare Price Index (APIx) at daily, weekly and monthly frequencies. The system shall maintain a basket of representative city-pairs (such as DEL-BOM, DEL-BLR, BOM-BLR, DEL-CCU, BLR-HYD, MAA-DEL, etc.) selected on the basis of DGCA passenger-traffic data, and shall capture fares for multiple advance-purchase windows (T+1, T+7, T+15, T+30, T+45 days). Scraping must handle JavaScript-rendered pages, dynamic CAPTCHAs, anti-bot measures, IP rotation, and session management while remaining compliant with the robots.txt and terms of service of source websites, with appropriate rate-limiting and ethical-scraping safeguards. The collected raw quotes shall be passed through a data-cleaning pipeline that removes outliers, handles missing values, accounts for cancellations/sold-out flights, and separates base fare from taxes, user-development fee and convenience charges. The dashboard must visualise price trends, sector-wise heatmaps, lead-time elasticity curves, and provide an API that the NSO and RBI can consume.

**Expected Solution:**

A working software prototype consisting of (a) a robust, ethically-designed multi-source web-scraping engine using Python (Scrapy/Selenium/Playwright) capable of scheduled daily extraction from airline portals; (b) a cleaned and de-duplicated airfare database with metadata such as origin, destination, carrier, advance-purchase window, fare-class, base fare, taxes and total fare; (c) an index-construction module based on PSD given routes and weights; (d) a web-based interactive dashboard showing the daily Airfare Price Index. The solution must include documentation, automated testing, and demonstrate at least 30 days of back-tested results against publicly available DGCA monthly average-fare data.

#### Dataset & Reference Links

https://esankhyiki.mospi.gov.in

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26057"></a>[57] SIH26057: AI-Powered Automated Underwater Marine Debris and Anomaly Detection System using Side-Scan Sonar Imagery

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26057` (SIH26057) |
| **Problem Statement Title** | AI-Powered Automated Underwater Marine Debris and Anomaly Detection System using Side-Scan Sonar Imagery |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | National Institute of Ocean Technology (NIOT) |
| **Category** | Software |
| **Theme** | Renewable / Sustainable Energy |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

The accumulation of anthropogenic (man-made) debris in marine ecosystems poses a critical threat to global biodiversity. Among the most destructive types of pollution are 'ghost nets'—abandoned, lost, or discarded fishing gear. These nets continuously trap and kill marine life,destroy coral reefs, and damage commercial vessel propellers.

Because the ocean is vast and dark, marine conservationists and underwater technologists rely on Side Scan Sonar (SSS) instruments. These sensors are towed behind ships or mounted on Autonomous Underwater Vehicles (AUVs) to create detailed acoustic maps of the seafloor.However, manual inspection of thousands of kilometers of sonar logs is incredibly slow, tedious, and prone to human error. Debris can easily blend into natural geological features like rock formations, sand ripples, and marine ridges. Automating this process via computer vision is essential for efficient ocean cleanup operations.

**Description:**

Participants must develop an end-to-end automated computer vision pipeline capable of ingesting side-scan sonar imagery, identifying man-made debris against a complex natural background, and generating actionable localized data.The software system must be robust enough to handle the core challenges inherent to acoustic imagery: high speckle noise, varying pixel resolutions, acoustic shadows, and data dropouts caused by underwater vehicle motion (heave, pitch, and roll). The primary objective is to build an algorithm that reliably separates natural seafloor topology from artificial anomalies. The final solution should be optimized to run efficiently, potentially allowing deployment on edge devices or onboard a marine drone without requiring heavy cloud computing dependencies.

**Expected Solution:**

Teams are expected to deliver a functional, modular software prototype containing the following core components:

- Object Detection / Semantic Segmentation Model: An AI/ML architecture (such as YOLO,Faster R-CNN, or U-Net) trained to detect and draw bounding boxes or pixel-level masks around man-made objects (including shipwrecks, pipes, cylinders, and entangled debris nets).

- Confidence Scoring & Noise Filtering Module: An algorithmic pipeline or pre-processing filter that minimizes false positives caused by natural acoustic shadows or rock clusters,outputting a clear confidence score (0% to 100%) for every detected anomaly.

- Anomalous Reporting & Geotagging Engine: A data-parsing script or lightweight dashboard interface that reads sonar metadata (such as coordinate files or ping headers) to output a structured report (JSON or CSV format). This report must detail the exact location (latitude/longitude), bounding dimensions, and classification of each detected hazard.

- User Interface (UI) Dashboard: A visual interface where a user can upload a raw sonar image log, view the AI models' detections overlaid on the map in real-time, and download the generated anomaly reports.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26058"></a>[58] SIH26058: Development of a Low-Power, Real-Time Adaptive Software-Defined Sonar Transmitter Payload for Autonomous Underwater Vehicles (AUVs)

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26058` (SIH26058) |
| **Problem Statement Title** | Development of a Low-Power, Real-Time Adaptive Software-Defined Sonar Transmitter Payload for Autonomous Underwater Vehicles (AUVs) |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | National Institute of Ocean Technology (NIOT) |
| **Category** | Hardware |
| **Theme** | Blockchain & Cybersecurity |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

In underwater exploration and marine mapping, Autonomous Underwater Vehicles (AUVs) rely heavily on side-scan sonar systems. The performance of these systems is entirely dependent on the physical characteristics of the transmitted acoustic wave, known as the 'ping'. Traditional sonars transmit short, fixed-frequency pulses. However, modern advanced military and research systems utilize Linear Frequency Modulated (LFM) Chirps—waveforms that sweep across a spectrum of frequencies over a precise timeframe.The primary bottleneck is that the underwater environment is highly dynamic. Sound waves behave differently depending on water depth, turbidity (suspended mud/sediment particles),temperature, and salinity. A high-frequency chirp (500 kHz) offers ultra-high image resolution but scatters instantly in muddy or deep waters. Conversely, a low-frequency chirp (100 kHz) can penetrate murky water and travel long distances but yields a blurry, low-resolution image. For an AUV to map effectively without draining its limited battery payload, its transmitter hardware must behave like a Software-Defined Radio (SDR)—dynamically adapting its physical analog pulse waveform in real-time based on the actual environmental conditions it encounters.

**Description:**

Participants must design, prototype, and demonstrate a physical, self-contained Software-Defined Sonar Transmitter Payload Module.Instead of a software simulation, the solution must be a physical hardware unit built using an embedded platform (e.g., STM32, ESP32, Texas Instruments DSP, or an FPGA) integrated with custom analog electronics. The hardware must ingest real-time environmental data (via physical sensors, or analog voltage dials acting as sensor inputs) and mathematically synthesize and output an optimized, real-time physical analog waveform via a Digital-to-Analog Converter (DAC) and amplifier circuit.The entire hardware architecture must focus heavily on low-power consumption and hardwarelevel optimization. Teams must utilize low-level configurations (such as Direct Memory Access (DMA) and hardware timers) to ensure the processing unit does not drain a marine drone's battery pack while trying to compute complex trigonometric wave values under strict real-time constraints.

**Expected Solution:**

Teams are expected to deliver a functional physical hardware prototype consisting of the following modules:

- Embedded Firmware Engine: A robust program deployed on a physical microcontroller or FPGA (written in C/C++, Verilog, or VHDL). The firmware must utilize hardware timers and DMA to stream wave-generation arrays directly to an internal or external DAC without stalling the CPU. The system must support multiple modulation types on the fly: LFM chirps, geometric sweeps, and phase-coded pulses.

- Environmental Sensor Interface & Adaptation Logic: A physical control interface where real-time environmental changes are introduced to the hardware (via physical sensors, or potentiometers simulating sensors for parameters like 'Entering Muddy Estuary' or 'Entering Clear Shallow Reef'). The microcontroller must read these inputs via an ADC and modify three critical wave parameters instantly:

1. Bandwidth/Center Frequency (Tuning for range vs. resolution)

2. Pulse Duration (Controlling total energy output)

3. Amplitude/Signal Power

- Analog Signal Conditioning & Hardware Filters: A physical analog frontend circuit (built on a breadboard or custom PCB) featuring active/passive low-pass filters and an operational amplifier. Combined with digital windowing filters (such as Hamming, Hann, or Blackman windows) applied in the firmware, this hardware must smooth out sudden voltage jumps at the start and end of a pulse, protecting the transmitter hardware from electrical stress and eliminating sidelobe artifacts.

- Physical Form Factor & Output Validation: The physical analog output of the transmitter payload must be connected to an oscilloscope or spectrum analyzer at the judging table.The generated raw waves must demonstrate clean, low-distortion, mathematically sound spectrograms when validated via a Fast Fourier Transform (FFT). Additionally, the module should be housed in a robust, 3D-printed or fabricated structural enclosure representing a field-deployable payload pod designed for an AUV hull slot.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26059"></a>[59] SIH26059: AI-Enabled Antarctic Sea-Ice, Iceberg Trajectory, and Navigation Decision Support System

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26059` (SIH26059) |
| **Problem Statement Title** | AI-Enabled Antarctic Sea-Ice, Iceberg Trajectory, and Navigation Decision Support System |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | National Centre for Polar andOcean Research (NCPOR) |
| **Category** | Software |
| **Theme** | Smart Education |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Develop an AI/ML-enabled decision support platform capable of forecasting Antarctic sea-ice concentration, predicting iceberg trajectories, and identifying safe and fuel-efficient navigation routes for research vessels using satellite,oceanographic and meteorological datasets.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26060"></a>[60] SIH26060: Digital Platform for efficient remote management of Indian Antarctic Research Stations

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26060` (SIH26060) |
| **Problem Statement Title** | Digital Platform for efficient remote management of Indian Antarctic Research Stations |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | National Centre for Polar andOcean Research (NCPOR) |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Develop a Digital Twin framework for Maitri and Bharati stations integrating infrastructure, energy, logistics and environmental monitoring for efficient remote management.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26061"></a>[61] SIH26061: AI-Driven Smart Energy Management System for Polar Research Stations

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26061` (SIH26061) |
| **Problem Statement Title** | AI-Driven Smart Energy Management System for Polar Research Stations |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | National Centre for Polar andOcean Research (NCPOR) |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Develop an intelligent energy-management system using AI for load forecasting, renewable energy integration and fuel optimization under extreme polar conditions.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26062"></a>[62] SIH26062: Integrated Polar Expedition Logistics and Asset Management System

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26062` (SIH26062) |
| **Problem Statement Title** | Integrated Polar Expedition Logistics and Asset Management System |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | National Centre for Polar andOcean Research (NCPOR) |
| **Category** | Software |
| **Theme** | Toys & Games |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Develop a centralized digital platform for expedition planning, cargo tracking, inventory management, personnel movement and emergency response.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26063"></a>[63] SIH26063: Integrated Polar Science Outreach, Knowledge Repository and Media Dissemination Portal

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26063` (SIH26063) |
| **Problem Statement Title** | Integrated Polar Science Outreach, Knowledge Repository and Media Dissemination Portal |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | National Centre for Polar andOcean Research (NCPOR) |
| **Category** | Software |
| **Theme** | Space Technology |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Develop a comprehensive outreach portal that archives expedition reports, scientific datasets, publications, photographs, videos and institutional activities while generating content for websites and social media.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26064"></a>[64] SIH26064: Low-Cost Deployable Seafloor Metal Detection Sensor for Ocean Resource Exploration

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26064` (SIH26064) |
| **Problem Statement Title** | Low-Cost Deployable Seafloor Metal Detection Sensor for Ocean Resource Exploration |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | National Centre for Polar andOcean Research (NCPOR) |
| **Category** | Hardware |
| **Theme** | Smart Resource Conservation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Design and develop a low-cost deployable ocean-bottom sensor that can be released from a research vessel during surveys to detect and map metal-rich seabed deposits, including polymetallic nodules, hydrothermal sulphides, cobalt-rich crusts and rare-earth-element-bearing sediments, providing a rapid and cost-effective tool for deep-ocean mineral exploration.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26065"></a>[65] SIH26065: Autonomous Low-Cost Ocean Observation Platform for Polar and Southern Oceans

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26065` (SIH26065) |
| **Problem Statement Title** | Autonomous Low-Cost Ocean Observation Platform for Polar and Southern Oceans |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | National Centre for Polar andOcean Research (NCPOR) |
| **Category** | Hardware |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Design and develop an indigenous, low-cost, autonomous ocean observation platform capable of long-term deployment in harsh polar and Southern Ocean environments for measuring key oceanographic and atmospheric parameters.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26066"></a>[66] SIH26066: OceanEmbed - Satellite Embedding-Based Deep Learning Framework for Reconstruction of Subsurface Ocean Temperature from Surface Satellite Observations.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26066` (SIH26066) |
| **Problem Statement Title** | OceanEmbed - Satellite Embedding-Based Deep Learning Framework for Reconstruction of Subsurface Ocean Temperature from Surface Satellite Observations. |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | Indian National Centre for Ocean Information Services (INCOIS) Ocean Valley |
| **Category** | Software |
| **Theme** | Space Technology |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Subsurface ocean temperature is a fundamental variable for understanding ocean circulation,upper-ocean heat content, stratification, climate variability, air-sea interaction and marine ecosystems. Accurate representation of the vertical ocean temperature is essential for applications such as marine heatwave monitoring, fisheries, and data assimilation, etc. However, direct measurements of subsurface temperature remain sparse because they rely primarily on in-situ observing systems such as ARGO profiling floats, moored buoys, gliders, and ship observations. While these observations provide valuable vertical information, their spatial and temporal coverage is insufficient for generating continuous, basin-scale subsurface fields.In contrast, satellite observations provide continuous, large-scale monitoring of surface ocean conditions at relatively high spatial and temporal resolution. Surface variables such as Sea Surface Temperature (SST), Sea Surface Salinity (SSS), Sea Surface Height (SSH)/Sea Level Anomaly(SLA), surface currents, and surface winds contain indirect signatures of subsurface ocean processes through physical mechanisms including thermocline displacement, mesoscale eddies,vertical mixing, transport, and ocean-atmosphere coupling.Recent advances in Artificial Intelligence (AI), Deep Learning (DL), and representation learning enable the generation of satellite embeddings, where multidimensional surface observations are transformed into compact latent representations that capture hidden ocean dynamics. Such embeddings offer the potential to learn nonlinear relationships between surface observations and subsurface ocean structure more effectively than conventional machine learning approaches.

- Detailed Description The current problem statement proposes the development of a Satellite Embedding-Based Deep Learning Framework to reconstruct depth-wise subsurface temperature from daily surface satellite observations at 0.25° spatial resolution for North Indian Ocean (5°N to 30°N and 45°E to 105°E).The objective is to estimate the three-dimensional ocean temperature using only surface satellite observations.

**The proposed system shall:**1. Develop a preprocessing and harmonization pipeline for multi-source satellite and ocean datasets.**2. Standardize all datasets to:**

a. Spatial Resolution: 0.25° × 0.25° b. Temporal Resolution: Daily 3. Use surface observations as input variables:

a. Sea Surface Temperature (SST)

b. Sea Surface Salinity (SSS)

c. Sea Surface Height (SSH) / Sea Level Anomaly (SLA)

d. Surface ocean currents (U, V)

e. Surface Winds (U, V)

**4. Generate compact satellite embeddings using DL architectures such as:**

a. Convolutional Neural Networks (CNN)

b. Vision Transformers (ViT)

c. Autoencoders d. Graph Neural Networks (GNN)

e. Attention-based hybrid architectures 5. Train reconstruction models that learn the relationship between surface ocean state to temperature profiles.

**6. Reconstruct:**

a. Temperature at standard depth levels. Standard depths in meters: (0, 5, 10, 20, 30, 50, 75, 100, 125, 150, 200, 300, 500, 700, 1000)

7. Evaluate the reconstruction using independent observations and standard skill metrics like correlation, RMSE, Bias etc.(If a dataset is not available at required resolution, the team may select the openly available product and perform appropriate spatial and temporal interpolation/regridding)

- Training Input Datasets The following datasets are recommended for building the training and evaluation pipeline. (Insert table here)

- Training Target Dataset (Subsurface Temperature)

GLORYS Global Ocean Reanalysis https://doi.org/10.48670/moi-00021 Variables: Temperature In-situ Observations dataset Gridded ARGO INCOIS Live Access Server (LAS) – Gridded ARGO

**Expected Solution:**

- End-to-end preprocessing pipeline for satellite and ocean datasets.

- Satellite embedding engine capable of learning latent ocean representations from surface observations.

- Deep learning reconstruction model for estimating subsurface temperature.

- Standardized output at daily temporal resolution and 0.25° spatial resolution.

- Validation framework using independent ARGO observations.

- Demonstration of a working Proof-of-Concept (PoC) over the Bay of Bengal / Arabian Sea

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26067"></a>[67] SIH26067: Develop a web-based interactive 3D visualization platform that integrates numerical ocean model outputs and in-situ observations.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26067` (SIH26067) |
| **Problem Statement Title** | Develop a web-based interactive 3D visualization platform that integrates numerical ocean model outputs and in-situ observations. |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | Indian National Centre for Ocean Information Services (INCOIS) Ocean Valley |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

India's vast Exclusive Economic Zone (EEZ) and coastline demand continuous, high-resolution monitoring of ocean state variables. INCOIS routinely generates and archives large volumes of ocean model outputs - including three-dimensional fields of temperature, salinity, current vectors,chlorophyll, etc. - as well as real-time and delayed-mode observations from autonomous instruments such as Argo profiling floats and underwater Gliders. These datasets are stored in NetCDF and ASCII/text formats and span multiple depth levels, spatial grids, and time steps.Despite the richness of this data, no integrated, web-based 3D visualization platform currently exists that can simultaneously render model fields and in-situ instrument observations in a single interactive environment. Existing tools are either desktop-bound, support only 2D plan views, or lack the ability to co-visualize model outputs alongside instrument profiles. Operational oceanographers and forecasters are therefore forced to toggle between disparate software packages,making it difficult to rapidly correlate model predictions with observational evidence.

**Key gaps identified include:**

? No web-based, platform-independent 3D rendering of ocean model data (temperature,salinity, currents, etc.) with depth-resolved volumetric views.

? No unified display of Argo float and Glider profile data (latitude, longitude, depth, time,temperature, salinity, chlorophyll) alongside model fields.

? Absence of interactive controls for variable selection, depth-slice navigation, time-step animation, and customizable colorbars.

? Inability to ingest new observational data streams or additional model variables without significant re-engineering.

? Lack of tools to support intuitive, rapid understanding of complex 3D ocean phenomena for operational decision-making.The absence of such a system impedes timely hazard assessment, search-and-rescue support,fishery advisories, climate monitoring, etc. - all operational mandates of INCOIS.

? Expected Solution The proposed solution is a web-based, browser-native 3D Ocean Data Visualization System that integrates ocean model outputs with observational data on a single interactive platform.

**Core functional requirements:**

? 3D Volumetric Rendering: Interactive visualization of ocean model fields (temperature,salinity, current vectors) across the full water column, with support for depth-slice views,isosurface extraction, and time-step animation using WebGL / Three.js or Cesium.js.

? Instrument Data Overlay: Co-display of Argo float, Glider profile, CTD and BGC data using geospatially accurate markers; users can click a float/glider to inspect a depth-vs-variable profile chart with timestamps.

? Multi-format Data Ingestion: Automated parsers for NetCDF (via PyNIO / xarray backend)and delimited text formats, with a modular architecture that allows new variables or data sources to be added with minimal code change.

? Customizable Colorbar & Variable Controls: Dynamic colorbar editor (color palette, min/max range, log/linear scale), variable selector, layer opacity controls, and vertical exaggeration slider for intuitive depth perception.

? Web-based, Scalable Architecture: Frontend built on modern JavaScript frameworks with a lightweight REST/OPeNDAP API backend, enabling Deployable on INCOIS infrastructure without any client-side dependencies.

? Extensible Design: Plugin-style module for future integration of additional sensors (e.g.,CTDs, moorings, HF-radar, Acoustic doppler current profiler (ADCP), etc.), new ocean model variables, and machine-learning derived products.

The system will follow open standards (OGC WMS/WCS, CF Conventions for NetCDF), enabling interoperability with national and international ocean data portals. The end product will empower INCOIS forecasters to perform rapid, intuitive analysis of complex 3D ocean phenomena -significantly improving the speed and accuracy of operational advisories, in the same way that 3D meteorological visualization has transformed weather forecasting workflows.Public Outreach & Science Communication: Beyond operational use, the platform will serve as a powerful science communication tool. Complex numerical ocean model outputs - which are typically inaccessible to non-specialists - can be transformed into visually intuitive, interactive 3D experiences. This makes the tool valuable for educating school and college students about ocean dynamics, engaging the general public during awareness campaigns, and supporting policymakers in understanding marine environmental conditions. INCOIS can use the platform for outreach events, exhibitions, and e-learning initiatives, bridging the gap between cutting-edge ocean science and the common person.

Insert 2 tables(Acronyms and Dataset Link) here-

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26068"></a>[68] SIH26068: WeatherGPT: Conversational AI for Weather Forecasting, Alerts, and Climate Information

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26068` (SIH26068) |
| **Problem Statement Title** | WeatherGPT: Conversational AI for Weather Forecasting, Alerts, and Climate Information |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | India Meteorological Department |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Weather information is often distributed through multiple portals, bulletins, satellite products, and forecast systems, making it difficult for common users, researchers, disaster managers, and government agencies to quickly obtain actionable insights.

There is a need for an intelligent conversational platform that can provide real-time weather information, forecasts, warnings, climate analysis, and decision support in natural language.

- Objective Develop an AI-powered chatbot platform named WeatherGPT that integrates meteorological datasets, forecasting models, and disaster warning systems to provide accurate, contextual, and multilingual weather intelligence through conversational interfaces.

- Key Features 1. Real-time weather information retrieval.

2. Natural language querying for weather forecasts.

3. Integration with numerical weather prediction (NWP) models such as GFS/WRF.

4. Extreme weather alerts and early warning dissemination.

5. Location-based forecasting and advisory generation.

6. Multilingual support for Indian languages.

7. Climate trend and historical weather analysis.

8. Voice-enabled interaction for rural accessibility.

**Expected Solution:**

Participants should develop:

- A mobile-based conversational AI platform.

- Backend integration with meteorological databases, website and APIs.

- AI/LLM-based query understanding engine.

- Scalable architecture supporting real-time data ingestion.

- Suggested Technology Stack

- Python / FastAPI / Node.js

- MQTT / WIS2.0 / WebSocket

- LLMs (OpenAI, Llama, Gemini, etc.)

- GIS tools and weather APIs

- PostgreSQL / MongoDB

- Docker / Kubernetes

- Expected Outcomes

- Faster dissemination of weather information.

- Improved public accessibility to forecasts.

- Better disaster preparedness and response.

- Intelligent weather decision-support system for agriculture, aviation, marine, and urban planning.

- Possible Use Cases

- Farmers seeking crop-weather advisories.

- Aviation weather briefing.

- Flood/cyclone warning dissemination.

- Smart city weather monitoring.

- Climate analytics for researchers.

- Evaluation Parameters

- Accuracy and relevance.

- Response latency.

- Multilingual capability.

- User interface and accessibility.

- Scalability and innovation.

- Integration with real-time meteorological systems.

- Voice-enabled interaction for rural accessibility

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26069"></a>[69] SIH26069: National Weather Big Data Analytics Platform

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26069` (SIH26069) |
| **Problem Statement Title** | National Weather Big Data Analytics Platform |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | India Meteorological Department |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Design and develop a scalable National Weather Big Data Analytics Platform capable of collecting and processing real-time weather-related information for India from multiple internet-based sources including social media platforms, public datasets, websites, APIs, and citizen reports. The platform should automatically collect weather related posts and information tagged with #IMD and other relevant weather hashtags, along with metadata such as date & time, city, state, GPS location, photos, videos, and event category, and store the information in a centralized database.

The system should leverage big data technologies and open-source tools to support large-scale real-time data ingestion, processing, storage, and visualization.

Participants are encouraged to use machine learning and AI-based techniques to identify fake or misleading reports, verify untrusted sources, remove duplicate entries, and automatically categorize weather events such as rainfall, thunderstorms, flooding, heatwaves, fog, dust storms, and strong winds.

Develop a web-based dashboard and Admin Panel for monitoring and analysing collected data with features including:

- Date-wise filtering

- Event-wise filtering

- Location-wise filtering

- Verification status tracking

- Real-time visualization and analytics

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26070"></a>[70] SIH26070: To develop an Artificial Intelligence (AI) / Machine Learning (ML) based system for identification, classification, and prediction of different tropical cyclone patterns using multi-source satellite data.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26070` (SIH26070) |
| **Problem Statement Title** | To develop an Artificial Intelligence (AI) / Machine Learning (ML) based system for identification, classification, and prediction of different tropical cyclone patterns using multi-source satellite data. |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | India Meteorological Department |
| **Category** | Software |
| **Theme** | Smart Education |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

To develop an Artificial Intelligence (AI) / Machine Learning (ML) based system for identification, classification, and prediction of different tropical cyclone patterns using multi-source satellite data.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26071"></a>[71] SIH26071: AI/ML-Based Integrated heavy rainfall Early Warning and Inundation Prediction System using Satellite, Radar, observational Weather and numerical weather prediction model data.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26071` (SIH26071) |
| **Problem Statement Title** | AI/ML-Based Integrated heavy rainfall Early Warning and Inundation Prediction System using Satellite, Radar, observational Weather and numerical weather prediction model data. |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | India Meteorological Department |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

AI/ML-Based Integrated heavy rainfall Early Warning and Inundation Prediction System using Satellite, Radar, observational Weather and numerical weather prediction model data.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26072"></a>[72] SIH26072: AIML based Nowcasting of thunderstorm and lightning using atmospheric observation including multiple radars, satellite, lightning and model data.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26072` (SIH26072) |
| **Problem Statement Title** | AIML based Nowcasting of thunderstorm and lightning using atmospheric observation including multiple radars, satellite, lightning and model data. |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | India Meteorological Department |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

AIML based Nowcasting of thunderstorm and lightning using atmospheric observation including multiple radars, satellite, lightning and model data.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26073"></a>[73] SIH26073: AI/ML-Based Intelligent Anomaly Detection for Automatic Weather Stations (AWS)

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26073` (SIH26073) |
| **Problem Statement Title** | AI/ML-Based Intelligent Anomaly Detection for Automatic Weather Stations (AWS) |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | India Meteorological Department |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

- Title SkyGuard AI: Intelligent Real-Time Anomaly Detection System for Temperature, Pressure, and Humidity Sensors in Automatic Weather Stations

**Background:**

Automatic Weather Stations (AWS) are critical components of modern meteorological observation networks. These stations continuously monitor atmospheric parameters and provide real-time data for weather forecasting, climate monitoring, disaster management, aviation, agriculture, and scientific research.However, AWS observations often contain anomalies caused by sensor malfunction,communication failures, calibration drift, power fluctuations, harsh environmental conditions, and data corruption.Erroneous observations can significantly impact weather forecasting accuracy and decision-making systems. Traditional threshold-based quality control methods are often insufficient for identifying complex or hidden anomalies in meteorological data streams.

- Problem Statement Develop an AI/ML-based intelligent anomaly detection system capable of automatically identifying abnormal, inconsistent, or faulty observations from Automatic Weather Stations in real time using only the following parameters:

- Temperature (°C)

- Atmospheric Pressure (hPa)

- Relative Humidity (%)

The system should distinguish between genuine meteorological events and sensor/data anomalies while minimizing false alarms and enabling scalable deployment across large weather observation networks.

- Objectives

- Detect anomalies in real-time AWS data streams.

- Identify sensor faults, spikes, frozen values, and communication errors.

- Learn normal temporal and seasonal patterns of temperature, pressure, and humidity.

- Perform multivariate consistency analysis among atmospheric parameters.

- Provide confidence scores and explainable AI-based reasoning for detected anomalies.

- Predict possible sensor degradation and maintenance requirements.

- Optionally suggest corrected/imputed values for anomalous observations.

- Expected Inputs Participants may use historical AWS datasets, simulated anomalies, or streaming sensor data containing the following meteorological parameters:

Parameter- Unit Temperature - °C Atmospheric Pressure - hPa Relative Humidity - %

- Expected Outputs

- Real-time anomaly alerts

- Severity and confidence scores

- Root-cause classification

- Visualization dashboard

- Sensor health status

- Corrected data estimation (optional)

- Suggested Technologies

- Explainable AI (SHAP/LIME) (Preferable)

- Edge AI for low-power deployment on ESP32

- Evaluation Criteria (To be evaluated in anomaly injected data)

Criteria - Weightage Innovation & Novelty - 25% Detection Accuracy - 20% Real-Time Capability - 15% Explainability - 10% Scalability - 10% Practical Deployability - 10% Visualization/UI - 5% Energy Efficiency - 5%

- Example Use Case An AWS suddenly reports a temperature of 55°C with extremely high humidity and abnormal pressure variation while neighboring stations show normal conditions. The AI system should analyze temporal and spatial consistency, identify the reading as a probable sensor anomaly, generate an alert, and suggest corrective action.

- Grand Challenge Can AI build a self-aware and self-healing weather observation network capable of delivering trustworthy atmospheric data under all environmental conditions?

- Output:

Fully executable code with example usage and a document explaining various use cases

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26074"></a>[74] SIH26074: Downscaling of weather forecast from Block level to Panchayat level: Inferring high-resolution plots/ data/ information from low-resolution plot /data /information /variables for agro-meteorological advisory services.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26074` (SIH26074) |
| **Problem Statement Title** | Downscaling of weather forecast from Block level to Panchayat level: Inferring high-resolution plots/ data/ information from low-resolution plot /data /information /variables for agro-meteorological advisory services. |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | India Meteorological Department |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Downscaling of weather forecast from Block level to Panchayat level: Inferring high-resolution plots/ data/ information from low-resolution plot /data /information /variables for agro-meteorological advisory services.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26075"></a>[75] SIH26075: Participants are invited to design and develop **CAPACITY CONNECT A Digital Capacity Building and Learning Management Portal** to support organizational training, competency development, and knowledge sharing through a centralized web-based platform.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26075` (SIH26075) |
| **Problem Statement Title** | Participants are invited to design and develop **CAPACITY CONNECT A Digital Capacity Building and Learning Management Portal** to support organizational training, competency development, and knowledge sharing through a centralized web-based platform. |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | India Meteorological Department |
| **Category** | Software |
| **Theme** | Smart Education |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

The solution should include secure signup and login functionality with three user roles: Trainee, Trainer, and Admin. Trainees should be able to create professional profiles with qualifications, work experience, interests, skills, and certificates, enroll in courses, access learning resources, attempt subject-wise MCQ assessments, and provide feedback on courses and training content.Trainers should be able to manage their profiles, create questionnaires with deadlines, monitor trainee participation and performance, and upload recorded lectures, presentations, and study materials in a trainer library accessible to trainees.The Admin module should provide user approval and role management features along with dashboards for monitoring courses, enrollments, certifications,assessments, and participation statistics. Admins should also be able to publish notifications, announcements, achievements, and newly added learning content on the homepage.The platform should support competency mapping for identifying suitable trainers for various subjects and should be scalable, secure, user-friendly, and accessible across devices to promote efficient learning and organizational capacity building.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26076"></a>[76] SIH26076: Development of personalized homepage for 'Mausam' mobile application:

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26076` (SIH26076) |
| **Problem Statement Title** | Development of personalized homepage for 'Mausam' mobile application: |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | India Meteorological Department |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

- Health-conscious users Highlight Air Quality Index (AQI), pollen count, UV index, and humidity levels to help users manage allergies, asthma, or skin sensitivity.

- Outdoor fitness enthusiasts Show sunrise/sunset times, 'best running hours,' wind speed, and heat alerts to optimize workout planning.

- Beachgoers & surfers Display sea conditions, tide timings, wave height, and water temperature for safe and enjoyable beach activities.

- Travelers Provide quick access to saved destinations, severe weather alerts for flights, and packing suggestions (e.g., 'Carry a raincoat in London').

- Parents & families Emphasize school commute conditions, rain alerts, and severe weather warnings to plan daily routines.

- Agriculture & gardeners Show soil moisture, rainfall predictions, frost alerts, and seasonal planting guidance.

- Commuters Integrate weather with traffic updates, visibility conditions, and alerts for storms or fog that affect travel.

- Event planners Offer extended forecasts, probability of rain, and 'comfort index' for outdoor gatherings or weddings.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26077"></a>[77] SIH26077: AI-Driven Hyper-Local Early Warning System for Severe Weather Nowcasting

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26077` (SIH26077) |
| **Problem Statement Title** | AI-Driven Hyper-Local Early Warning System for Severe Weather Nowcasting |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | National Centre for Medium Range Weather Forecasting (NCMRWF) |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

- Problem Statement India is highly vulnerable to rapidly intensifying, localized extreme weather events such as cloudbursts, severe thunderstorms, and flash floods. Traditional physics-based Numerical Weather Prediction (NWP) models often suffer from computational latency and struggle to capture the rapid, small-scale atmospheric changes that preceded these events. There is a critical need for a real-time, hyper-local early warning system capable of 'nowcasting' severe weather 2 to 6 hours before impact, providing actionable lead time for disaster management.

- Proposed Solution We propose an advanced AI predictive engine designed for high-precision severe-weather nowcasting. Specifically, the system simultaneously predicts the onset of highly localized, rapidly intensifying events, namely severe thunderstorms, cloudbursts, and the subsequent flash floods,with an actionable lead time of 2 to 6 hours. Instead of relying on computationally intensive thermodynamic simulations, the system utilizes a spatiotemporal deep learning architecture to recognize the complex, multivariate atmospheric signatures that precede these extreme events. A critical component of this methodology is storm nowcasting using variations in integrated water vapor (IWV). By tracking rapid spatial and temporal accumulations of IWV, the model accurately identifies the concentrated moisture pools required for heavy precipitation. To predict multiple extreme events simultaneously, the engine employs a multi-task learning approach. A shared neural network backbone extracts foundational atmospheric features (moisture, instability, and lift) from the input grids. The network then branches into distinct output layers, allowing a single unified model to generate hyper-local probability risk maps for thunderstorms, cloudbursts, and flash floods simultaneously, entirely bypassing the computational latency typical of traditional numerical weather prediction (NWP) models.

Predictive Matrix: Key Atmospheric Variables Severe convective storms require three primary ingredients: moisture, instability, and lift. Our AI model tracks the critical precursors across all three categories to ensure high accuracy and low false-alarm rates:

? Moisture Availability (The Fuel): The cornerstone of our storm nowcasting is the capture of integrated water vapor (IWV) variations. By tracking rapid spatial and temporal accumulations of IWV from satellites, the model identifies the concentrated moisture pools that trigger localized cloudbursts.

? Atmospheric Instability (The Energy): The model assesses the atmosphere's thermal profile to determine if it is buoyant enough to support explosive vertical cloud growth. High Convective Available Potential Energy (CAPE) paired with eroding Convective Inhibition (CIN) serves as a prime indicator of impending severe thunderstorms.

Kinematics and Lift (The Trigger & Structure): Low-level convergence (wind vectors colliding at the surface) forces air upward, initiating the development of a storm cell.

Furthermore, tracking vertical wind shear (changes in wind speed/direction with altitude) helps the model predict whether a storm will move quickly or remain stationary.

Observational Signatures: Rapid cooling of cloud tops, measured as the Cloud Top Temperature(CTT) Drop Rate, provides real-time validation of explosive vertical updrafts within the system.

Topographic Dynamics (The Flood Catalyst): To accurately predict flash floods, the AI overlays the atmospheric probability maps onto a high-resolution Digital Elevation Model (DEM). This allows the system to calculate how terrain slope, elevation, and natural drainage basins will channel the extreme precipitation generated by a predicted cloudburst.To capture these predictors with hyper-local accuracy, the model fuses multi-modal, high resolution datasets:

IMDAA Reanalysis Data (Historical Baseline & Thermodynamics): Multi-level air temperature, specific humidity profiles (for calculating CAPE/CIN), geopotential height, and U/V wind components (for calculating shear and convergence).

Satellite Observations (INSAT-3D/3DR via MOSDAC): Water Vapor (WV) Channels. This is essential for deriving real-time Integrated Water Vapor (IWV) fluctuations necessary for our storm nowcasting.

Thermal Infrared (TIR) Channels: Utilized to calculate the rapid Cloud Top Temperature (CTT) drop rate.

Quantitative Precipitation Estimation (QPE): Satellite-derived precipitation estimates are used to monitor real-time rainfall intensity, serving as a reliable, openly accessible alternative to ground-based radar.

Digital Elevation Model (DEM): High-resolution topographical data (such as ISRO's CartoDEM or SRTM) provides a static baseline of elevation, slope, and surface drainage networks, enabling translation of atmospheric cloudburst predictions into actionable flash flood warnings on the ground.

- Technical Methodology ? Data Fusion & Alignment: Raw data from IMDAA reanalysis, INSAT-3D/3DR satellite observations, and high-resolution Digital Elevation Models (DEM) are ingested, normalized, and mapped onto a unified spatiotemporal grid (e.g., using multi-dimensional array structures). This ensures that all dynamic atmospheric predictors—such as specific humidity and cloud-top temperatures—and static surface variables align geographically and chronologically for seamless multimodal processing.

? Multi-Variate Feature Extraction & Multi-Task Inference: A shared multi-modal spatiotemporal transformer network continuously analyzes real-time satellite grids, specifically tracking critical IWV variations and CTT drop rates, against the IMDAA-derived thermodynamic baselines using cross-attention mechanisms. Utilizing a Multi-Task Learning (MTL) architecture,the network branches into distinct output 'heads.' This allows the unified model to simultaneously process the aligned data and generate distinct, hyper-local probability maps for severe thunderstorms, cloudbursts, and flash floods without computational bottlenecking.

? Automated Alerting: When the predictive matrix breaches the signature thresholds of a severe event, the engine generates a spatial risk map and pushes automated, categorized alerts via a lightweight API.

**Expected Solution:**

The final deliverable for the Smart India Hackathon will be a fully functional, real-time prototypeof the AI-Driven Hyper-Local Early Warning System. At its core is a deployed multi-task inference engine that continuously ingests live INSAT satellite data and IMDAA thermodynamic baselines to simultaneously generate predictive risk maps for severe thunderstorms, cloudbursts, and flash floods within a 2 to 6-hour predictive window. This backend integrates with an interactive, webbased spatial dashboard designed for disaster management authorities, featuring dynamic risk maps overlaid on a Digital Elevation Model (DEM) and an Explainable AI (XAI) module that transparently displays meteorological triggers. Finally, an automated API will translate these predictive insights into immediate, categorized alerts sent directly to first responders and vulnerable communities the moment critical thresholds are breached.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26078"></a>[78] SIH26078: AI-Driven Spatio-Temporal Tracking of Extreme Weather Anomalies in Medium-Range Forecasts

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26078` (SIH26078) |
| **Problem Statement Title** | AI-Driven Spatio-Temporal Tracking of Extreme Weather Anomalies in Medium-Range Forecasts |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | National Centre for Medium Range Weather Forecasting (NCMRWF) |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

- Problem Statement Identifying and tracking the exact geographic footprints of extreme weather anomalies (such as severe cyclones, heat domes, or cold waves) within massive global Numerical Weather Prediction (NWP) outputs is computationally intensive and heavily reliant on manual interpretation. In medium-range forecasting (3 to 10 days), atmospheric chaos renders traditional deterministic models highly uncertain.

Furthermore, standard deep learning models (like standard CNNs or U-Nets) suffer from spectral smoothing—they tend to 'average out' spatial data, which destroys the extreme amplitudes (the high-intensity peaks of rainfall or wind speed) that forecasters actually need to track. There is a critical gap between broad, coarse 12 km global ensemble datasets and localized, high-fidelity threat tracking.

- Proposed Solution We propose an automated, state-of-the-art AI tracking and downscaling pipeline that shifts the paradigm from manual weather data sorting to automated, physics-informed anomaly tracking.Instead of relying on a single deterministic forecast run, our system directly processes multivariable, 4D Ensemble Prediction Systems (EPS) data.The system uses a two-stage hybrid AI architecture to solve the spectral smoothing problem:First, it utilizes a graph neural network (GNN) to map atmospheric variables onto a spherical mesh,instantly isolating moving anomalies and calculating their trajectory over a 3- to 10-day forecast window.

Second, it pipes this isolated region into a generative diffusion model to perform statistical downscaling. This physics-constrained generative model mathematically derives a hyper-local 5km subgrid impact zone without flattening or blurring the severe amplitudes of the extreme weather event.

- Technical Methodology & Architecture Spherical Anomaly Tracking (Stage 1 GNN): To eliminate the geographic distortions caused by processing the spherical Earth on flat 2D pixel grids, the system maps the 12 km NCMRWF Global Ensemble (NEPS-G) grids directly onto an icosahedral mesh. The message-passing GNN calculates the Extreme Forecast Index (EFI) against a 30-year historical ERA5 baseline distribution to isolate standard deviations and draw a macro-scale temporal bounding box around the anomaly's trajectory.

Amplitude-Preserving Downscaling (Stage 2 Diffusion): The system passes the cropped, macroscale bounding box into a conditional denoising diffusion probabilistic model. Rather than optimizing for mean errors (which blurs peaks), the diffusion model learns the physical relationships between synoptic-scale features and regional topography. It iteratively generates high-resolution, high-amplitude local weather scenarios, downscaling the 12 km grid into a 5 km grid.

Physics-Informed Constraints: To ensure the model remains scientifically accurate, we embed fluid dynamics and thermodynamic conservation laws directly into the neural network's loss function. The model is mathematically penalized if it generates physically impossible weather states (e.g., severe downpours missing corresponding moisture convergence vectors).

- Datasets and Tools ? AI Frameworks: PyTorch / JAX (engineered with custom, physics-guided loss functions),Deep Graph Library (DGL) for icosahedral mesh networks, and Hugging Face Diffusers for generative downscaling.

? Data Wrangling & Geospatial Tools: Xarray and Dask for processing parallelized, multigigabyte 4D NetCDF/GRIB2 arrays; MetPy for physical meteorological equations;

Cartopy for geographical map projections.

**? Training & Testing Datasets:**

? Baseline: Historical IMDAA / ERA5 reanalysis data to establish the climatological norm.

? Forecast Inputs: Historical NCUM (12 km deterministic) and NEPS-G (12 km global ensemble) datasets containing documented extreme historical events (e.g., Cyclone Amphan, severe North India heatwaves).

- Expected Outcome & Key Deliverables The Tracking Core: A production-ready Spatio-Temporal GNN module that continuously processes global NWP streams to output dynamic, automated 4D bounding boxes around evolving weather threats.

The Downscaling Core: A generative diffusion module capable of ingesting a 12 km resolution anomaly slice and outputting a probabilistically sound, 5 km resolution sub-grid array that retains extreme value amplitudes.

The Visualization & Alert Dashboard: An automated system that translates the mathematical 5 km centroid arrays into clean, geographic visual layers.

The Alerting API: A lightweight, production-ready REST API that programmatically drops a pinpoint coordinate at the core of the severe anomaly and triggers categorized spatial alerts (low, moderate, and severe) across a precise 5 km geographical impact radius.

- Use Cases & Societal Impact Eliminating Alert Fatigue for the NDRF: Current weather alerts are often too broad, covering entire states or districts, which leads to public complacency. This solution allows meteorologists to issue hyper-localized, highly targeted warnings. It changes a generic'heavy rain in the district' alert into a precise 'high risk of flash flooding within your specific 5 km radius in the next 12 hours' alert, empowering first responders to deploy assets perfectly.

Protecting Rural Economies: Grants farming communities a highly accurate, 3- to 10- day lead time regarding localized catastrophic anomalies like sudden frost, hail, or heat domes. This structural foresight lets farmers alter harvesting schedules or apply cropprotection covers, shielding rural livelihoods from sudden climate shocks.

Democratizing Supercomputing Power: Once this hybrid AI pipeline is trained, it processes live inference data on a standard cloud GPU node in seconds, making high-fidelity climate forecasting highly affordable and easily accessible.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26079"></a>[79] SIH26079: AI-Based Forecast Bust Detection for Medium-Range Weather Forecasts

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26079` (SIH26079) |
| **Problem Statement Title** | AI-Based Forecast Bust Detection for Medium-Range Weather Forecasts |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | National Centre for Medium Range Weather Forecasting (NCMRWF) |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

- Problem Statement Medium-range weather forecasts sometimes show large errors during rapidly evolving systems such as monsoon depressions, heavy rainfall events, western disturbances, cyclones, heat waves and break/active monsoon phases. Such forecast failures, or 'forecast busts', can affect operational decision-making.

- Challenge The challenge is to develop an AI/ML-based system that can identify regions and lead times where the forecast is likely to have high uncertainty or large error. The system should compare current NWP forecast patterns with historical forecast error behaviour and provide a forecast confidence indicator.

Expected Outcome - Description Forecast confidence map - Region-wise confidence for Day 1 to Day 10 forecasts Forecast bust probability - Probability of large forecast error over different regions Error-prone area detection - Identification of areas where model forecast may be unreliable Explainable output - Key meteorological reasons for low confidence Prototype dashboard/API - Simple interface for operational use

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26080"></a>[80] SIH26080: Regime-Aware AI Post-Processing of Monsoon Rainfall Forecasts

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26080` (SIH26080) |
| **Problem Statement Title** | Regime-Aware AI Post-Processing of Monsoon Rainfall Forecasts |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | National Centre for Medium Range Weather Forecasting (NCMRWF) |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

- Problem Statement Rainfall forecast errors over India vary with weather regimes such as active monsoon, break monsoon, monsoon lows/depressions, orographic rainfall, coastal rainfall and western disturbances. A single bias-correction method may not work equally well in all situations.The challenge is to build an AI/ML-based rainfall post-processing system that first identifies the prevailing weather regime and then applies suitable correction to the raw NWP rainfall forecast.The aim is to improve district/grid-level rainfall forecasts, especially for heavy and very heavy rainfall events.

- Expected Outcome Expected Outcome - Description:

Weather regime classifier - Classification of active, break, depression,coastal/orographic rainfall regimes Bias-corrected rainfall forecast - Improved rainfall forecast compared to raw NWP output Heavy rainfall probability - Probability of rainfall exceeding operational thresholds District-level rainfall product - User-friendly rainfall forecast table/map Verification report - Skill comparison using RMSE, ETS, CSI, POD, FAR and FSS

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26081"></a>[81] SIH26081: Hybrid AINWP Multi-Model Forecast Blending System

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26081` (SIH26081) |
| **Problem Statement Title** | Hybrid AINWP Multi-Model Forecast Blending System |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | National Centre for Medium Range Weather Forecasting (NCMRWF) |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

- Problem Statement Different forecasting systems perform differently depending on region, season, lead time and weather situation. Physical NWP models, ensemble forecasts and AI/ML weather models may each have strengths under different conditions. Therefore, there is a need for an intelligent blending system that can dynamically combine multiple forecasts.

The challenge is to develop a hybrid AI–NWP blending framework that assigns adaptive weights to different forecast sources based on historical skill, forecast lead time, region, season and weather regime. The final product should provide an optimized forecast for rainfall, temperature, wind and extreme weather indicators.

Expected Outcome - Description

- Dynamically blended forecast - Best-combined forecast from multiple model sources

- Model weight maps - Indication of which model is more reliable for each region/lead time

- Improved forecast skill - Better performance than individual models

- Extreme weather guidance - Improved signals for heavy rainfall, heat wave and high-wind events

- Operational workflow - Automated script/dashboard for routine forecast blending

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26082"></a>[82] SIH26082: Air PollutionWeather Coupled Forecasting System (Delhi NCR Focus)

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26082` (SIH26082) |
| **Problem Statement Title** | Air PollutionWeather Coupled Forecasting System (Delhi NCR Focus) |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | National Centre for Medium Range Weather Forecasting (NCMRWF) |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Traditional Air Quality Index (AQI) forecasting models typically treat meteorology and pollution dispersion as separate entities. However, in highly polluted urban landscapes like Delhi NCR, there is a critical, dynamic feedback loop between the weather and pollutants. During peak pollution seasons (such as the winter stubble-burning period), atmospheric inversion layers trap particulate matter close to the ground. Conversely, dense concentrations of aerosols (PM2.5) block sunlight,altering local temperatures, wind patterns, and planetary boundary layer (PBL) heights. Ignoring these coupled meteorological-chemical feedback loops leads to significant inaccuracies in standard AQI predictions. To achieve high-accuracy, actionable insights, there is an urgent need for an integrated system that simulates real-time interactions between atmospheric physics and chemical transport.

The challenge is to build a high-resolution, coupled forecasting system specifically tailored for Delhi NCR that predicts AQI for the next 72 hours.

The solution must leverage advanced weather-chemistry models (such as WRF-Chem or similar open-source coupled frameworks) to dynamically interlink meteorology with pollution dispersion(specifically PM2.5 and Ground-level Ozone). A core focus should be accurately modeling the impact of atmospheric inversion on external pollution spikes, such as regional stubble burning,and how those trapped pollutants subsequently alter local weather conditions.Implement a workflow that handles two-way feedback between meteorology (temperature, wind,PBL height) and chemistry (PM2.5, PM10, O3,NOx). A user-friendly, real-time dashboard displaying high-resolution AQI forecasts for Delhi NCR with a 72-hour outlook. Features that explicitly track atmospheric inversion strength and predict how stubble-burning plumes will disperse under prevailing weather conditions.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26083"></a>[83] SIH26083: Extreme Heatwave Early Warning and Human Thermal Stress Index

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26083` (SIH26083) |
| **Problem Statement Title** | Extreme Heatwave Early Warning and Human Thermal Stress Index |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | National Centre for Medium Range Weather Forecasting (NCMRWF) |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

In recent years, the frequency, duration, and intensity of heatwaves across India have escalated sharply due to climate change. However, traditional meteorological warnings rely almost exclusively on ambient dry-bulb temperature thresholds. This creates a critical vulnerability:standard forecasts ignore the deadly compounding effects of relative humidity, wind speed, and solar radiation on the human body.

A temperature of 40°C at 20% humidity feels vastly different from 40°C at 70% humidity—the latter can be fatal. Current public health infrastructure lacks localized, impact-based forecasting that translates raw weather data into actual physiological risk, human thermal stress levels, and projected mortality rates.

The challenge is to design an intelligent, localized early warning system that shifts heatwave forecasting from 'what the weather will be' to 'what the weather will do' to human health.

Participants need to build a predictive platform that computes a comprehensive Human Thermal Stress Index (integrating temperature, humidity, wind, and radiation) and links it directly to an automated Mortality Risk Index. The system should offer high-resolution forecasts to help municipal corporations, healthcare systems, and disaster management authorities deploy targeted,preemptive interventions.

Develop algorithms to calculate advanced heat stress metrics such as the Wet-Bulb Globe Temperature (WBGT), Universal Thermal Climate Index (UTCI), or Heat Index (HI) rather than relying on temperature alone. Integrate historical public health, demographic (e.g., elderly or outdoor worker density), and localized weather data to predict heat-induced mortality and hospitalization spikes 3 to 5 days in advance. A dynamic GIS-mapped dashboard providing colorcoded, hyper-local alerts (Zone/Ward level) paired with actionable, automated public health advisories. An API capable of pushing automated SMS/WhatsApp regional alerts or localized triggers for city administration to initiate heat action plans (e.g., opening cooling centers, adjusting power grids, shifting outdoor work hours).

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26084"></a>[84] SIH26084: Convective scale nowcasting for Thunderstorms, Hail & Cloudbursts (06 hr)

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26084` (SIH26084) |
| **Problem Statement Title** | Convective scale nowcasting for Thunderstorms, Hail & Cloudbursts (06 hr) |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | National Centre for Medium Range Weather Forecasting (NCMRWF) |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Convective storms, such as severe thunderstorms, hail, downburst winds, and cloudbursts are among India's deadliest natural hazards, especially during the pre-monsoon and monsoon seasons.Despite advancements in Numerical Weather Prediction (NWP) models, traditional systems often fail to accurately capture these mesoscale extreme weather events.The primary limitation stems from spatial and temporal constraints: these violent storms develop rapidly within a window of minutes and occur at localized scales that slip through coarse grid resolutions. Current early warning infrastructures struggle to provide high-resolution, short-term forecasts (0–6 hours), leaving local administrations, aviation sectors, and rural farming communities vulnerable to sudden, devastating impacts.

The challenge is to build a real-time, convective-scale Nowcasting System (0–6 hour lead time) operating at a hyper-local 1–3 km spatial resolution.

Because traditional physics-based models are too computationally slow to simulate these rapid developments in real-time, participants must design a system rooted in Multi-Source Data Fusion architectures. The core objective is to ingest high-frequency, heterogeneous meteorological streams, automatically detect early convective initiation, and dynamically forecast severe storm parameters (including lightning strike density, hail probability, downburst velocity, and cloudburst thresholds).Design a robust, real-time ingestion engine that fuses data streams from multiple sources: Doppler Weather Radars (DWR - reflectivity and velocity fields), geostationary satellite imagery (INSAT-3D/3DR thermal/infrared bands), and ground-based lightning detection networks. A real-time,interactive GIS-mapped dashboard showcasing high-resolution (1–3 km) hazard zones with live countdown clocks for storm arrivals.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26085"></a>[85] SIH26085: Urban Flood Nowcasting System (Drainage and Rainfall Coupling)

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26085` (SIH26085) |
| **Problem Statement Title** | Urban Flood Nowcasting System (Drainage and Rainfall Coupling) |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | National Centre for Medium Range Weather Forecasting (NCMRWF) |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Urban flooding in major Indian metros like Mumbai, Delhi, and Chennai has become an annual crisis. Traditional Numerical Weather Prediction (NWP) models fall short because knowing how much rain will fall does not automatically translate into knowing where the streets will flood.Urban flooding is a hyper-local phenomenon dictated by micro-topography, concrete imperviousness, and heavily strained, invisible drainage networks. Currently, municipal bodies lack real-time, street-level predictive systems. Consequently, cities are caught off guard by rapid water accumulation, leading to severe traffic gridlocks, economic disruption, and loss of life.

The challenge is to design a high-resolution, real-time Urban Flood Nowcasting System (0–3 hour lead time) capable of predicting street-level inundation before it happens.

Participants must move away from isolated weather models and instead build a coupled framework. This system must fuse real-time rainfall nowcasts with high-resolution Digital Elevation Models (DEM) and a graph-based mathematical model of the city's underground drainage network. By mapping how water flows, accumulates, and surcharges across concrete surfaces and drainage nodes, the solution should pinpoint exactly which streets or intersections will flood.Develop a pipeline that takes high-resolution rainfall nowcasts (from Doppler Weather Radars) and instantly routes that volume across a 2D surface terrain model. Represent the city's stormwater drain network as a directed graph (nodes as manholes/inlets, edges as pipes/canals). The model must calculate hydraulic capacity and predict where blockages or overcapacity will cause backflow onto the streets. A dynamic, web-based GIS dashboard showing real-time, street-by-street flooding projections (e.g., water depth estimations in centimeters) with a 0–3 hour forward-looking window.An API utility that can interface with navigation maps to suggest flood-safe alternative routes for emergency services, public transit, and commuters during heavy downpours.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26086"></a>[86] SIH26086: Hyperlocal Monsoon Onset & Break Prediction System (Block/Village Scale)

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26086` (SIH26086) |
| **Problem Statement Title** | Hyperlocal Monsoon Onset & Break Prediction System (Block/Village Scale) |
| **Organization** | Ministry of Earth Sciences (MoES) |
| **Department** | National Centre for Medium Range Weather Forecasting (NCMRWF) |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

The Indian Summer Monsoon dictates the economic livelihood of millions of farmers, particularly during the Kharif sowing season. While macro-scale monsoon forecasts across large meteorological subdivisions have improved, Indian agriculture remains highly vulnerable to the unpredictable nature of intra-seasonal variations. Specifically, the exact dates of monsoon onset,prolonged dry spells (break-monsoon phases), and subsequent revival cycles vary drastically from one district to another.

Standard regional forecasts lack the spatial granularity required for localized agricultural planning.If a farmer sows seeds during a false onset just before a major breakthrough pause, entire crops fail due to moisture stress, leading to crushing financial losses.

The challenge is to build a hybrid predictive framework capable of delivering a 7-to-30-day probabilistic outlook of monsoon behavior at the Block and Panchayat (Village cluster) scale.

The system must bridge the gap between global climate teleconnections and hyper-local weather outcomes. Participants should design a solution that ingests large-scale climate indices—such as the El NiÃ±o-Southern Oscillation (ENSO), Indian Ocean Dipole (IOD), and Madden-Julian Oscillation (MJO)—and downscales their signatures using advanced machine learning models to predict localized precipitation behavior, onset thresholds, and active/break durations.Develop a hybrid mathematical or machine learning model that pairs global planetary boundary conditions (ENSO, IOD, MJO phases) with regional atmospheric data to predict local rainfall anomalies. Generate dynamic, color-coded risk maps at the block/panchayat level illustrating the statistical probability percentage of monsoon onset, continuous dry spells (breaks), or heavy downpours 1 to 4 weeks in advance. Build an expert-system engine that translates rainfall probabilities into localized crop-specific agronomic advisories (e.g., advising farmers to delay sowing, prepare irrigation alternatives, or alter crop choices based on upcoming break phases). A mobile-optimized web application or automated SMS/WhatsApp API gateway that pushes clear,actionable text-based advisories in regional Indian languages directly to farmers and local agricultural extension officers.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26087"></a>[87] SIH26087: AI-Enabled Cooperative Capacity Building, ERP & Employment Ecosystem

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26087` (SIH26087) |
| **Problem Statement Title** | AI-Enabled Cooperative Capacity Building, ERP & Employment Ecosystem |
| **Organization** | Ministry of Cooperation |
| **Department** | National Council for Cooperative Training (NCCT) |
| **Category** | Hardware |
| **Theme** | Smart Education |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

The National Council for Cooperative Training (NCCT), through VAMNICOM, RICMs, and ICMs, conducts large-scale training programmes for cooperative personnel, PACS members, SHGs, dairy cooperatives, farmers, and rural youth across the country. Simultaneously, trained rural youth often face challenges in accessing employment opportunities, entrepreneurship support, digital learning resources, and visibility of skill certifications.Existing systems are largely manual or fragmented, resulting in duplication of effort, inadequate trainee tracking, limited learning analytics, poor employment linkage, and inefficient programme administration.

- Problem Statement To develop an integrated digital ecosystem for cooperative training institutions that combines ERP-based training management, e-learning, data analytics, skill development, digital literacy, and employment exchange services for cooperative stakeholders and rural youth.

- Scope of the Solution The proposed system should provide a centralized, scalable, and web-based digital platform capable of integrating all major training management activities under NCCT institutions.

**Expected Solution:**

Features

- Online programme registration and nomination management

- Participant, institution, and trainee profile management

- Interactive multilingual e-learning modules

- Digital attendance through face recognition / QR code

- Timetable, hostel, and logistics management

- LMS integration with assessments and certification

- Skill certification repository and verification

- Career counseling chatbot

- Employer and recruiter dashboard

- Mobile-friendly and offline-accessible learning platform

- Centralized database for future programme outreach and monitoring

- Technology Components

- Learning Management Systems (LMS)

- Cloud-Based ERP Platform

- Data Analytics

- Mobile Applications

- Multimedia & Interactive Learning Tools

- Face Recognition / QR Technologies

- Proposed Mode Software + Hardware

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26088"></a>[88] SIH26088: Multilingual Cooperative Governance & Legal Assistance Chatbot

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26088` (SIH26088) |
| **Problem Statement Title** | Multilingual Cooperative Governance & Legal Assistance Chatbot |
| **Organization** | Ministry of Cooperation |
| **Department** | National Council for Cooperative Training (NCCT) |
| **Category** | Hardware |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

- Problem Statement Cooperative members, farmers, and rural stakeholders often lack awareness regarding cooperative laws, government schemes, PACS services, crop insurance schemes, financial literacy, and grievance redressal mechanisms due to language barriers and limited access to reliable guidance.

- Objective To develop an AI-powered multilingual chatbot capable of providing instant guidance and support on cooperative governance, legal provisions, schemes, and member services.

**Expected Solution:**

Features

- Multilingual conversational interface

- Guidance on cooperative laws and by-laws

- Information on Ministry of Cooperation schemes and services

- PMFBY and agricultural support guidance

- Financial literacy assistance

- Cooperative grievance redressal support

- Voice-enabled assistance for rural users

- Integration with mobile and web platforms

- Technology Components

- Natural Language Processing (NLP)

- Artificial Intelligence Chatbot Frameworks

- Speech-to-Text & Text-to-Speech Integration

- Cloud Computing

- Proposed Mode Software + Hardware

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26089"></a>[89] SIH26089: Cooperative Gig Services Platform for Household & Community Services

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26089` (SIH26089) |
| **Problem Statement Title** | Cooperative Gig Services Platform for Household & Community Services |
| **Organization** | Ministry of Cooperation |
| **Department** | National Council for Cooperative Training (NCCT) |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Labour Cooperative Federations and Labour Cooperative Societies possess a large pool of skilled workers such as electricians, plumbers, carpenters, painters, domestic helpers, caregivers, drivers, gardeners,cleaners, and technicians. However, they lack a structured digital platform to connect these workers with households and institutions requiring such services.Private platforms currently dominate this market, while cooperative workers often remain underutilized despite having skills and local presence.

- Problem Statement To develop a cooperative-owned digital service marketplace platform that enables Labour Cooperative Federations and Labour Cooperative Societies to provide verified household and community services while ensuring fair wages, worker welfare, and consumer trust.

**Expected Solution:**

Features

- Service provider registration and verification

- Worker skill profiling and certification

- Customer booking and scheduling system

- Geo-location based service matching

- Digital payments and invoicing

- Rating and feedback mechanism

- Worker welfare and insurance integration

- Emergency and on-demand service booking

- Cooperative federation administration dashboard

- Multilingual mobile application

- AI-based demand forecasting and workforce allocation

- Technology Components

- Mobile Applications

- Artificial Intelligence (AI)

- Geo-Spatial Technology

- Digital Payment Systems

- Cloud Computing

- Proposed Mode Software

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26090"></a>[90] SIH26090: AI-Driven Market Linkage and Smart Cataloging Mobile Application for Marginalized Artisans

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26090` (SIH26090) |
| **Problem Statement Title** | AI-Driven Market Linkage and Smart Cataloging Mobile Application for Marginalized Artisans |
| **Organization** | Ministry of Social Justice and Empowerment (MoSJE) |
| **Department** | Department of Social Justice and Empowerment |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

The government actively supports the socio-economic upliftment of marginalized communities,particularly micro-entrepreneurs, artisans, and weavers. Financial assistance is provided to establish small-scale manufacturing and handicraft units. To help these beneficiaries sell their goods, market exposure is facilitated through periodic physical exhibitions, cluster development programs, and trade fairs (such as Shilp Samagam, Surajkund Mela, and Dilli Haat).While physical exhibitions provide a temporary boost in sales, these micro-entrepreneurs lack continuous, year-round access to broader digital markets. Transitioning to the digital economy is hindered by low digital literacy, language barriers, and a lack of technical skills required to professionally photograph, price, and catalog products for modern e-commerce.

- Challenge There is a critical need to bridge the gap between traditional craftsmanship and modern digital commerce. Beneficiaries struggle to present their products competitively online. They often fail to capture high-quality images, write compelling product descriptions, or understand dynamic market pricing.The challenge is to build an intuitive, AI-driven mobile application that acts as a 'virtual business manager' for these artisans. The app must empower them to seamlessly digitize their inventory, optimize their listings using AI, and connect directly with larger B2B buyers or government e-marketplaces without requiring advanced technical knowledge.

**Expected Solution:**

Participants are expected to develop an AI-powered, cross-platform mobile application supported by a robust, scalable backend architecture. To ensure high adoption among low-literacy users, the application must feature a highly responsive, minimalist UI/UX design (incorporating modern, clean visual hierarchies and accessible layouts).

**Key features should include:**

1. AI Image Enhancer & Studio: A built-in camera module that utilizes AI to automatically remove cluttered backgrounds, correct lighting, and format product photos (e.g., textiles,handicrafts) to professional e-commerce standards.

2. Multilingual Auto-Cataloger: An NLP-based engine that allows artisans to describe their product via voice notes in regional languages. The AI should translate and generate SEO-friendly, professional product descriptions in English and Hindi.

3. Dynamic Pricing Assistant: A machine learning algorithm that analyzes the uploaded product image and description to suggest an optimal, competitive selling price based on current market trends and raw material costs.

- Impact Goals

- Provide marginalized micro-entrepreneurs with a continuous, year-round digital sales channel,reducing their dependency on periodic physical fairs.

- Drastically lower the barrier to entry for digital commerce through intuitive AI automation.

- Improve digital literacy and financial independence, ultimately increasing the average annual income of the target demographic.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26091"></a>[91] SIH26091: AI-Driven Hyper-Local Business Advisory and Financial Structuring Assistant for Rural Micro-Entrepreneurs

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26091` (SIH26091) |
| **Problem Statement Title** | AI-Driven Hyper-Local Business Advisory and Financial Structuring Assistant for Rural Micro-Entrepreneurs |
| **Organization** | Ministry of Social Justice and Empowerment (MoSJE) |
| **Department** | Department of Social Justice and Empowerment |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

The government actively promotes the economic empowerment of marginalized communities by providing concessional credit for income-generating activities. Under various schemes,beneficiaries are required to contribute a small margin money fraction—typically 10% of the total project cost—while the State Channelizing agencies (SCAs) Channelizing agencies(CAs) provide the remaining 90% as a concessional loan. For example, if an entrepreneur wishes to establish a ?10,00,00 enterprise, they must possess ?1,00,00 as their 10% contribution, making them eligible for a ?9,00,00 loan.

**These loans are categorized into specific tiers:**

? Micro Finance Scheme: For small units with a project cost up to ?1.40 lakh. The funding agency provides up to 90% (maximum ?1.25 lakh) at a concessional interest rate of 6.5% per annum for the beneficiary, to be repaid over 3 years (including a 3-month moratorium).

? Term Loan Scheme: For larger projects costing between ?1.40 lakh and ?50.00 lakh. The agency provides up to 90% (maximum ?45 lakh) at an interest rate of 8% per annum, to be repaid over 7 years (including a 6-month moratorium).

However, despite the availability of capital, many first-time rural entrepreneurs face a high rate of business stagnation. This is due to a profound lack of formal market research tailored to their specific geographical reality, compounded by poor financial literacy regarding loan structuring,margin requirements, and repayment schedules.

- Challenge Beneficiaries often select business activities based on anecdotal success rather than data-driven market demand, and they struggle to calculate exactly how much capital they need or which scheme they qualify for. A prospective entrepreneur in a specific Gram Panchayat (village) lacks the analytical tools to determine local market saturation, optimal pricing, localized threats, and their precise financial eligibility.

There is a critical need for an intelligent tool that democratizes institutional-grade business consulting. The challenge is to build a hyper-local AI Assistant accompanied by a Smart Scheme Calculator that guides the user through a comprehensive business feasibility study and financial structuring plan before they apply for funding.

**Expected Solution:**

Participants are required to develop an NLP-powered, multilingual AI Business Advisory Assistant tailored for rural and semi-urban geographies. The system should take basic inputs from the user:

Geographic Location (Village/Block/District), Available Margin Capital (e.g., ?1,00,000), and the Proposed Business Category (e.g., Dairy, Retail, Textiles etc).

**The application must feature two core modules:****Module 1: Hyper-Local Business Feasibility Report The AI must dynamically generate a localized strategy encompassing:**

1. Market Reach: Estimating the immediate consumer base within a 5–10 km radius of the village/block and identifying primary distribution channels.

2. Opportunity Analysis: Highlighting unserved or underserved niches within the chosen business sector in that specific local economy.

3. General Business Analysis (SWOT): A foundational breakdown of Strengths, Weaknesses,Opportunities, and Threats tailored to the specific micro-enterprise budget.

4. Threats Identification: Pinpointing local risks such as supply chain bottlenecks, seasonal demand fluctuations, or dependency on single buyers.

5. Competitor Mapping: Using localized demographic and economic data to estimate the density of existing similar businesses in the block.

6. Product Market Value: Suggesting optimal pricing strategies and predicting the local market value of the goods/services based on regional purchasing power.

Module 2: Smart Financial Calculator & Scheme Router An integrated financial engine that automatically processes the user's 'Available Margin Capital' to output a clear financial roadmap: 7.

**Financial Structuring:**

Automatically calculates the total feasible Project Cost (Available Margin / 10%) and the Maximum Loan Amount (90% of Project Cost).

Example: If the user inputs ?1,00,00 as available capital, the tool establishes a ?10,00,00 Project Cost and a ?9,00,00 loan eligibility.

**Scheme Auto-Selection:**

Routes the user to the correct scheme based on the calculated Project Cost.

Logic A: If Project Cost ? ?1.40 Lakh -> Selects Micro Finance Scheme (6.5% interest, 3-year tenure, 3-month moratorium).

Logic B: If Project Cost > ?1.40 Lakh and ? ?50.00 Lakh -> Selects Term Loan Scheme (8% interest, 7-year tenure, 6-month moratorium).

EMI & Moratorium Generator: Outlines the expected quarterly repayment schedule, operational costs, and working capital requirements, factoring in the specific moratorium periods.

- Impact Goals ? Reduce the failure rate of newly funded micro-enterprises by ensuring beneficiaries choose viable, locally relevant business models based on data.

? Eliminate financial confusion by clearly mapping a beneficiary's available cash (10%) to their maximum borrowing capacity (90%) and exact repayment obligations.

? Empower marginalized youth with enterprise intelligence, fostering a culture of data-backed, financially sound entrepreneurship at the grassroots level.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26092"></a>[92] SIH26092: AI-Driven Scheme Matching for Marginalized Entrepreneurs

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26092` (SIH26092) |
| **Problem Statement Title** | AI-Driven Scheme Matching for Marginalized Entrepreneurs |
| **Organization** | Ministry of Social Justice and Empowerment (MoSJE) |
| **Department** | Department of Social Justice and Empowerment |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

To promote the socio-economic empowerment of the Scheduled Caste (SC) population, the government provides concessional financial assistance and educational loans. Beneficiaries with an annual family income of up to ?5.00 Lakhs are eligible for various tailored financial products covering up to 90% of their project or education costs at highly concessional interest rates (typically 6.5% to 8% per annum).

However, direct loan applications are not entertained. Instead, funds are routed through a 'Channel Finance System' comprising over 100 Channel Partners, including State Channelizing Agencies (SCAs), Public Sector Banks (PSBs), Regional Rural Banks (RRBs), and NBFC-MFIs.

- Challenge Citizens often lack awareness regarding which specific credit scheme fits their needs—such as distinguishing between a Micro Finance Scheme for small projects (up to ?1.40 lakh), a Term Loan for larger projects (up to ?50.00 lakh), or an Educational Loan Scheme. Furthermore,applicants face difficulties identifying and locating the nearest authorized Channel Partner equipped to process their specific loan category. This fragmentation leads to offline confusion,misrouted applications, and delays in disbursement.The challenge is to develop an intelligent, multi-lingual digital platform or mobile application that bridges the gap between the beneficiaries and the channelizing agencies.

**Expected Solution:**

Participants are expected to develop a comprehensive platform that includes:

1. Smart Scheme Recommender: An AI/rule-based engine that takes basic user inputs (project type, estimated cost, income level, education status) and automatically recommends the most suitable credit or educational loan scheme.

2. Financial Calculator: A dynamic tool to calculate projected EMIs, accounting for specific scheme guidelines like maximum loan limits, interest rates (e.g., 6.5% to 15% depending on the scheme), and moratorium periods (3 to 12 months).

3. Geo-Spatial Partner Locator & Router: Integration of a mapping service to identify the nearest eligible Channel Partner (SCA/Bank/NBFC-MFI) based on the user's location and the partner's current fund utilization eligibility (ensuring applications aren't sent to partners with high NPAs or overdues).

- Impact Goals

- Enhance financial literacy among the target demographic regarding concessional lending.

- Improve transparency and efficiency in the channel finance ecosystem, ensuring faster disbursements and better fund utilization.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26093"></a>[93] SIH26093: AI-Based Real-Time Stress and Trauma Assessment Module for Victims/Complainants Accessing NHAA (14566) and Integrated Portal

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26093` (SIH26093) |
| **Problem Statement Title** | AI-Based Real-Time Stress and Trauma Assessment Module for Victims/Complainants Accessing NHAA (14566) and Integrated Portal |
| **Organization** | Ministry of Social Justice and Empowerment (MoSJE) |
| **Department** | Department of Social Justice and Empowerment |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Victims and complainants belonging to Scheduled Castes and Scheduled Tribes who approach the National Helpline Against Atrocities (14566), Integrated Portal, chatbot, mobile application, IVRS, or other digital platforms often experience severe emotional distress arising from caste-based discrimination, violence, rape, gang rape, murder of family members, social boycott, displacement, threats, and prolonged legal proceedings. Presently, there is no standardized mechanism for assessing the psychological condition and vulnerability of victims at the time of first contact with authorities.

- Problem Statement Design and develop an AI-enabled Real-Time Stress and Trauma Assessment Module that can assess the psychological stress, trauma, fear, anxiety, and vulnerability levels of victims/complainants interacting through NHAA (14566), the Integrated Portal, chatbot,IVRS, mobile application, or any other approved digital interface.

**Expected Solution:**

The solution should:

- Analyse voice interactions, speech patterns, pauses, pitch variation, emotional indicators, and textual narratives.

- Use Natural Language Processing (NLP), Speech Analytics, and Emotion AI to identify signs of trauma and distress.

- Generate a Stress Vulnerability Index (SVI) on a predefined scale.

- Categorize victims into Low, Moderate, High, and Critical Risk categories.

- Detect indicators of severe trauma, fear, depression, suicidal ideation,intimidation, social isolation, and extreme vulnerability.

- Automatically recommend counselling, legal aid, medical assistance, police intervention, witness protection, or emergency support based on risk level.

- Support multilingual interactions, including major Indian languages and dialects.

- Maintain privacy, informed consent, confidentiality, and ethical AI standards.

- Expected Outcomes

- Early identification of highly distressed victims.

- Prioritization of counselling and rehabilitation services.

- Improved victim-centric grievance redressal.

- Better allocation of support resources.

- Enhanced responsiveness of the helpline and integrated portal ecosystem.

- Stakeholders:

- Department of Social Justice and Empowerment

- National Helpline Against Atrocities (14566)

- State Governments and Union Territories

- District Administrations

- Counsellors and Mental Health Professionals

- Law Enforcement Agencies

- Rehabilitation and Welfare Authorities

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26094"></a>[94] SIH26094: AI-Powered Dynamic Mental Health Monitoring and Distress Prediction System for Victims of Atrocities

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26094` (SIH26094) |
| **Problem Statement Title** | AI-Powered Dynamic Mental Health Monitoring and Distress Prediction System for Victims of Atrocities |
| **Organization** | Ministry of Social Justice and Empowerment (MoSJE) |
| **Department** | Department of Social Justice and Empowerment |
| **Category** | Software |
| **Theme** | MedTech / BioTech / HealthTech |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Victims of atrocities frequently experience prolonged psychological distress after complaint registration due to threats, intimidation, repeated court appearances, delays in investigation and trial, social ostracism, economic hardship, and rehabilitation challenges.Existing mechanisms focus primarily on legal and financial support and do not provide continuous monitoring of victim well-being.

- Problem Statement Develop an AI-based Dynamic Mental Health Monitoring and Distress Prediction System that continuously monitors and predicts psychological distress among victims and complainants registered through NHAA (14566), the Integrated Portal, chatbot, mobile application, IVRS, or other approved communication channels throughout the investigation,trial, rehabilitation, and compensation process.

**Expected Solution:**

The system should:

- Conduct periodic interactions with victims through chatbot, IVRS calls, SMS, mobile applications, web portal, or helpline follow-up mechanisms.

- Analyse voice, text, behavioural responses, and engagement patterns using NLP, Sentiment Analysis, and Emotion AI.

- Generate a Dynamic Distress Score and longitudinal trend analysis.

- Predict escalation of psychological distress before a crisis situation emerges.

- Trigger alerts to counsellors, district authorities, and designated officials when predefined risk thresholds are crossed.

- Recommend appropriate interventions such as counselling, medical treatment, witness protection, relocation support, financial assistance, legal aid, or rehabilitation measures.

- Provide dashboards at district, State, and national levels for monitoring vulnerable victims and high-risk cases.

- Ensure explainable AI, privacy protection, data security, and compliance with applicable legal and ethical standards.

- Expected Outcomes

- Continuous monitoring of victim well-being.

- Early detection and prevention of mental health crises.

- Timely deployment of counselling and rehabilitation services.

- Strengthened victim confidence in the justice delivery system.

- Evidence-based decision-making for policymakers and administrators.

- Improved coordination among welfare, counselling, and law-enforcement agencies.

- Innovation Components

- Emotion AI

- Voice Stress Analytics

- Sentiment Analysis

- Predictive Risk Modelling

- Multilingual Conversational AI

- Explainable AI

- Automated Case Prioritisation

- Real-Time Risk Alerts

- Priority Use Cases

- Victims of rape and gang rape.

- Victims of murder, grievous hurt, and arson.

- Witnesses facing intimidation or threats.

- Families affected by caste-based violence.

Beneficiaries receiving relief, compensation, rehabilitation, and protection under the provisions of the Scheduled Castes and Scheduled Tribes (Prevention of Atrocities) Act, 1989.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26095"></a>[95] SIH26095: Smart Real-Time Monitoring & Inspection Mobile App

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26095` (SIH26095) |
| **Problem Statement Title** | Smart Real-Time Monitoring & Inspection Mobile App |
| **Organization** | Ministry of Social Justice and Empowerment (MoSJE) |
| **Department** | Department of Social Justice and Empowerment |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

- Problem Statement Develop a centralized mobile application for real-time monitoring, surprise inspections, CCTV surveillance integration, and random inspection assignment for projects/institutes/NGOs running under DoSJE schemes.

- Key Features

- Live CCTV feed integration from projects/institutes

- Random Video Conferencing (VC) connectivity with Project Incharge/Staff/Beneficiaries

- Real-time monitoring dashboard for Department officials

- Mobile-based inspection module for PMU/Inspection Teams

- Random assignment of inspection duties through AI/automation

- Geo-tagged inspection reports and live evidence capture

- AI-based anomaly and attendance analytics

- Stakeholders

- DoSJE Divisions

- PMU Teams

- NGOs/Institutes

- Beneficiaries

- State/District Authorities

- Expected Outcomes:

- Improved transparency and accountability

- Reduction in fake reporting and proxy functioning

- Real-time monitoring of projects

- Better inspection governance and compliance

- Enhanced citizen-centric service delivery

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26096"></a>[96] SIH26096: Digital Heritage Archive for Memorials, Manuscripts & Ambedkar: AI-Powered Institutional Archive and Audio-Visual Knowledge Platform

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26096` (SIH26096) |
| **Problem Statement Title** | Digital Heritage Archive for Memorials, Manuscripts & Ambedkar: AI-Powered Institutional Archive and Audio-Visual Knowledge Platform |
| **Organization** | Ministry of Social Justice and Empowerment (MoSJE) |
| **Department** | Department of Social Justice and Empowerment |
| **Category** | Hardware |
| **Theme** | Heritage & Culture |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Dr. B. R. Ambedkar's writings, speeches, constitutional debates, manuscripts,and historical contributions are spread across libraries, memorials, archives, and fragmented digital sources, making them difficult to access and preserve. Existing archival systems lack intelligent search, multilingual accessibility, and interactive learning features required for students, researchers, and visitors.Institutions such as Dr. Ambedkar International Centre require a modern digital platform through which visitors can explore Ambedkar's works, speeches, rare manuscripts, and historical records through interactive screens and audio-visual systems.

**Description:**

The proposed system aims to develop an AI-enabled Digital Heritage Archive and Institutional Knowledge Platform dedicated to Dr. B. R. Ambedkar. The platform will combine hardware and software components such as interactive touch-screen kiosks, smart displays, centralized archival servers, and AI-powered search systems.Visitors should be able to access speeches, books, constitutional debates, rare manuscripts,photographs, documentaries, and archival records through an easy-to-use digital interface.

**The system should support:**

- AI-powered semantic search and intelligent knowledge mapping.

- Full-Text and summarized access to writings and speeches.

- OCR-based digitization of old documents and manuscripts.

- Multilingual translation and audio narration features.

- Audio-video archival system for lectures, documentaries, and interviews.

- Interactive timeline and memorial story telling modules.

- AI Research Assistant for answering queries related to Dr. Ambedkar's works and constitutional ideas.

- The platform should also support secure digital preservation, metadata tagging, and institutional archival management.

**Expected Solution:**

A centralized hardware-software integrated digital archive system should be developed for institutions such as Dr. Ambedkar International Centre. The solution should include interactive kiosks and smart displays enabling visitors to search, study, listen to, and compile Dr. Ambedkar's writings, speeches, and historical records.The system should promote digital preservation, constitutional awareness, accessible learning, and immersive heritage experiences for researchers, students, and the general public.

#### Dataset & Reference Links

- Dr. Ambedkar Foundation.

- Constituent Assembly Debates Archive.

- National Digital Library of India.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26097"></a>[97] SIH26097: AI-Driven voice Assistant for livelihood Mapping and NSQF-Aligned Skilling Recommendations for SC Communities under GIA component of PM-AJAY

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26097` (SIH26097) |
| **Problem Statement Title** | AI-Driven voice Assistant for livelihood Mapping and NSQF-Aligned Skilling Recommendations for SC Communities under GIA component of PM-AJAY |
| **Organization** | Ministry of Social Justice and Empowerment (MoSJE) |
| **Department** | Department of Social Justice and Empowerment |
| **Category** | Software |
| **Theme** | Smart Education |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

- The Pradhan Mantri Anusuchit Jaati Abhyuday Yojana (PM-AJAY) aims to reduce poverty among Scheduled Caste (SC) communities through livelihood promotion, skill development, and enterprise support under its Grant-in-Aid (GIA) component. A major challenge in implementation is the identification of appropriate skill training pathways that align with both the aspirations of beneficiaries and the actual livelihood opportunities available in their local regions.

- Many target beneficiaries face barriers such as low digital literacy, limited awareness of modern trades, language constraints, and difficulty navigating text-heavy digital systems. As a result, there is often a mismatch between enrolled training programs and the beneficiary's interests, capabilities, or local market demand, leading to high dropout rates and poor post-training employment outcomes.

- To improve inclusion and effectiveness, there is a need for an AI-enabled conversational system that can interact naturally in regional languages and dialects, understand beneficiary aspirations, assess skill gaps, and recommend suitable NSQF aligned livelihood opportunities in and around the beneficiary.

- Basic Issues under GIA Component:

- Lack of proper road map and Planning of the Perspective plans from execution to implementation

- Identification of the participants Trained and skilled Financial consultants

- Job placement issue after the skilling programme

- Coordination Issues among the corporation, Ministry/Departments

- Inadequate Technical and support team at ground level

- Detailed Description The proposed solution should be an AI-driven, multilingual, voice-based virtual livelihood assistant capable of conducting conversational interviews with beneficiaries from aspirational SC communities. Instead of relying on traditional form-filling methods, the system should use voice interactions to collect information such as:

- Educational background

- Existing or traditional family occupations

- Current livelihood activities

- Skills and interests

- Mobility and physical constraints

- Preference for self-employment or wage employment

- Local economic realities and opportunities The assistant should support regional languages and dialects to ensure accessibility for users with low literacy or limited digital exposure. The interaction should feel empathetic and conversational rather than administrative.The collected information should be analyzed using AI/MLbased profiling and recommendation mechanisms to identify:

- Suitable NSQF-aligned training programs

- Relevant trades and livelihood pathways

- Skill gaps requiring intervention

- Region-specific employment or enterprise opportunities The system should also function effectively in lowconnectivity and low-tech environments through deployment channels such as:

- IVR-based phone calls for feature phone users

- WhatsApp voice-note interfaces Lightweight mobile or kiosk-based solutions

**Expected Solution:**

An AI-powered multilingual voice assistant application designed to help SC beneficiaries under PM-AJAY identify suitable skill training and livelihood opportunities.The app will support regional languages and local dialects, allowing users to interact through simple voice conversations instead of text-based forms.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26098"></a>[98] SIH26098: Development of a Low-Cost Precision Guidance and Smart Electronic Fuze System for a 155 mm Artillery Shell

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26098` (SIH26098) |
| **Problem Statement Title** | Development of a Low-Cost Precision Guidance and Smart Electronic Fuze System for a 155 mm Artillery Shell |
| **Organization** | Ministry of Defence (MoD) |
| **Department** | Yantra India Limited, Ambajhari,Nagpur |
| **Category** | Hardware |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

- Problem Title Design and Development of a Precision Guidance Kit with Canard Actuation and Multi-Mode Electronic Fuze for a 155 mm Artillery Shell

**Background:**

Conventional 155 mm artillery shells rely on unguided ballistic trajectories, resulting in relatively high Circular Error Probable (CEP), particularly at long ranges. Improving strike accuracy while utilizing existing shell hardware can significantly enhance operational effectiveness, reduce ammunition consumption, and minimize collateral damage.

The YIL (Yantra India Limited) possesses extensive expertise in manufacturing the mechanical hardware of 155 mm artillery shells and seeks innovative solutions to transform conventional shells into precision-guided munitions through the integration of an advanced guidance and fuze system.

- Problem Statement Develop a compact, robust, and cost-effective precision guidance solution for a standard 155 mm artillery shell by integrating:

- A Canard Actuation Assembly (CAA) for in-flight trajectory correction.

- A Guidance,Navigation and Control (GNC) system capable of improving terminal accuracy.

- A Multi-mode Electronic Fuze supporting:

- Proximity Mode

- Time Mode

- Impact Mode

- Embedded electronics and software for real-time flight control.

- Power management suitable for high-g launch and flight conditions.

- Communication and programming interface for fuze configuration prior to firing.

The integrated system should achieve a Circular Error Probable (CEP) of 30 meters or better, while maintaining compatibility with the existing 155 mm shell design and surviving the extreme mechanical and environmental conditions experienced during artillery launch and flight.

- Expected Outcome Participants should propose a complete system architecture including:

- Guidance and navigation methodology.

- Canard deployment and actuation mechanism.

- Flight control algorithms.

- Multi-mode electronic fuze design.

- Sensor selection (e.g., IMU, GNSS, barometric sensor, proximity sensor, etc.).

- Embedded hardware architecture.

- Power supply and environmental protection strategy.

- Simulation and validation methodology.

- Manufacturability and cost optimization.

- Desired Deliverables

- System architecture document.

- CAD model of the canard actuation assembly.

- Electronics block diagram.

- Guidance and control algorithm.

- Simulation demonstrating trajectory correction.

- Prototype or proof-of-concept (preferred).

- Performance estimation showing the capability to achieve a CEP of ?30 m.

- Constraints

- Compatible with a standard 155 mm artillery shell casing.

- Must withstand high launch acceleration, vibration, spin, and harsh environmental conditions.

- Low Size, Weight, Power, and Cost (SWaP-C).

- High reliability and safety.

- Modular design suitable for future upgrades.

- Skills Expected from Participants

- Mechanical Design

- Mechatronics

- Embedded Systems

- Control Systems

- Guidance, Navigation & Control (GNC)

- Aerospace Engineering

- Electronics

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26099"></a>[99] SIH26099: AI-Driven Standardization and Harmonization of Material Codes Across CPSEs

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26099` (SIH26099) |
| **Problem Statement Title** | AI-Driven Standardization and Harmonization of Material Codes Across CPSEs |
| **Organization** | Ministry of Petroleum & Natural Gas |
| **Department** | Chennai Petroleum Corporation Limited(CPCL) |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Central Public Sector Enterprises (CPSEs) operating in sectors such as Oil & Gas, Power, Steel, Mining and Heavy Engineering procure and maintain a large number of similar or functionally equivalent materials. However, the same material may be assigned different material codes, descriptions, specifications, units of measurement and classification across different CPSEs.

This results in duplication of material masters, inconsistent descriptions, difficulty in identifying equivalent materials, fragmented procurement data, higher inventory levels and limited opportunities for collaborative procurement.

A unified and intelligent approach is therefore required to standardize, harmonize and rationalize material master data across CPSEs.

**Description:**

The proposed solution envisages development of an AI-powered National Unified Material Master Framework capable of analysing material codes, descriptions, specifications, technical parameters and historical procurement data from multiple CPSEs.

The system shall use Artificial Intelligence, Machine Learning and Natural Language Processing (NLP) techniques to identify identical, duplicate, near-duplicate and functionally equivalent materials across different ERP/SAP systems.

The platform should automatically recommend standardized material descriptions, specifications, classifications and a Common National Material Code, while retaining mapping with the respective CPSE's existing material codes.

The system should provide intelligent matching and recommendation capabilities, allowing users to review, validate and approve proposed mappings. It should also support migration/mapping of legacy material codes and seamless integration with existing SAP/ERP systems.

**Expected Solution:**

An AI-driven Unified Material Master Platform shall be developed with the following capabilities:

- AI-based matching of material descriptions and specifications across CPSEs.

- Identification of duplicate, near-duplicate and equivalent materials.

- Automated standardization of material descriptions and technical attributes.

- Intelligent classification and categorization of materials.

- Generation/recommendation of a Common National Material Code.

- Mapping of existing CPSE material codes to the common national code.

- Legacy material code rationalization and migration support.

- User validation and approval workflow for AI recommendations.

- Dashboard for material master analytics and duplicate detection.

- Audit trail and governance mechanism for material master changes.

- Integration capability with SAP/ERP systems of participating CPSEs.

The proposed solution should enable 'One Nation – One Material Code' for common materials, while maintaining traceability to individual CPSE material codes.

- Key Capabilities 1. AI Material Matching & Recommendation 2. Material Standardization & Classification 3. Duplicate / Near-Duplicate Detection 4. Common National Material Code Generation 5. CPSE Code Mapping & Migration Support 6. Material Master Dashboard & Analytics 7. Audit Trail & Governance 8. SAP / ERP Integration

- Expected Impact

- One Nation – One Common Material Code

- Reduction in duplicate and redundant material codes

- Improved material master data quality

- Better inventory optimization and visibility

- Reduced procurement cost through demand aggregation

- Improved inter-CPSE material identification and collaboration

- Faster procurement and specification finalization

- Better data-driven procurement decisions

- Foundation for common procurement and strategic sourcing across CPSEs

#### Dataset & Reference Links

CPSE Material Master Data / Sample Material Master Dataset –To be provided by participating CPSEs

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26100"></a>[100] SIH26100: AI-Powered Integrated Bid Compliance Verification Platform for GeM Procurement

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26100` (SIH26100) |
| **Problem Statement Title** | AI-Powered Integrated Bid Compliance Verification Platform for GeM Procurement |
| **Organization** | Ministry of Petroleum & Natural Gas |
| **Department** | Chennai Petroleum Corporation Limited(CPCL) |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Government procurement through the Government e-Marketplace (GeM) involves verification of multiple statutory, regulatory and eligibility requirements of bidders.

Procurement officers are required to examine and validate documents and information related to Udyam/MSME registration, GST registration and return filing, PAN and Income Tax compliance, Make in India/local content, EPFO/ESIC compliance, Startup India, NSIC, OEM authorization, DigiLocker, blacklisting/debarment and other applicable statutory requirements.

The verification process is largely document-intensive and requires cross-checking information across multiple government portals and databases. This results in significant manual effort, longer tender evaluation time and the possibility of inconsistencies or human errors.

**Description:**

The problem statement envisages development of an AI-powered integrated bid compliance verification platform that can automatically verify the eligibility and compliance status of bidders participating in GeM procurement.

The proposed platform shall integrate with relevant Government portals and databases and retrieve/verify bidder information such as Udyam Registration, GSTN, Income Tax, PAN, MCA21, Startup India, NSIC, EPFO, ESIC, DigiLocker, Make in India, BIS/DPIIT and other applicable sources.

An AI Verification Engine shall analyse the submitted bidder documents and portal-derived information, identify missing or inconsistent information, validate applicable compliance requirements and generate an overall compliance assessment. The system shall provide a Compliance Dashboard displaying the compliance score, risk level, document verification status, pending requirements and AI-generated recommendations. The final decision regarding qualification/disqualification shall remain with the Procurement Officer.

**Expected Solution:**

An AI-enabled integrated platform shall be developed for automated verification of bidder compliance in GeM procurement. The solution shall:

1. Integrate with relevant Government portals/databases for automated verification.

2. Verify Udyam/MSME status and other applicable statutory registrations.

3. Verify GST registration and return filing status.

4. Verify PAN and Income Tax compliance.

5. Check Make in India/local content requirements.

6. Verify EPFO/ESIC compliance wherever applicable.

7. Verify Startup India, NSIC and OEM authorization requirements.

8. Perform DigiLocker/document verification.

9. Identify blacklisting and debarment status.

10.Check other applicable statutory and tender-specific compliance requirements.

11.Use AI to identify missing, inconsistent or non-compliant information.

12. Generate an overall Compliance Score and Risk Level.

13. Provide an AI-generated recommendation to the Procurement Officer.

14.Maintain an auditable record of verification and compliance checks.

The final qualification/disqualification decision shall remain with the Procurement Officer, with the AI system functioning as a decision-support and verification tool.

- Key Capabilities 1. Multi-Portal Integration – Udyam, GSTN, PAN, GEM etc., 2. AI Document Verification – Automated extraction,validation & cross-verification 3. Automated Compliance Engine – Tender-specific eligibility & statutory compliance checks 4. Risk & Compliance Scoring – Overall compliance score with bidder risk classification 5. AI Recommendation Engine – Identifies gaps,discrepancies & recommends compliance status 6. Audit Trail & Dashboard – Centralized verification status,evidence & decision support

- Expected Impact

- 60–80% Reduction in Verification Effort

- Faster Tender Evaluation & Award

- Improved Compliance & Transparency

- Reduced Human Errors & Inconsistencies

- Better Bidder Screening & Risk Identification

- Standardized Verification Across CPSEs

- Complete Auditability & Traceability

#### Dataset & Reference Links

To be provided / Dummy bidder and tender datasets may be used for development and testing.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26101"></a>[101] SIH26101: Develop an AI enabled learning platform that identifies competency gaps, recommends personalized training through integration with the iGOT Karmayogi ecosystem, and capable of generating Quizzes and Multiple choice questions (MCQs) from uploaded learning materials to strengthen capacity building in India's Official Statistical System.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26101` (SIH26101) |
| **Problem Statement Title** | Develop an AI enabled learning platform that identifies competency gaps, recommends personalized training through integration with the iGOT Karmayogi ecosystem, and capable of generating Quizzes and Multiple choice questions (MCQs) from uploaded learning materials to strengthen capacity building in India's Official Statistical System. |
| **Organization** | MoSPI |
| **Department** | Data Informatics & Innovation Division (DIID) |
| **Category** | Software |
| **Theme** | Smart Education |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

India's statistical system is undergoing rapid technology advancement with increasing adoption of Artificial Intelligence (AI), Machine Learning (ML), Big Data Analytics, GIS, cloud computing, and modern statistical methodologies. Officials engaged in data collection, processing, analysis, dissemination, and policy support require continuous upskilling to meet evolving technological and domain-specific requirements.

While the iGOT Karmayogi platform offers a vast repository of learning resources, officials often face challenges in identifying the most relevant courses aligned with their job roles, current competencies, and future skill requirements. Presently, there is no intelligent mechanism that performs comprehensive skill-gap assessment and recommends personalized learning pathways specifically for professionals working in Official Statistics.

Artificial Intelligence (AI) and emerging digital technologies are rapidly transforming the way organizations operate, deliver services, and make decisions. However, many organizations face challenges such as limited AI awareness, skill gaps, inadequate technical expertise, and the absence of structured, scalable training mechanisms.

Traditional training approaches often lack personalization, continuous assessment, and real-time learner support, making it difficult to meet diverse learning needs.

An AI enabled Learning Management System can assess learners existing competencies through learner's profile, identify skill gaps, and recommend personalized training through integration with the iGOT Karmayogi platform based on job roles, experience levels, and organizational requirements. Through adaptive learning modules, AI powered virtual assistants, automated assessments, and realtime feedback mechanisms, learners receive targeted training that improves engagement and learning outcomes. The LMS supports continuous capacity building by offering structured courses, hands-on exercises, virtual labs on emerging technologies such as Artificial Intelligence, Data Science, Cloud Computing, Cybersecurity, and Automation. AI driven analytics and dashboards enable organizations to monitor learner progress, evaluate training effectiveness, predict future skill requirements, and make informed decisions regarding workforce development. By integrating personalized learning, competency mapping, performance monitoring, and intelligent content delivery, the AI enabled LMS ensures effective adoption of emerging technologies and helps create a future-ready, digitally skilled workforce.

- Detailed Description The proposed solution aims to develop an AI-enabled Skill Intelligence and Learning Platform that strengthens capacity building for officials engaged in India's Official Statistical System by integrating with the iGOT Karmayogi ecosystem. The platform should leverage Artificial Intelligence to assess competencies, identify skill gaps, and recommend personalized learning pathways aligned with each official's job role, responsibilities, and career progression.

The system should automatically create a comprehensive competency profile for every official using information such as designation, department, job role, current assignment, educational qualifications, work experience, and previous trainings.

Based on this profile, the platform should evaluate the official's existing competencies against predefined competency frameworks for Official Statistics and identify knowledge and skill gaps.

**The AI engine should map competencies across multiple domains, including:**

- Statistical Competencies: Survey Design, Sampling, National Accounts, Price Statistics, Labour Statistics, Agricultural Statistics, Industrial Statistics, SDG Indicators, Metadata Standards, and Data Quality Frameworks.

- Technical Competencies: Python, R, SQL, Stata, SPSS, SAS, GIS, Data Visualization, AI/ML, Cloud Computing, APIs, and Open Data.

- Digital Governance: Cybersecurity, Data Privacy, Digital Signatures, Government Cloud, and Digital Public Infrastructure.

- Behavioural and Managerial Competencies: Leadership, Communication, Project Management, Ethics, Decision Making, and Change Management.

Using AI techniques such as Machine Learning, Natural Language Processing (NLP), Large Language Models (LLMs), semantic search, and competency mapping, the platform should recommend personalized learning pathways from the iGOT Karmayogi course repository. Recommendations should consider the official's current competency level, previous learning history, departmental priorities, future job requirements, emerging technologies, and career progression.

The platform should integrate seamlessly with iGOT Karmayogi APIs to retrieve course catalogues, recommend relevant courses, monitor enrolment and completion status, and update competency scores automatically.

To support continuous learning, the solution should provide AI-powered virtual assistants for learner support, adaptive assessments, interactive learning modules, virtual laboratories, quizzes, and multilingual learning resources. The system should continuously monitor learner progress and dynamically update recommendations based on performance and newly acquired competencies.

To strengthen capacity building, the platform should support AI powered Intelligent Assessment Engine capable of generating objective type questions (MCQs), and quizzes from uploaded learning materials such as documents, presentations, videos etc. It should provide instant evaluation, explanations for correct answers, and personalized feedback to reinforce learning outcomes. This feature should enable trainers to automatically create assessments and quizzes, and evaluate learner understanding, and provide instant feedback, thereby enhancing continuous learning and competency assessment. The engine should leverage Large Language Models (LLMs), Natural Language Processing (NLP), etc.

A comprehensive analytics dashboard should be provided for both employees and administrators. The employee dashboard should display current competency levels, identified skill gaps, recommended learning paths, learning hours, and overall progress. The administrator dashboard should provide organization-wide insights into workforce competencies, training effectiveness, competency distribution, emerging skill requirements, and predictive analytics for future capacity-building needs.

The solution should be designed as a secure, scalable, cloud-ready, and interoperable web platform capable of integrating with existing government digital ecosystems through standard APIs. The platform should support role-based access control, Single Sign-On (SSO), and secure data exchange while ensuring compliance with government cybersecurity and data privacy guidelines.

The proposed AI-enabled Skill Intelligence Platform will enable data-driven workforce development by delivering personalized, competency-based learning recommendations, improving utilization of iGOT Karmayogi resources, and creating a future-ready statistical workforce equipped with modern statistical, analytical, and digital skills required for the evolving needs of India's Official Statistical System.

**Expected Solution:**

The AI enabled platform for training and capacity building by providing personalized learning recommendations, improving competency levels of officials, enhancing utilization of iGOT Karmayogi resources, and creating a future-ready workforce equipped with modern statistical and digital skills. Additionally, AI powered generation of objective type questions and quizzes from uploaded learning content for automated assessments and self evaluation.

**The solution should provide:**

- AI-based competency assessment

- Automated skill-gap analysis

- Seamless iGOT integration

- Personalized learning recommendations of iGOT Course Module as well as NSSTA's TPAC recommended Training Programme

- AI powered generation of MCQ and Quizzes from uploaded learning content.

- Interactive dashboards for Learner and Administrator

- Secure, and scalable web application

#### Dataset & Reference Links

nssta.gov.in, mospi.gov.in

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26102"></a>[102] SIH26102: Development of an AI-powered system to detect anomalies, fraud, and inefficiencies in MPLAD Scheme implementation regd.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26102` (SIH26102) |
| **Problem Statement Title** | Development of an AI-powered system to detect anomalies, fraud, and inefficiencies in MPLAD Scheme implementation regd. |
| **Organization** | MoSPI |
| **Department** | Data Informatics & Innovation Division (DIID) |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

The Members of Parliament Local Area Development Scheme (MPLADS) is a Central Sector Scheme under which Hon'ble Members of Parliament recommend developmental works for creation of durable community assets and provision of basic civic amenities. The Scheme involves large-scale fund utilization and execution of thousands of works across the country through multiple implementing agencies and administrative authorities. Given the volume and complexity of financial and project-related data generated under the Scheme, there is a need for an AI-powered solution that can leverage machine learning and advanced analytics to detect trends and anomalies in expenditure patterns, fund utilization, cost estimates, and work execution, thereby enabling early identification of potential fraud, inefficiencies, and non-compliance while enhancing transparency, accountability, and effective monitoring of MPLADS works.

**Description:**

Develop an AI-powered monitoring and analytics platform for MPLADS that leverages Machine Learning (ML), Artificial Intelligence (AI), and advanced data analytics to identify trend, anomalies, irregularities, and potential fraud in fund utilization and project execution. The solution should analyze data relating to sanctions,expenditures, cost estimates, work progress, payments, and asset creation to detect unusual patterns, cost overruns, duplicate works, delayed projects, and deviations from established norms. The system should generate risk-based alerts, predictive insights, and decision-support dashboards for Members of Parliament, State Nodal Authorities, District Authorities, and the Ministry. The platform should also facilitate automated compliance monitoring, trend analysis, and early warning mechanisms to improve transparency, accountability, and efficiency in the implementation of MPLADS works across the country.

**Expected Solution:**

The proposed solution should be an AI-powered platform that helps monitor MPLADS works and fund utilization in a smarter and more efficient manner. By analyzing data related to project approvals, expenditures, payments, work progress, and completion status, the system should be able to identify unusual patterns, delays, cost overruns, duplicate works, and potential cases of misuse of funds. It should automatically generate alerts and highlight high-risk cases that require attention from the concerned authorities. The platform should provide easy-to-understand dashboards and insights to Members of Parliament, State Nodal Authorities, District Authorities, and the Ministry, enabling them to make informed decisions and take timely corrective action. By leveraging artificial intelligence and data analytics, the solution should enhance transparency, strengthen accountability, reduce manual monitoring efforts, and support more effective implementation of MPLADS works across the country.

#### Dataset & Reference Links

https://mplads.mospi.gov.in/digigov/dashboard.html

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26103"></a>[103] SIH26103: Use case on web-based integrated project-monitoring platform

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26103` (SIH26103) |
| **Problem Statement Title** | Use case on web-based integrated project-monitoring platform |
| **Organization** | MoSPI |
| **Department** | Data Informatics & Innovation Division (DIID) |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

The Infrastructure & Project Monitoring Division (IPMD), Ministry of Statistics and Programme Implementation (MoSPI) monitors the Central Sector Infrastructure Projects costing ?150 crore and above, across all the infrastructural Ministries/ Departments. The project monitoring was undertaken through the Online Computerised Monitoring System (OCMS) since 2006, which served as the primary repository of project-level information relating to project cost, expenditure, timelines and implementation status. Over nearly two decades, OCMS generated a valuable historical database capturing project implementation trends, cost overruns and time overruns across sectors. Later, OCMS was modernized to Project Assessment, Infrastructure Monitoring and Analytics for Nation-building (PAIMANA) portal, to enable a comprehensive and integrated project-monitoring ecosystem.

- PAIMANA Portal and Data Ecosystem PAIMANA is a web-based integrated project-monitoring platform designed to function as a national repository of infrastructure projects. It captures project-level information relating to approved cost, revised cost, expenditure, implementation timelines, physical progress, milestones, implementing agencies and project status. The information on infrastructure projects is updated on a monthly basis, through role-based access and APIs.

As of April 2026 , the PAIMANA project-monitoring framework tracks 1,981 ongoing infrastructure projects across 17 Central Ministries/Departments covering 22 infrastructure sectors . These projects have an aggregate original cost of approximately ?37.13 lakh crore, revised cost of approximately ?42.78 lakh crore and cumulative expenditure of approximately ?20.36 lakh crore. The monitored portfolio covers major sectors including Transport & Logistics, Energy, Water & Sanitation, Communication, Social Infrastructure, Coal, Steel and Mining.

Despite the availability of comprehensive project-monitoring data, infrastructure projects frequently encounter challenges such as cost overruns, time overruns, delays in milestone achievement, contractual and implementation bottlenecks, resource constraints and execution risks. These challenges often result in significant escalation of project costs and delays in the creation of public infrastructure assets.

While the existing PAIMANA framework provides robust capabilities for monitoring and reporting project progress, there is a growing need to move beyond descriptive monitoring towards predictive and prescriptive monitoring. The scale, diversity and continuous availability of project data provide an opportunity to strengthen infrastructure project monitoring through data-driven analytical and decision-support systems.

- AI Opportunity from PAIMANA Database The historical project-monitoring database available through OCMS combined with the recent PAIMANA portal provides a unique and comprehensive repository of infrastructure project data spanning nearly two decades. The database encompasses projects of varying sizes, sectors, geographical locations, implementing agencies, expenditure patterns and implementation timelines.

The availability of large-scale historical repository of project data together with continuously updated project information received through integrated digital systems provides a strong foundation for the application of Artificial Intelligence (AI), Machine Learning (ML) and Large Language Models (LLMs). These technologies can be leveraged to develop predictive analytics and early warning decision support systems for identifying cost overruns, schedule delays and implementation risks, thereby enabling proactive interventions and evidence-based decision-making in infrastructure project monitoring.

- Problem Statement and Scope of Work for Hackathon Under the broader theme of 'AI for Infrastructure Monitoring', the proposed use-case seeks to develop an AI-powered Predictive Analytics and Early Warning System capable of analysing the large volume of project data available at PAIMANA portal, using Open-Source Tools and Softwares, to identify projects that are likely to experience cost escalation, schedule delays and implementation risks before such issues materialise.

The solution should assist policymakers, project administrators and monitoring agencies in prioritising interventions, improving project execution outcomes and enhancing the effectiveness of infrastructure project monitoring. The use-case aims to transform project monitoring from a descriptive reporting framework into a predictive and prescriptive decision-support system capable of generating actionable insights for evidence-based decision-making. In this regard, the proposed solution may address the following technical dimensions:

a)Development and evaluation of statistical analysis and predictive models using open-source tools and methodologies for analysing project performance and forecasting cost overruns, time overruns and implementation risks.

b)Assessment of whether Artificial Intelligence (AI) and Machine Learning (ML) techniques provide significant gains over conventional statistical methods in terms of prediction accuracy, early warning capabilities and decision-support for infrastructure project monitoring.

c)Development of prediction and analytical models based on the existing Common Upload Form (CUF) fields available in the project-monitoring framework, along with an assessment of the extent to which predictive performance is attributable to the current CUF fields vis-à-vis additional variables that are not presently captured in the CUF.

It is suggested/ desirable that the proposed solution may leverage any of the following (using Open-Source Tools/ Softwares); (a) Artificial Intelligence (AI), (b) Machine Learning (ML), (c) Big Data Analytics, (d) Forecast Modelling and (e) Large Language Models (LLMs); to predict cost and time overruns, generate project-level risk scores, identify emerging implementation challenges, and provide early warning signals and decision-support mechanisms for timely interventions. However, these suggested techniques are only indicative and non-exhaustive. The students may adopt alternative or additional methodologies, tools, frameworks, or analytical approaches, as deemed appropriate, to achieve the stated objectives.

- Possible Expected Outcomes and Evaluation An indicative solution proposed by the student should comprise of any of the outcomes given below:

a. Cost Overrun Prediction Model;

b. Time Overrun Prediction Model;

c. Project Risk Scoring Framework;

d. Early Warning Alert System;

e. Benchmarking and Comparative Analytics Module;

f. Cost Escalation Driver Analysis Module;

g. AI-powered Monitoring Dashboard;

h. LLM-enabled Project Intelligence Assistant;

i. Documentation and deployment framework.

The above outcomes are indicative and non-exhaustive. Students may propose alternative outputs, features or solution components that effectively address the problem statement. It is desirable that only open-source tools/ software be used to achieve the stated objectives. The selection and application of such methods shall remain at the discretion of the student, subject to demonstrating their suitability, effectiveness, and alignment with the project requirements.

#### Dataset & Reference Links

The Project Monitoring Report for the month of April, 2026 may be referred for developing an understanding on the key field/ parameters through https://paimana-proj.mospi.gov.in/ReportPage

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26104"></a>[104] SIH26104: AI-Powered Real-Time Detection and Prevention of Voice Cloning Impersonation Attacks

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26104` (SIH26104) |
| **Problem Statement Title** | AI-Powered Real-Time Detection and Prevention of Voice Cloning Impersonation Attacks |
| **Organization** | All India Council for Technical Education (AICTE) |
| **Department** | Cyber Security Cell |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Recent advancements in generative AI and neural speech synthesis have made high-fidelity voice cloning possible from only a few seconds of recorded audio. Threat actors are exploiting these capabilities to impersonate CXOs,government officials, and trusted individuals in order to initiate fraudulent financial transactions, manipulate employees,or bypass verification procedures in high-risk workflows. Conventional call verification methods—such as caller ID, manual call-back, and basic voice familiarity—are no longer sufficient to distinguish genuine callers from AI-generated or manipulated voices, especially in high-pressure social engineering scenarios.

These attacks are increasingly orchestrated over VoIP, mobile networks, and enterprise collaboration platforms,sometimes combined with leaked personal information to create highly convincing narratives. The absence of automated detection of synthetic or cloned voices in real time significantly increases the likelihood of large-scale financial fraud and reputational damage to institutions that rely heavily on telephonic instructions and approvals.

- Problem Statement Current telephony and communication ecosystems lack a robust, AI-driven mechanism to detect and flag voice cloning or synthetic speech impersonation during live calls. Existing solutions rarely perform granular analysis of acoustic artifacts, prosody, and speech generation patterns and typically cannot provide an actionable risk score while the conversation is ongoing.There is a need for an end-to-end security framework that can analyze incoming voice streams in near real time,determine the likelihood that the caller is using a cloned or AI-generated voice, and provide timely alerts and recommendations before sensitive actions—such as approval of fund transfers or disclosure of confidential information—are taken. The solution must be privacy-preserving, scalable across telecom and enterprise environments, and support multilingual contexts with diverse Indian accents and dialects.

- Proposed Solution Develop an AI-powered, real-time voice integrity verification framework that integrates advanced deep learning,digital signal processing, and contextual analysis to detect AI-generated or manipulated voices. The system should continuously process live or near live audio streams from telephony, VoIP, and collaboration platforms,extract discriminative features, and compute a dynamic impersonation risk score.The framework should expose APIs and SDKs for seamless integration with banking applications, enterprise communication systems, and telecom operator infrastructures, enabling proactive fraud prevention and enhanced cyber resilience in voice channels.

- Key Components

- Multi-Layer Voice Authenticity Analysis o Acoustic and spectral analysis using deep learning models to detect synthesis artifacts, phase inconsistencies, and spectral signatures indicative of cloned or AI-generated audio.

o Prosody and behavioral analysis to model speech rhythm, pitch contours, pauses, and microvariations, differentiating natural human speech from neural TTS outputs.

o Cross-session consistency checks comparing ongoing call features against historical genuine samples (where available) to detect anomalies in speaker identity.

- Real-Time Risk Scoring Engine o Continuous computation of a confidence/risk score indicating the probability of impersonation or synthetic speech.

o Threshold-based alerting logic configurable for different risk scenarios (for example, high-value transaction calls, privileged access approvals).

o Contextual enrichment using metadata such as call origin, known contact information, transaction context, and historical fraud indicators.

- Alerting and User Interaction Layer o Multi-channel alert mechanisms (UI prompts, SMS/email, in-app notifications) for frontline staff and end users.

o Pre-transaction warning prompts recommending secondary verification such as call-back, multifactor authentication, or escalation to supervisors.

o Configurable workflows for banks,enterprises, and government agencies to define automated responses when impersonation risk crosses thresholds.

- Privacy and Compliance Module o Minimal retention of voice recordings with options for on-device or edge inference to reduce central storage of sensitive audio data.

o Support for anonymization or feature-only logging to comply with data protection and privacy requirements.

- Platform and Integration APIs o REST/gRPC APIs and SDKs for integration with core banking systems, contact center platforms, enterprise communication tools, and telecom networks.

o Support for multiple Indian languages and regional accents through language-agnostic feature extraction and language-specific acoustic models.

- Expected Outcomes

- Significant reduction in financial fraud and social engineering incidents driven by voice cloning and AIenabled impersonation.

- Improved trust and assurance in voice-based communication channels for individuals, financial institutions, enterprises, and government organizations.

- Early detection of AI-driven social engineering attacks, enabling proactive containment and incident response.

- A reusable security layer for telecom operators and enterprises that strengthens overall cyber resilience and aligns with national cybersecurity objectives.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26105"></a>[105] SIH26105: AI-Powered Continuous Cyber Risk Quantification and Investment Optimization Platform

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26105` (SIH26105) |
| **Problem Statement Title** | AI-Powered Continuous Cyber Risk Quantification and Investment Optimization Platform |
| **Organization** | All India Council for Technical Education (AICTE) |
| **Department** | Cyber Security Cell |
| **Category** | Software |
| **Theme** | Blockchain & Cybersecurity |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Enterprises and institutions invest heavily in cybersecurity tools, compliance programs, and risk management initiatives, yet cyber risk is still predominantly communicated using qualitative ratings such as 'Low','Medium', or 'High'.

These coarse categories fail to express the potential financial impact of cyber threats,making it difficult for senior management, boards, and regulators to evaluate whether current cyber investments are adequate or optimally allocated.

Cyber risk is inherently dynamic: new vulnerabilities emerge, threat actors change tactics, business services are added or retired, and security controls mature over time. Most current risk assessment practices rely on periodic, manual exercises, resulting in stale risk registers and limited visibility into the organization's real-time cyber exposure. This gap leads to suboptimal prioritization of remediation efforts, under- or over-spending on security controls, and weak alignment between technical risk metrics and business decision-making.

- Problem Statement Design and develop an AI-powered platform that continuously quantifies cyber risk in monetary terms by correlating technical security telemetry with business asset criticality and control effectiveness. The platform must estimate the likelihood and financial impact of cyber incidents, identify key risk drivers, and recommend cost-effective mitigation strategies under explicit budget constraints.The solution should bridge the gap between technical cybersecurity metrics and business language, enabling CISOs, risk officers, and executive leadership to make informed, data-driven decisions about cyber risk and security investment.

- Proposed Solution Develop a cloud-ready cyber risk analytics platform that ingests data from multiple enterprise security and IT sources—such as vulnerability management, SIEM, IAM, EDR, CSPM, asset inventories, and threat intelligence feeds—and uses AI/ML models to compute continuous risk scores and estimated financial exposure, such as Expected Annual Loss. The system should provide interactive dashboards and decision-support tools that allow stakeholders to simulate remediation scenarios, evaluate investment options, and understand the return on security investment.The platform must be capable of mapping risk metrics to established cybersecurity frameworks, including ISO/IEC 27001, NIST Cybersecurity Framework, CIS Controls, RBI Cyber Security Framework, and SEBI Cybersecurity and Cyber Resilience Framework, supporting both regulatory reporting and internal governance.

- Key Components

- Risk Quantification Engine o Continuous aggregation and normalization of data from vulnerability scanners, SIEM, IAM, EDR,CSPM, asset inventory, and other security tools.

o Statistical and ML-based estimation of incident likelihood and potential business impact, including downtime costs, data breach costs, regulatory penalties, and reputational effects.

o Calculation of enterprise cyber risk as financial exposure metrics (for example, Expected Annual Loss and Value at Risk) at organization, business unit, and asset levels.

o Asset criticality modeling to weigh technical findings based on business importance and service dependencies.

o Control effectiveness evaluation using telemetry about configuration strength,incident history, and compliance status.

- AI Decision Support Layer o Predictive analytics for emerging threats and evolving risk based on trends in vulnerabilities, threat intelligence, and control performance.

o AI-generated mitigation recommendations that propose prioritized actions—such as patch deployment, access control tightening, network segmentation, and additional monitoring—with quantified risk reduction.

o Natural language query interface for non-technical stakeholders, enabling questions like 'What is our highest financial cyber risk today?' or 'Which vulnerabilities contribute most to our expected losses?'.

o Scenario simulation tools for exploring 'what-if' analyses, such as 'What happens if MFA is implemented across all privileged accounts?' or 'How will delaying remediation by 30 days affect our financial exposure?'.

- Investment Optimization Module o Optimization models that recommend sets of controls and remediation actions delivering maximum risk reduction for a specified budget (for example, ?1 crore).

o Computation of ROSI and cost-benefit metrics for different security initiatives to support strategic planning and board-level approvals.

o Visualization of 'Investment vs. Risk Reduction' curves to highlight diminishing returns and optimal spend zones.

- Executive and Technical Dashboards o Unified views for CISOs and executives, including Enterprise Risk Score, total Financial Exposure, Risk Trend Analysis, Top Risk Contributors, and Risk Reduction Opportunities.

o Drill-down capability for technical teams to see control-level and asset-level findings, remediation backlogs, and mapping to frameworks and policies.

- Compliance and Framework Mapping o Built-in mapping against frameworks such as ISO/IEC 27001, NIST Cybersecurity Framework, CIS Controls, RBI Cyber Security Framework, and SEBI Cybersecurity and Cyber Resilience Framework.

o Support for generating evidence-based reports and dashboards for audits, regulatory filings, and internal governance committees.

- Expected Outcomes

- Continuous, near real-time visibility into enterprise cyber risk, expressed in monetary terms understandable to business stakeholders.

- Improved prioritization of cybersecurity initiatives based on quantified impact rather than subjective risk ratings.

- Enhanced communication of cyber risk to executive management, boards, and regulators through intuitive, data-driven dashboards and narratives.

- More rational and optimized cybersecurity investment decisions, maximizing risk reduction per unit of spend.

- Reduction in both the likelihood and financial impact of cyber incidents through targeted remediation and investment strategies.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26106"></a>[106] SIH26106: AI-Powered Email Threat Detection, GeoLocation and Forensic Intelligence Platform

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26106` (SIH26106) |
| **Problem Statement Title** | AI-Powered Email Threat Detection, GeoLocation and Forensic Intelligence Platform |
| **Organization** | All India Council for Technical Education (AICTE) |
| **Department** | Cyber Security Cell |
| **Category** | Software |
| **Theme** | Blockchain & Cybersecurity |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Email continues to be one of the most widely used communication channels in government, education, banking,and enterprise ecosystems. However, it also remains one of the most exploited attack vectors for phishing,impersonation, business email compromise, financial fraud, credential theft, and malware delivery. Threat actors increasingly use spoofed domains, deceptive sender identities, social engineering techniques, and compromised infrastructure to send highly convincing fraudulent emails that appear legitimate to end users.Traditional email security controls such as spam filters, static blacklists, and rule-based signature mechanisms are often insufficient to detect sophisticated fraudulent emails. Attackers now use AI-generated language,domain lookalikes, display-name spoofing, hidden redirection links, and relay chains to evade standard detection systems. In many cases, even when a suspicious email is identified, organizations lack the technical capability to effectively trace the source path, identify probable sender infrastructure, correlate geolocation clues, and support investigation into the origin of the email.This gap creates major challenges for cybersecurity teams, law enforcement support, fraud response units, and institutional administrators who need not only to detect malicious emails but also to investigate their source and reveal indicators that may help identify the actor or infrastructure behind the attack.

- Problem Statement Current email security ecosystems primarily focus on filtering or blocking suspicious content but provide limited intelligence for deep forensic tracing of fraudulent email origins. Existing tools often do not adequately correlate email headers, SMTP relay paths, SPF/DKIM/DMARC validation results, IP reputation, geolocation indicators, domain registration intelligence, and behavioral patterns to build a complete picture of the sender's identity or operating location.There is a need for an AI-powered platform capable of detecting phishing, spoofed, impersonated, and fraudulent emails in real time or near real time, analyzing the complete technical structure of an email, tracing its transmission path across mail servers, estimating its origin with location, and generating forensic intelligence and investigative insights that assist in identifying malicious infrastructure, compromised systems, or threat actors behind the attack.The solution should support forensic analysis, fraud prevention, institutional email security, and investigation workflows while maintaining legal, privacy, and evidentiary standards.

- Proposed Solution Develop an AI-Powered Email Threat Detection, GeoLocation and Forensic Intelligence Platform that combines Natural Language Processing (NLP), Machine Learning (ML), email header forensics, IP intelligence, domain analysis, and graph-based correlation to identify suspicious emails,detect advanced email threats, and investigate their probable origin.

The system should ingest raw email content, metadata, and headers; validate sender authentication mechanisms;

extract indicators of compromise; reconstruct relay paths; analyze originating IP addresses and associated geolocation data; and generate a confidence-based assessment of fraud risk and probable sender origin. The platform should provide actionable alerts, visual trace maps, and forensic reports for security analysts,administrators, and investigators.

- Key Components

- Fraudulent Email Detection Engine o NLP-based analysis of email subject lines, body text, urgency cues, impersonation language, and social engineering patterns.

o Detection of phishing indicators such as spoofed sender addresses, deceptive domains, suspicious attachments, malicious links, and obfuscated URLs.

o AI/ML models to classify emails as legitimate, suspicious, impersonated, phishing, or fraud-related.

o Identification of business email compromise patterns such as payment diversion, fake invoice requests, credential harvesting attempts, and executive impersonation.

- Email Header and Protocol Analysis Module o Deep analysis of email headers including Return-Path, Received headers, Message-ID, Reply-To,DKIM signatures, SPF alignment, and DMARC status.

o Detection of anomalies in mail routing, forged sender fields, relay manipulation, and spoofed transmission records.

o Validation of whether the email was sent through authorized infrastructure or suspicious relay paths.

- Origin Traceability and Location Analysis o Extraction of originating IP addresses from header chains and identification of the earliest reliable sending node.

o IP geolocation mapping to estimate the likely country, region, city, ISP, hosting provider, or proxy service associated with the email source.

o Correlation with VPN, TOR, open relay, botnet, or cloud-hosted infrastructure indicators where applicable.

o Domain intelligence analysis using WHOIS data, DNS records, MX records, hosting fingerprints,and registrar details to identify suspicious sender infrastructure.

- Identity Correlation and Attribution Support o Correlation of email indicators with known threat intelligence, blacklists, previous incidents,domain clusters, and repeated fraud campaigns.

o Graph-based relationship analysis between sender domains, IP addresses, aliases, reply chains, and linked infrastructure.

o Confidence-based investigative assessment to assist in revealing probable sender identity, associated infrastructure, or campaign-level attribution patterns.

o Support for flagging whether the email likely originated from a compromised account, spoofed domain, anonymized infrastructure, or direct malicious actor environment.

- Alerting, Dashboard, and Forensic Reporting o Real-time alerts for high-risk emails before user interaction or administrative approval.

o Analyst dashboard showing fraud score, spoofing indicators, sender trace path, geolocation map,and attribution confidence.

o Generation of structured forensic reports for institutional action, legal review, cyber incident response, and support to law enforcement agencies.

o Searchable case management view for grouping related fraudulent emails into campaigns.

- Privacy, Legal, and Compliance Safeguards o Controlled handling of personal data and metadata in accordance with organizational privacy policies.

o Logging, evidence preservation, and chain-of-custody support for investigation purposes.

oConfigurable retention and masking mechanisms for sensitive communication data.

- Expected Outcomes

- Early and accurate detection of fraudulent, spoofed, and phishing-based email attacks.

- Improved ability to trace suspicious email origin paths and identify probable source infrastructure.

- Enhanced fraud investigation capability through geolocation analysis, domain intelligence, and sender attribution support.

- Reduced financial loss, reputational damage, and unauthorized disclosure of confidential information caused by email-based fraud.

- Better institutional readiness for cyber incident response, forensic investigation, and enforcement coordination.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26107"></a>[107] SIH26107: Al-powered Intelligent Assistant for Indian Standards and BIS Services for Industries and Consumers

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26107` (SIH26107) |
| **Problem Statement Title** | Al-powered Intelligent Assistant for Indian Standards and BIS Services for Industries and Consumers |
| **Organization** | Ministry of Consumer Affairs, Food & Public Distribution |
| **Department** | Department of Consumer Affairs (DoCA) |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

The Bureau of Indian Standards publishes thousands of Indian Standards and provides various services such as product certification, hallmarking, laboratory recognition, Standards Clubs, training, consumer affairs, and conformity assessment.

- At present, users often struggle to identify:

- Applicable Indian Standards for their products,

- Certification requirements,

- Relevant BIS schemes,

- Licensing procedures,

- Testing requirements,

- Related standards, and

- Answers to technical queries.

Searching through multiple documents, portals, and PDFs is time-consuming, particularly MSMEs, startups, students, and consumers.

**Description:**

Develop an Al-powered conversational assistant that enables users to obtain accurate, context-aware, and source-backed information related to Indian Standards and BIS services through natural language interactions.

The assistant should understand user queries in plain language, retrieve relevant information from authorized BIS knowledge sources, and provide responses with references to the documents or clauses which ever are applicable.

**Expected Solution:**

The software solution consists of a Intelligent Assistant or Agent which can

- Answer questions related to Indian Standards.

- Recommend applicable standards based on product descriptions.

- Provide guidance on BIS certification schemes.

- Explain certification processes.

- Answer consumer-related queries.

- Guide users regarding hallmarking.

- Suggest relevant testing laboratories.

- Support multilingual interaction.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26108"></a>[108] SIH26108: AI-Powered Recommendation Engine for Identifying Applicable Indian Standards for Procurement Specifications

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26108` (SIH26108) |
| **Problem Statement Title** | AI-Powered Recommendation Engine for Identifying Applicable Indian Standards for Procurement Specifications |
| **Organization** | Ministry of Consumer Affairs, Food & Public Distribution |
| **Department** | Department of Consumer Affairs (DoCA) |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Government departments, Public Sector Enterprises (PSES),procurement agencies, and private organizations procure a wide range of products and services through e-procurement portals. Procurement officials are often required to prepare technical specifications that reference the appropriate Indian Standards (IS).However, identifying the correct standard(s) is challenging due to the large number of published standards, overlapping scopes, frequent revisions, and the need to consider associated or normative reference standards. Consequently, tender specifications may omit relevant standards, reference outdated versions, or include incomplete technical requirements, leading to ambiguity, reduced product quality, and procurement disputes.

An intelligent system is required that can automatically analyze a product description or technical specification and recommend the most relevant Indian Standard(s), along with allied, cross-referenced, or normative standards that should also be considered.

**Description:**

Develop an Al-powered recommendation engine that integrates with procurement portals and assists procurement officials in identifying the most relevant Indian Standards and related standards while preparing tender specifications.

- Expected Features

- Accept product descriptions, technical specifications, or tender documents as input.

- Recommend the most relevant Indian Standard(s) based on semantic understanding rather than keyword matching.

- Identify allied standards, including normative references, test methods, terminology standards, safety standards, installation standards, and related product standards.

- Highlight the latest published version and amendments of the recommended standards.

- Suggest mandatory certification requirements, where applicable (e.g., BIS Product Certification, CRS, Hallmarking).

- Support multilingual input and natural language queries.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26109"></a>[109] SIH26109: Al-Based Predictive Modelling for Early Forecasting of Bovine Mastitis in lndian Dairy Farms

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26109` (SIH26109) |
| **Problem Statement Title** | Al-Based Predictive Modelling for Early Forecasting of Bovine Mastitis in lndian Dairy Farms |
| **Organization** | Ministry of Fisheries, Animal Husbandry & Dairying |
| **Department** | Department of Animal Husbandry & Dairying |
| **Category** | Hardware |
| **Theme** | Agriculture, FoodTech & Rural Development |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Bovine mastitis is one of the most prevalent and economically significant diseases affecting dairy cattle and buffaloes in lndia. The disease adversely impacts milk production, milk quality,animal health, and farm profitability, while also increasing treatment costs and antimicrobial usage. Despite its substantial economic and public health implications, mastitis is often detected only after clinical signs become apparent, limiting opportunities for timely intervention and prevention.The increasing adoption of digital dairy technologies, including automated milking systems,livestock monitoring devices, milk quality sensors, farm management softlvare, and environmental monitoring Systems, presents an opportunity to leverage Artificial lntelligence(Al), Machine Learning (ML), and Internet of Things (loT) technologies for early disease prediction and risk-based herd management.

- Problem Statement Develop an integrated Al-enabled predictive forecasting system capable of identifying and predicting the risk of bovine mastitis at both individual animal and herd levels before the onset of clinical disease.The proposed solution should utilize real-time and historical farm data from multiple sources to generate early warning alerts, risk scores, and actionable recommendations for dairy farmers, veterinarians, dairy cooperatives, and animal health authorities. The system should support continuous monitoring, disease forecasting, and evidence-based decision-making to reduce disease incidence and associated economic losses.

**Expected Solution:**

The solution should be capable of:

1. Predicting mastitis risk at least 7-14 days before the appearance of clinical signs.

2. Generating animal-wise and herd-level risk assessments.

3. lntegrating data from sensors, farm management systems, laboratory records, and manual inputs.

4. Providing real-time alerts and notifications to farmers and veterinarians.

5. Continuously improving prediction accuracy through Al/ML-based learning models.

6. Supporting data-driven decision-making through user-friendly dashboards and visualization tools.

7. Recommending preventive and corrective interventions based on identified risk factors.

8. Supporting multilingual and mobile-enabled deployment for field-level adoption.

- Data Parameters for Analysis The system should be capable of analysing and conelating multiple risk factors associated with mastitis occurrence, including:

- Animal health and treatment records and herd strength

- For individual level breed, age lactation number, disease history and vaccination status

- Milk yield and milk quality parameters

- Somatic Cell Count (SCC) and related indicators

- Body temperature, aclivity levels, and rumination behaviour

- Environmental, hygiene of the farm and climatic conditions

- Feeding and nutritional practices

- Housing conditions and farm management practices

- Milking procedures and operational schedules

- Previous disease history and co-morbidities

- Worker hygiene and health-related risk factors Based on the analysis, the system may classify animals into risk categories such as:

- No Risk

- Low Risk

- Moderate Risk

- High Risk

- Solution Components

- Hardware Component- The hardware component may include:

- loT-enabled sensors for monitoring milk conductivity, milk temperature, pH, milk yield,and other relevant indicators.

- Wearable or collar-based devices for monitoring body temperature, udder surface temperature, activity, rumination, feeding behaviour, and physiological parameters.

- Wireless communication through Bluetooth, W-Fi, GSM, NB-loT, LoRa, or equivalent technologies.

- Battery-operated or solar-powered deployment suitable for field conditions.

- GPS-enabled geo-tagging of animal and farm data.

- Rugged, low-cost, and farmer-friendly designs suitable for lndian dairy production systems.

- Software Component The software platform should include:

- Al and machine learning models for mastitis risk prediction and forecasting.

- Mobile applications for farmers, veterinarians, and field personnel.

- Cloud-based data storage, integration, and analytics

- Algorithms to predict subclinical mastitis with SCC.

- Real-time herd health monitoring dashboards.

- Early warning and notification systems through mobile alerts, SMS, or other communication channels.

- Decision-support tools providing recommendations on animal health management, milking hygiene, nutrition, biosecurity, and veterinary interventions.

- GIS-based visualization of disease trends, hotspots, and risk clusters.

- Expected Deliverables

- Functional prototype of the integrated mastitis forecasting system.

- Al-based predictive analytics engine with demonstrated forecasting capability.

- Mobile application and user interface for field deployment.

- Cloud-based dashboard and data management platform.

- Early warning and notification module.

- Hardware prototype incorporating sensor-based data acquisition.

- Demonstration and validation of predictive performance under field conditions.

- Expected Outcomes and lmpact The successful solution is expected to:

- Enable early detection and prevention of bovine mastitis both at individual level and herd level.

- Reduce milk production losses and treatment costs.

- lmprove milk quality, safety, and marketability.

- Reduce indiscriminate antimicrobial usage and support antimicrobial resistance (AMR) mitigation efforts.

- lmprove animal welfare, productivity, and longevity.

- Promote precision livestock farming and digital dairy management.

- Enhance the profitability and resilience of dairy farmers.

- Contribute to the development of a data-driven livestock health surveillance ecosystem in lndia.

- lnnovation Challenge The solution should be affordable, scalable, interoperable, and easy to deploy across diverse dairy production systems, including smallholder farms, dairy cooperatives, organized farms,and commercial dairy enterprises. Particular emphasis should be placed on low-cost implementation, ease of use, multilingual accessibility, data security, and predictive accuracy under lndian field conditions.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26110"></a>[110] SIH26110: Development of a Low-Cost Light-weight Milk Chilling Can for Small-Scale Dairy Farmers

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26110` (SIH26110) |
| **Problem Statement Title** | Development of a Low-Cost Light-weight Milk Chilling Can for Small-Scale Dairy Farmers |
| **Organization** | Ministry of Fisheries, Animal Husbandry & Dairying |
| **Department** | Department of Animal Husbandry & Dairying |
| **Category** | Hardware |
| **Theme** | Agriculture, FoodTech & Rural Development |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Milk is a highly perishable agricultural product that begins to deteriorate rapidly after milking due to bacterial growth and enzymatic activity. ln many rural and remote dairy-producing regions, particularly Hilly and North Eastern Regions, farmers lack access to bulk milk cooling facilities and reliable electricity. As a result, milk often remains at ambient temperatures for several hours before reaching collection centers, leading to quality degradation, reduced shelf life and economic losses. Available solutions are expensive, relatively heavy and low volume storage cans, making them uneconomical for use or during transportation.

**Description:**

The proposed problem aims to develop a low-cost, lightweight milk chilling can capable of maintaining milk at safe storage temperatures during collection and transportation. The can should be manufactured using food-grade lightweight materials such as High-Density Polyethylene (HDPE), aluminum alloys or composite materials while ensuring structural strength and hygiene standards.The design should incorporate an insulated double-wall structure with materials such as polyurethane foam (PUF) or other cost-effective insulating materials to minimize heat transfer.

The chilling mechanism may utilize reusable ice packs, phase change materials (PCM), or passive cooling technologies that do not require continuous electrical power. The system should be capable of maintaining milk temperatures between 4°C and 8°C for several hours under typical rural environmental conditions.The solution should also consider ease of handling, cleaning, transportation and durability.Optional features such as a temperature monitoring indicator, leak-proof lid and ergonomic handles may be included to improve usability. The product should be affordable enough for adoption by small and marginal dairy farmers and suitable for village-level milk collection systems/centres.

**Expected Solution:**

A lightweight, insulated milk chilling can with a capacity of 30-40 litres that can maintain milk at safe temperatures for at least 6-12 hours without external power supply. The developed solution should reduce milk spoilage, improve milk quality during transportation, lower handling effort due lo reduced weight and cost significantly less than conventional insulated stainless-steel chilling containers. The final prototype should be durable, food-safe, easy to manufacture and suitable for widespread deployment in rural dairy supply chains.

#### Dataset & Reference Links

Dairy temperature monitoring and milk quality datasets collected from local dairy cooperatives or experimental field trials.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26111"></a>[111] SIH26111: Smart Al-Enabled Rapid Feed and Silage Quality Testing System for Dairy Farmers

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26111` (SIH26111) |
| **Problem Statement Title** | Smart Al-Enabled Rapid Feed and Silage Quality Testing System for Dairy Farmers |
| **Organization** | Ministry of Fisheries, Animal Husbandry & Dairying |
| **Department** | Department of Animal Husbandry & Dairying |
| **Category** | Software |
| **Theme** | Agriculture, FoodTech & Rural Development |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Animal nutrition directly affects milk production, animal health, reproductive performance, and dairy profitability. Dairy farmers often face challenges due to poor-quality cattle feed,adulterated feed ingredients, fungal contamination, toxin presence, and low-quality silage.Conventional feed testing laboratories are expensive and inaccessible for many rural farmers.There is a need for rapid, portable, affordable, and digitally enabled feed quality assessment systems.Emerging technologies such as Al, loT, spectroscopy, computer vision, and biosensors can help create real-time feed testing and advisory systems for dairy farmers.

**Description:**

Participants are required to develop a rapid digital testing solution capable of:

- Assessing nutritional quality of cattle feed and silage;

- Detecting adulteration and contamination;

- Providing instant farmer advisories and feed recommendations;

- Monitoring feed storage and silage conditions.

**The solution may include:**

- Portable testing devices;

- Smartphone-enabled feed analysis;

- Al-powered nutritional prediction;

- Cloud dashboards;

- QR-based authenticity systems.

**The system may detect:**

- Crude protein

- Moisture

- Fiber

- Energy value

- Mineral deficiencies

- Urea adulteration

- Sand/silica contamination

- Aflatoxins and mycotoxins

- Fungal contamination Silage monitoring may include:

- pH

- Fermentation quality

- Moisture

- Spoilage indicators

- Mould growth

**Expected Solution:**

The expected solution should:

- Provide testing results within minutes;

- Be low-cost and portable;

- Support multilingual farmer interfaces;

- Work offline in rural areas;

- Generate nutritional and storage advisories;

- Enable cloud-based monitoring and traceability.

- Expected technologies

- AI/ML

- loT sensors

- NIR spectroscopy

- Mobile applications

- Computer vision

- Cloud analytics

- Predictive advisory systems

- Insert Table Here*

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26112"></a>[112] SIH26112: Design and Develop a Modular Autonomous Mobile Robot (AMR) Platform for Smart Warehouse Automation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26112` (SIH26112) |
| **Problem Statement Title** | Design and Develop a Modular Autonomous Mobile Robot (AMR) Platform for Smart Warehouse Automation |
| **Organization** | Autodesk |
| **Department** | Autodesk Education Experience |
| **Category** | Hardware |
| **Theme** | Robotics and Drones |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Description:**

Research and develop a concept design of a warehouse automation robot platform and a modular attachment for it, using Autodesk Fusion. Re-imagine their design and optimize for additive manufacturing.

**The idea submission consists of two mandatory concept development challenges:**

Part A – Universal Mobile Robot Platform (AGV/AMR Base)

Develop a concept design of a universal Autonomous Mobile Robot (AMR) / Automated Guided Vehicle (AGV) chassis that serves as a common mobile platform for warehouse automation. The platform should support multiple interchangeable attachments while considering structural integrity, payload capacity, weight reduction, modularity, manufacturability, and ease of maintenance.

Part B – Modular Functional Attachments Develop a concept design for any one modular attachment that integrates with the universal platform to perform specific warehouse automation tasks. Example attachments include bin handling, pallet handling, conveyor transfer, robotic picking, inventory scanning, inspection, or any other innovative warehouse automation module.

Students should use Fusion features such as Generative Design, Topology Optimization, Additive Build, and Simulation. The redesigned components should demonstrate innovation, enhanced functionality, improved efficiency, and optimized material usage while being suitable for additive manufacturing.

- Participation Guidelines For Idea Submission

- Each student team should submit Fusion public link of the Conceptual Design as described in Part-A and Part-B of the above problem statement and a PowerPoint presentation (5-7 Slides).

- Designs should be created using ONLY Autodesk Fusion and not copied or taken from any other source.

- AI Generated content is NOT ALLOWED.

For Grand Finale*: Students must use Autodesk Fusion to design, and 3D print final design of specific components (scaled down to machine size) within the given time period and present the following to the jury members:

- PPT explaining the final project

- Final 3D prints

- Public link of the design

- Rendered images NOTE: *Grand Finale details to be revealed on competition day.

- Attach Marking Criteria Table here*

- Faculty (SIH SPOC) Form Teams choosing to submit idea for Autodesk's problem statement are required to request their faculty (SIH SPOC) to fill this 'Mandatory Form'.

- Autodesk Fusion

- Autodesk Fusion combines Additive Manufacturing (3D printing) capabilities with Generative Design features. It allows users to optimize designs for 3D printing, generate support structures, and explore numerous design options using algorithms. This integration enables the creation of complex and optimized parts using 3D printing technologies.

- Students and educators can click Here to get FREE access to Fusion.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26113"></a>[113] SIH26113: Human augmentation technologies are transforming healthcare,rehabilitation, industrial ergonomics, assistive living, sports, and personal mobility by improving human capabilities and enhancing quality of life.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26113` (SIH26113) |
| **Problem Statement Title** | Human augmentation technologies are transforming healthcare,rehabilitation, industrial ergonomics, assistive living, sports, and personal mobility by improving human capabilities and enhancing quality of life. |
| **Organization** | Autodesk |
| **Department** | Autodesk Education Experience |
| **Category** | Hardware |
| **Theme** | MedTech / BioTech / HealthTech |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Description:**

Students are required to conceptualize a Human Augmentation device or assembly of their choice using Autodesk Fusion. The design should reflect original thinking and real-world engineering intent. The proposed solution may address applications in healthcare, rehabilitation, industrial ergonomics,assistive living, sports, or personal mobility, and may include (but is not limited to):

- Exoskeleton Mechanisms

- Prosthetic Components

- Rehabilitation Devices

- Assistive Support Systems

- Ergonomic Enhancement Products

- Wearable Assistive Devices

- Adaptive Mechanical Aids From the complete assembly, participants shall identify one critical machinable mechanical component that is strictly manufacturable using either Subtractive 3-Axis CNC Milling or Subtractive 2-Axis CNC Turning.The selected component shall be clearly identified within the complete assembly, indicating its location and function in the Human Augmentation product. Participants shall also justify why the selected component is suitable for the chosen CNC manufacturing process.Using Autodesk Fusion, participants shall develop the complete digital manufacturing workflow for the selected component, including:

- CAD Modelling

- Manufacturing Setup

- Tool Selection

- Toolpath Generation

- Machining Simulation

- Toolpath Optimization

- G-code Generation The final solution should demonstrate good engineering design practices, manufacturability, machining efficiency, and effective use of Autodesk Fusion CAD/CAM capabilities.

- Expected Outcomes The proposed solution should include:

- CAD model of the identified critical mechanical component within the assembly.

- Justification for selecting the component for either Subtractive 3-Axis CNC Milling or Subtractive 2-Axis CNC Turning.

- Manufacturing setup and machining strategy.

- Toolpath generation and machining simulation.

- Optimized manufacturing process.

- Product renders (assembled and exploded views).

- Participation Guidelines For Idea Submission

- Each student team shall submit a PowerPoint Presentation (6–8 Slides) describing their proposed Human Augmentation solution.

**The presentation should include:**

- Problem statement and proposed solution.

- Concept sketches.

- CAD model of the identified critical mechanical component within the assembly.

- Assembly view highlighting the selected CNC-manufactured component.

- Justification for selecting the component for either Subtractive 3-Axis CNC Milling or Subtractive 2-Axis CNC Turning.

- CAM workflow developed in Autodesk Fusion, including:

- Manufacturing Setup

- Tool Selection

- Toolpath Generation

- Machining Simulation

- Toolpath Optimization

- Product renders (assembled and exploded views).

NOTE: Physical machining or prototype fabrication is not required during the Idea Submission stage. Teams will be evaluated based on the proposed design,CAD model of the identified critical mechanical component, component selection, and digital manufacturing workflow demonstrated in Autodesk Fusion.

- Designs should be created using ONLY Autodesk Fusion and not copied or taken from any other source.

- AI Generated content is NOT ALLOWED.

For Grand Finale*: Students must use Autodesk Fusion to design and manufacture specific components to machine size within the given time period and present the following to the jury members:

- PPT explaining the final project

- Final Manufactured components

- Public link of the design

- Rendered images NOTE: *Grand Finale details to be revealed on competition day.

- The required 3-Axis CNC Milling Machine and 2-Axis CNC Turning Machine will be provided by the organizers during the Grand Finale.

- Attach Marking Criteria Table and Reference Workflow here*

- Faculty (SIH SPOC) Form Teams choosing to submit idea for Autodesk's problem statement are required to request their faculty (SIH SPOC) to fill this 'Mandatory Form'

- Autodesk Fusion

- Autodesk Fusion is a cloud-based 3D modeling, CAD, CAM, CAE, and PCB software platform for professional product design and manufacturing.

- Students and educators can click here to get FREE access to Fusion.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26114"></a>[114] SIH26114: Smart City Site Planning using Autodesk Forma Site Design

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26114` (SIH26114) |
| **Problem Statement Title** | Smart City Site Planning using Autodesk Forma Site Design |
| **Organization** | Autodesk |
| **Department** | Autodesk Education Experience |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Description:**

- Students are tasked with designing a Smart City using Forma Site Design for effective site design for adding details to the buildings in the site.

- The Site area selected must have minimum 1 km square area

- The goal is to design and develop a site including the contextual data (available for free within Forma Site Design) and export Site BIM model suitable for further use in Revit app.

- The Site designed must include Site Limits, Landscaping, Buildings, and Transportation elements.

- The Site designed must be analyzed using the Analyze functions available within Forma Site Design for Area Metrics, Embodied Carbon, Sun hours, Daylight potential, Wind Analysis, Microclimate analysis, Noise analysis, Solar Energy.

- Minimum 2 Site Design proposals must be compared and presented using the Forma Borad available within Forma Site Design.

- Objective Urban populations continue to grow rapidly, creating the need for smarter, more sustainable, and resilient cities. Planners, architects, and engineers must leverage data-driven design tools to evaluate site performance, optimize land use, and improve the quality of life for future residents.In this project, students are tasked with designing a Smart City Development using Autodesk Forma Site Design for site planning and analysis, and Autodesk Revit for detailed building development.

- Participation Guidelines For Idea Submission:

- Each student team should submit Forma Site Design with 2 proposals that are compared for their and a Forma Site Design PowerPoint presentation (5-7 Slides).

- Models should be created using only Forma Site Design and not copied or taken from any other source.

- AI Generated content is NOT ALLOWED.

For Grand Finale: Students must use Forma Site Design to design, and create 3D Model of specific office building within the given time period and present the following to the jury members:

- PPT explaining the final Site Design proposal

- Detailed and synced drawing block of a building exported, edited in Revit app and then synced to Forma Site Design.

- Presentation of the Proposal Comparison done through Forma Board

- Rendered images and Walkthrough video (30 secs.) of the final Model.

Note: Teams coming with pre-designed files will be disqualified.

- Attach Marking Criteria Table here*

- Faculty (SIH SPOC) Form Teams choosing to submit idea for Autodesk's problem statement are required to request their faculty (SIH SPOC) to fill this 'Mandatory Form'.

- Autodesk Forma Site Design

- Autodesk Forma Site Design is a complete Site Design and Site Analysis web app built on native Forma AI HUB primarily used by architects, engineers, and construction professionals to design, model, and document the site and present proposal for approvals.

- Educators and Students can download 'Autodesk Forma Site Design'.

- Essential workflow and learning access Click Here to get FREE access to Forma Site Design.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26115"></a>[115] SIH26115: Design and Develop a Smart Mobile Medical-Waste Collection and Segregation System

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26115` (SIH26115) |
| **Problem Statement Title** | Design and Develop a Smart Mobile Medical-Waste Collection and Segregation System |
| **Organization** | Autodesk |
| **Department** | Autodesk Education Experience |
| **Category** | Software |
| **Theme** | MedTech / BioTech / HealthTech |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Description:**

Healthcare facilities generate large volumes of biomedical waste that require safe, compliant, and efficient handling. Manual collection and segregation increase the risk of contamination, operational inefficiencies, and regulatory challenges.

Design and develop an AI-powered, battery-electric autonomous mobile system that automates the collection, identification, segregation, and digital tracking of biomedical waste across hospitals. The solution should leverage AI-enabled vision systems to classify waste, intelligently segregate it into designated compartments, and provide end-to-end traceability while minimizing human exposure to hazardous materials and improving safety, operational efficiency, and regulatory compliance.

Using Autodesk Fusion, students must demonstrate a complete product development lifecycle—from concept ideation to manufacturing-ready product, delivering an innovative, scalable, and solution for next-generation healthcare waste management.

- Participation Guidelines For Idea Submission:

- Each student team will submit a PowerPoint presentation (5-7 Slides) with conceptual sketches, research, and relevant images.

- NO design files are required at this stage. The actual design must be created ONLY during the Grand Finale.

- Designs should be created using ONLY Autodesk Fusion and not copied or taken from any other source.

- AI Generated content is NOT ALLOWED.

**For Grand Finale:****Students must use Autodesk Fusion within the given time period and present:**

- PPT explaining the final project

- Public link of the fully developed Autodesk Fusion design model

- Use of Generative Design for optimization will be an added advantage.

- Simulation and Analysis will be advantageous

- Motion study and exploded assembly view

- Hi-res rendered images

- Design should be capable of developing a prototype with a focus on Cost, Manufacturability, Scalability, and Quality.

Note: Teams coming with pre-designed files will be disqualified.

- Attach Marking Criteria Table here*

- Faculty (SIH SPOC) Form Teams choosing to submit idea for Autodesk's problem statement are required to request their faculty (SIH SPOC) to fill this 'Mandatory Form'.

- Autodesk Fusion

- Autodesk Fusion is a cloud-based 3D modeling, CAD, CAM, CAE, and PCB software platform for professional product design and manufacturing.

- Students and educators can click here to get FREE access to Fusion.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26116"></a>[116] SIH26116: Urban Mixed-Use Design Challenge-Design a centrally located mixed-use building in Autodesk Revit with commercial spaces (Ground + 1st floor) and residential units (up to 8 floors). 1 Level of Basement (Car Parking + EV Charging), Total (B+G+9)(Note: Plot size and all required dimensions may be assumed by students (in mm units).

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26116` (SIH26116) |
| **Problem Statement Title** | Urban Mixed-Use Design Challenge-Design a centrally located mixed-use building in Autodesk Revit with commercial spaces (Ground + 1st floor) and residential units (up to 8 floors). 1 Level of Basement (Car Parking + EV Charging), Total (B+G+9)(Note: Plot size and all required dimensions may be assumed by students (in mm units). |
| **Organization** | Autodesk |
| **Department** | Autodesk Education Experience |
| **Category** | Software |
| **Theme** | Smart Education |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Description:**

- Facade-Driven Architectural Expression-Develop an innovative facade system that enhances architectural aesthetics, responds to climate (light, heat, ventilation), and blends with the surrounding urban context.

- Breathable & Nature-Integrated Design-Incorporate a central landscape courtyard and green interfaces (terraces, balconies) to create an airy, breathable structure that integrates nature and improves occupant well-being.

- Residential & Commercial Design Efficiency-Ensure functional planning for commercial activation on lower floors and well- designed residential units above, with optimal daylight, ventilation, privacy, and views.

- Structural Modeling & Detailing-Create 2D structural drawings for key components such as beams, columns, and slabs, including necessary detailing.The model should include all essential building elements: beams, columns, slabs, stairs, and tile flooring.

- Good to Have (Optional) - Site Compatibility & Environmental Analysis (Using Forma Site Design)-Utilize Forma Site Design to study site orientation, sun path, wind conditions,and massing strategies, ensuring the design is environmentally responsive and contextually appropriate. (1-2 Hour)

- High-Quality Visual Presentation & Walkthrough-Deliver a pictorial, design-focused presentation including rendered views, facade studies, diagrams, and a 30-second walkthrough animation.Rendering quality and visual storytelling will be key evaluation criteria.

- Participation Guidelines For Idea Submission:

- Each student team should submit Revit 3D Model of a Basement Parking + Ground + First Floor that creates a vibrant urban destination while seamlessly integrating nature, sustainability, and user well-being and a PowerPoint presentation (5-7 Slides).

- Models should be created using ONLY Revit and not copied or taken from any other source.

- AI Generated content is NOT ALLOWED.

**For Grand Finale:**

Students must use Autodesk Revit to design and create 3D Model of specific mixed used building within the given time period and present the following to the jury members:

Design a B+G+9 mixed-use development that brings together active commercial spaces and sustainable residential living. Create a nature-integrated, climate-responsive building centered around a landscaped courtyard that enhances daylight,ventilation, and occupant well-being.

**Key Deliverables:**

- Commercial podium (Basement Parking + Ground + First Floor) with retail, cafés,and community spaces.

- Residential levels (2nd–9th Floor) featuring efficient layouts, balconies, natural ventilation, and privacy.

- Innovative climate-responsive facade with shading elements and green terraces.

- Central landscaped courtyard as the project's defining feature.

- Complete Autodesk Revit model with architectural and structural elements,including detailed drawings.

- Optional Autodesk Forma studies for sun, wind, and environmental analysis.

- High-quality presentation with renders, diagrams, facade studies, and a 30-second walkthrough animation.

- PPT explaining the final project.

- Complete Structural reinforcement drawing of any one floor along with detailing.

- Complete 3D Model.

- Rendered images and Walkthrough video (30 secs.) of the final Model.

Note: Teams coming with pre-designed files will be disqualified.

- Attach Marking Criteria Table here*

- Faculty (SIH SPOC) Form Teams choosing to submit idea for Autodesk's problem statement are required to request their faculty (SIH SPOC) to fill this 'Mandatory Form'.

- Autodesk Revit

- Autodesk Revit is a Building Information Modeling (BIM) software primarily used by architects, engineers, and construction professionals to design, model, and document buildings and infrastructure in 3D.

- Students and educators can click Here to get FREE access to Revit.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26117"></a>[117] SIH26117: Sovereign On-Premise Agentic AI Workbench using Open-Weight Multimodal LLMs for Confidential Industrial Work

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26117` (SIH26117) |
| **Problem Statement Title** | Sovereign On-Premise Agentic AI Workbench using Open-Weight Multimodal LLMs for Confidential Industrial Work |
| **Organization** | Mangalore Refinery and Petrochemicals Limited (MRPL) |
| **Department** | Mangalore Refinery and Petrochemicals Limited (MRPL) |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Refineries, PSUs, defence-linked manufacturing units and government offices generate a lot of routine but sensitive knowledge work. Approval notes, board presentations, engineering calculations, code for internal tools, review of scanned drawings and inspection reports. None of this can go through cloud AI assistants like Claude or Codex because the underlying data is confidential: Piping & Instrument Diagrams, financials, vendor negotiations, unreleased designs, internal correspondence, confidential business strategies etc. Company policy keeps this data on premises, so people either do the work manually resulting in productivity gain, or they quietly paste confidential material into public tools anyway. Open weight large reasoning models have reached a point where a genuinely useful assistant built on them is realistic. But nothing deployable exists today that industrial users can actually work with the way they use Claude or Codex.

**Description:**

The idea is a self-hosted, air gapped AI workbench running entirely on the organization's own GPU server. Nothing leaves the premises. The backend should not be locked to one model. It needs to support multiple open weight models at once and automatically pick the right one for a given task based on what that task needs, a coding request handled differently from a document summary request. New open weight models should be addable later without redesigning the system, since this space is moving fast.

The assistant also needs to actually act like an agent. Plan out multi step work, call local tools such as file read and write, code execution in a sandbox, spreadsheet work, internal document search, and iterate on a task instead of answering once and stopping. It needs to handle more than text too: scanned PDFs, handwritten notes, engineering drawings, photographs, read through on device OCR and vision models. Output should be real deliverables, approval notes, PPT/Word/Excel files, working code, calculations with steps shown, not just chat replies. And it needs to ground itself in the organization's own manuals, SOPs and past correspondence through a local knowledge base connector, again with nothing going external.

**Expected Solution:**

A working local deployment, demonstrable on a single workstation or server with a mid range GPU (use a smaller open weight model if 120B class hardware isn't available at the venue), that shows model auto selection across at least two different task types. An agentic task carried through end to end, for example reading a scanned inspection report, pulling out key findings and drafting an approval note as a Word file. A coding task run and verified in a sandbox. A multimodal task involving image or scanned document understanding. The system should also show, through logs or a visible network monitor, that no external calls are made at any point. That's the actual proof of the sovereign claim, not just a statement of it.

#### Dataset & Reference Links

Open-source models and publicly available document samples (sample scanned PDFs, sample P&IDs from open datasets) to be used for demonstration; no proprietary data required.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26118"></a>[118] SIH26118: Passive Colorimetric H2S Exposure-Dosimeter Wristband with AI-Based Quantitative Reading

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26118` (SIH26118) |
| **Problem Statement Title** | Passive Colorimetric H2S Exposure-Dosimeter Wristband with AI-Based Quantitative Reading |
| **Organization** | Mangalore Refinery and Petrochemicals Limited (MRPL) |
| **Department** | Mangalore Refinery and Petrochemicals Limited (MRPL) |
| **Category** | Hardware |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Workers in oil and gas operations face chronic low-level H2S exposure. Standard electronic gas detectors miss this risk because they only report instantaneous ppm, and they need batteries, calibration and upkeep. Passive colorimetric badges already exist, usually lead-acetate based, but they only give a rough visual read, exposed past threshold or not, judged by eye. There's no way to know the actual cumulative dose, concentration multiplied by time, and no way to confirm the badge itself hasn't already expired or degraded before it's worn. India has no low-cost, indigenous, digitally-read passive dosimeter for this. Peak-exposure alarms are not what protects long-term health. Cumulative dose is.

**Description:**

The idea is a disposable wristband with an indigenously formulated chemical strip that darkens progressively and permanently with cumulative H2S exposure, not just past one threshold. The strip sits next to a printed reference color scale, and separately, a second patch that shows the badge's own shelf life. Something a worker or safety officer can glance at before a shift to confirm the badge itself is still valid.

A phone app does the reading. Photograph the strip next to the reference scale, and the app corrects for whatever lighting the photo was taken in by calibrating against that reference. It converts the color into an estimated cumulative exposure figure and logs it against worker ID and shift, for occupational health records and DGMS or OISD style reporting. The dose figure should be presented as an estimate, since colorimetric reactions don't scale perfectly linearly at very low concentrations or over long durations. Temperature and humidity affect reaction speed too, so the strip design needs to account for that, either through a sealed reference cell or a compensation method in the app.

**Expected Solution:**

A working wristband prototype, chemical strip plus a separate expiry indicator, along with a phone app that reads and quantifies exposure from a photograph. Tested against a controlled, lab-simulated H2S exposure at known concentration and duration, with a stated and validated shelf life, 30 or 90 days for example, and a dose estimate that tracks reasonably close to the known simulated exposure.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26119"></a>[119] SIH26119: Indigenous GPU-Accelerated Optimization Solver (Sovereign Alternative to Express / CEPLEX)

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26119` (SIH26119) |
| **Problem Statement Title** | Indigenous GPU-Accelerated Optimization Solver (Sovereign Alternative to Express / CEPLEX) |
| **Organization** | Mangalore Refinery and Petrochemicals Limited (MRPL) |
| **Department** | Mangalore Refinery and Petrochemicals Limited (MRPL) |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Almost every optimization problem in India's refining, petrochemical, power, logistics, manufacturing and planning sectors ultimately depends on a handful of foreign mathematical optimization solvers such as IBM ILOG CPLEX, Gurobi and FICO Xpress. These engines sit behind refinery scheduling, production planning, supply chain optimization, blending, energy management and many AI-driven decision-support systems. While they are extremely capable, they come with high recurring license costs, restrictive licensing models and limited visibility into the underlying optimization algorithms. Indian developers can formulate optimization problems, but they cannot inspect, modify or tailor the solver internals to suit strategic national requirements. Open-source alternatives such as COIN-OR CBC, HiGHS, GLPK and SCIP exist and have made significant progress, but they still lag behind commercial solvers for several classes of large-scale mixed-integer optimization problems and have not been developed, validated or optimized specifically for Indian industrial use cases. The real challenge is not building the modeling interface; it is developing a numerically robust optimization engine that consistently finds high-quality solutions for large, sparse and highly constrained industrial problems within practical computation times.

**Description:**

The objective is to develop a sovereign mathematical optimization solver core rather than a complete modeling environment. The solver should support Linear Programming (LP), Mixed-Integer Linear Programming (MILP) and Quadratic Programming (QP) as the initial focus, with a modular architecture that can later be extended to Mixed-Integer Quadratic Programming (MIQP), Nonlinear Programming (NLP) and Mixed-Integer Nonlinear Programming (MINLP). Core algorithms may include revised simplex and interior-point methods for continuous optimization, together with branch-and-bound, branch-and-cut, cutting planes, presolve, heuristics and advanced node selection strategies for mixed-integer problems. The solver should exploit sparse matrix techniques, efficient numerical linear algebra and multi-core parallelization, with GPU acceleration considered where it provides measurable benefits. The emphasis is on numerical stability, scalability and reliable convergence across large industrial optimization problems rather than on graphical interfaces or modelling tools. It shall not be built upon any existing open source solver library but shall be built from scratch from mathematical foundation.

The scope is to solve optimization problems arising from refinery scheduling, crude blending, process optimization, production planning, logistics, power system dispatch, transportation and supply chain management. The benchmark is that the solver should consistently deliver optimal or near-optimal solutions for industrial-scale problems involving thousands to millions of variables and constraints, including highly degenerate models, ill-conditioned matrices and difficult mixed-integer formulations where weaker implementations exhibit excessive computation times or fail to converge.

**Expected Solution:**

A robust optimization engine with a basic application programming interface (API) or command-line interface is sufficient; a polished graphical user interface is not required. The solver should successfully solve standard benchmark problems from recognised optimization libraries such as MIPLIB, Netlib or Mittelmann benchmark sets, with solution quality and computational performance compared against at least one established commercial or open-source solver. A clear demonstration of numerical robustness should be provided by solving challenging large-scale optimization problems involving degeneracy, weak LP relaxations or ill-conditioned constraint matrices, where simpler implementations struggle to achieve reliable convergence or acceptable solution times. The resulting solver should provide a transparent, extensible and sovereign foundation for future Indian optimization software across industrial, scientific and strategic applications.

#### Dataset & Reference Links

Teams to use publicly available mathematical optimization benchmark datasets such as MIPLIB, Netlib LP, Mittelmann benchmark instances, QPLIB (for quadratic programming where applicable), along with representative refinery scheduling, crude blending, production planning and supply chain optimization case studies from open literature. Where industrial da

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26120"></a>[120] SIH26120: Digital Twin for Well-to-Surface Optimization of Cyclic Steam Stimulation (CSS) and Sucker Rod Pump (SRP) Operations for Heavy Oil Wells of Baghewala Field.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26120` (SIH26120) |
| **Problem Statement Title** | Digital Twin for Well-to-Surface Optimization of Cyclic Steam Stimulation (CSS) and Sucker Rod Pump (SRP) Operations for Heavy Oil Wells of Baghewala Field. |
| **Organization** | Oil India Limited |
| **Department** | Oil India Limited |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Baghewala Field in Rajasthan produces heavy crude oil (17–19° API) from the Jodhpur Sandstone reservoir. The reservoir is characterized by High crude viscosity, High asphaltene content, Low reservoir pressure, Low reservoir temperature (46–48°C) and Poor oil mobility under primary recovery. Consequently, artificial lift and thermal enhanced oil recovery are critical for sustained production. At present, CSS cycle design and SRP operation are optimized separately using historical experience. As reservoir temperature declines after steam injection, crude viscosity increases, leading to reduced pump efficiency, higher energy consumption, rod floating issues, rod failures and lower oil recovery. There is a need for an integrated, data-driven system that continuously optimizes both CSS and artificial lift operations.

- Problem Description Current operations face the following challenges:

- CSS parameters (steam volume, injection pressure, soak time and production cut-off)

are largely based on historical practices.

- SRP operating parameters (stroke length, SPM and VFD settings) are adjusted manually and reactively.

- Heavy crude causes rod floating, impact loading, frequent pump unsetting, rod failures and increased maintenance.

- Reservoir behaviour, wellbore conditions and SRP performance are not optimized together.

- Lack of predictive analytics results in higher Steam-Oil Ratio (SOR), increased energy consumption and reduced production efficiency.

- Expected Outcome / Solution Develop an AI-enabled Well-to-Surface Digital Twin that integrates reservoir, wellbore and surface production systems to provide real-time monitoring, prediction and optimization.

**The solution should:**

- Optimize CSS cycle parameters.

- Predict reservoir heating, cooling and production performance.

- Continuously optimize SRP operation by adjusting stroke speed and SPM based on well conditions.

- Detect rod floating and minimize impact loading.

- Improve pump efficiency and equipment reliability.

- Optimize steam and energy consumption while reducing operating cost.

- Expected Benefits

- Increased oil production and recovery.

- Reduced Steam-Oil Ratio (SOR).

- Lower energy consumption per barrel.

- Reduced rod failures and pump unsetting.

- Improved equipment life and operational reliability.

- Data-driven and predictive decision making.

- Relevant Data Availability The field has sufficient historical and operational data, including:

- Production history

- CSS cycle records

- Steam injection parameters

- VFD and SRP operating data

- Rod failure and pump unsetting history

- Well completion and reservoir data

- Fluid properties and pressure data

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26121"></a>[121] SIH26121: eRTMAC-NWIS (Nearby Wells Intelligence System): An AI-Powered Offset Well Knowledge and Decision Support Platform for Drilling Operations

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26121` (SIH26121) |
| **Problem Statement Title** | eRTMAC-NWIS (Nearby Wells Intelligence System): An AI-Powered Offset Well Knowledge and Decision Support Platform for Drilling Operations |
| **Organization** | Oil India Limited |
| **Department** | Oil India Limited |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Oil India Limited has a digital real-time monitoring system (eRTMAC) that provides real-time drilling data, mud logging information, and wellsite analytics across operational areas. However, drilling decisions, particularly in geologically complex formations, require not only real-time data from the active well but also insights from nearby and historical wells drilled in the same reservoir or formation. Historical drilling knowledge currently resides across numerous well completion reports, drilling reports, PDF documents, and individual experience, making retrieval time-consuming and dependent on individual experience &

memory. This often results in delays in decision-making and missed opportunities to proactively mitigate drilling risks.

- Problem Description Currently, drilling teams do not have a unified platform that can:

i. Display nearby wells on a geospatial map relative to the active well.

ii. Provide instant access to historical drilling experiences and operational events from offset wells.

iii. Correlate drilling parameters, reservoir characteristics, mud losses, kicks, stuck pipe incidents, casing programs, cementing practices, and formation-specific risks across wells.

iv. Generate proactive alerts when current drilling operations approach depths or formations where similar challenges were encountered in nearby wells.

As a result, engineers often spend significant time manually searching through historical reports and databases, limiting the ability to make fast, informed, and data-driven operational decisions.

- Expected Outcome / Solution Develop an AI/ML-enabled Nearby Wells Intelligence System (NWIS) that acts as a standalone decision-support platform alongside eRTMAC that has institutional memory.

**The solution should:**

i. Use AI, NLP, OCR, and data analytics to automatically extract and structure information from historical drilling reports and well documents.

ii. Provide an interactive map-based visualization of nearby wells within a user-defined radius.

iii. Create a searchable knowledge repository of drilling events, lessons learned, operational challenges, and mitigation measures.

iv. Correlate geological, drilling, and reservoir data across wells based on depth and formation.

v. Develop predictive analytics models that can identify potential drilling risks such as mud losses, stuck pipe, overpressure zones, torque spikes, or cementing issues based on historical offset-well behaviour.

vi. Generate real-time alerts and recommendations to assist drilling engineers in proactive decision-making.

vii. Present information through a user-friendly dashboard for field and office-based personnel.

- Relevant Data Availability (if any)

**Potential data sources available within OIL may include:**

i. Well Completion Reports (WCRs)

ii. Daily Drilling Reports (DDRs)

iii. Drilling and mud logging databases iv. Historical well parameters and drilling records v. Reservoir and geological data vi. eRTMAC data streams vii. Well trajectory and survey data viii. Casing, cementing, and mud program records ix. Historical operational event records including mud losses, kicks, stuck pipe incidents, fishing operations, and NPT events.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26122"></a>[122] SIH26122: Intelligent Data Capture & Schedule-Linking Layer for Infrastructure Project Management: Real-Time Actual Progress Tracking (Planning-to-Execution Bridge)

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26122` (SIH26122) |
| **Problem Statement Title** | Intelligent Data Capture & Schedule-Linking Layer for Infrastructure Project Management: Real-Time Actual Progress Tracking (Planning-to-Execution Bridge) |
| **Organization** | Oil India Limited |
| **Department** | Oil India Limited |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Infrastructure project schedules cascade from macro milestones (L1) down to micro, executable activities (L5/L6),spanning multiple engineering disciplines - civil, piping, static/rotating equipment, electrical, instrumentation, HSE- each executing and reporting in parallel. While the baseline plan is well-structured (Primavera/MS Project), actual execution data flows back through daily progress reports, site diaries, discipline-wise spreadsheets, and verbal supervisor updates, each in its own format and cadence, largely disconnected from the L5/L6 activity IDs in the plan.

- Problem Description There is no reliable, low-friction mechanism to capture actual start/end times of L5/L6 activities across disciplines and auto-link them back to the plan. Input quality varies with manpower skill, reporting discipline, and format.Field execution is often more granular than the planned WBS, and different disciplines describe the same physical progress differently (e.g., 'spool erected' vs. the plan's 'Erect Line 24?-XX').Consequently:

? Actual progress data is fragmented, delayed, and inconsistently structured across disciplines and contractors.

? Manual reconciliation with the baseline schedule is slow, error-prone, and often lags the schedule update cycle by days or weeks.

? Downstream performance analytics, delay/ risk analysis, and forecasting inherit this poor-quality, late data- undermining the AI performance-monitoring stack that depends on it.

? Once a project closes, the hard-won knowledge of what actually happened - real durations, real bottlenecks,real deviations from plan - is rarely captured in a structured, queryable form, so it is lost rather than feeding future project planning.

- Expected Outcome/Solution ? Ingest heterogeneous discipline-wise inputs - free-text daily reports, spreadsheets, scanned diaries,Primavera/MS Project exports - and extract activity-level actual start/end events.

? Offer an LLM-based conversational or voice interface ('time agent') for site supervisors across disciplines to log activity start/end with minimal friction, replacing rigid manual forms while still producing structured output.

? Fuzzy-match and link extracted discipline-specific activity descriptions to the correct L5/L6 plan node,handling terminology differences and granularity mismatches, and flag unmatched/new activities for planner review rather than silently dropping them.

? Auto-update actual start/end dates in the schedule/PMIS in near real time, with a confidence score and audit trail per entry.

? Produce a clean, structured, discipline-tagged actual-progress dataset that serves two purposes: (a) live input for performance analytics, delay/risk pattern discovery, and forecasting, and (b) a foundation for institutional memory building - a growing, queryable repository of real project execution patterns (actual durations, recurring delay causes, discipline-wise productivity) that future projects can learn from, instead of that knowledge staying locked in individual supervisors' experience or scattered paper records.

A working prototype demonstrating ingestion of 2–3 varied input formats (e.g., a free-text daily report and a discipline spreadsheet), extraction, and schedule-linking logic would be ideal; full production-grade OCR/ASR is not required.

- Relevant Data Availability Anonymized/ sample daily progress report formats, sample L5/L6 schedule extracts, and illustrative discipline-wise (civil/ piping/ electrical) site-diary or spreadsheet templates can be shared under NDA with Institute/ Authorised person. Live project data will not be shared; teams should work with synthetic/sample data of similar structure.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26123"></a>[123] SIH26123: Edge-AI Based Distributed Fleet Coordination for Autonomous Mobile Robots (AMRs) in Smart Warehouses

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26123` (SIH26123) |
| **Problem Statement Title** | Edge-AI Based Distributed Fleet Coordination for Autonomous Mobile Robots (AMRs) in Smart Warehouses |
| **Organization** | Bharat Electronics Limited |
| **Department** | Bharat Electronics Limited |
| **Category** | Software |
| **Theme** | Robotics and Drones |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Modern smart warehouses rely on fleets of Autonomous Mobile Robots (AMRs) to move goods efficiently. As fleet sizes grow, relying entirely on a centralized cloud server for path planning causes high network latency, Wi-Fi dead-zone vulnerabilities, and single-point-of-failure risks.To ensure continuous operation, modern robotics is shifting toward decentralized, edge-computing solutions where robots can talk to each other directly and make split-second decisions on the fly.

**Description:**

The objective is to design a decentralized coordination and collision-avoidance framework for a multi-robot fleet (at least 3 AMRs) operating in a dynamic warehouse environment. The system must run locally on edge hardware (e.g., Raspberry Pi or Jetson Nano onboard each robot) and handle:

1. Decentralized Communication: Inter-robot messaging to share position and intent without a central server.

2. Dynamic Multi-Agent Conflict Resolution: Resolving deadlocks and avoiding collisions at narrow intersections or choke points in real-time.

3. Task Allocation & Re-routing: Automatically re-assigning pickup points or changing paths if one robot encounters a blocked aisle.

**Expected Solution:**

A multi-robot simulation featuring:

- Decentralized Network Stack: A peer-to-peer communication protocol where robots share localization data locally.

- Multi-Agent Path Planning: Implementation of algorithms for edge hardware.

- Fleet Dashboard: A lightweight monitoring UI that visualizes the entire fleet's real-time positions and battery status.

- Success Criteria: Zero inter-robot collisions and a minimum 20% reduction in total task completion time compared to traditional stop-and-wait methods when handling overlapping paths.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26124"></a>[124] SIH26124: AI-Powered Mobile Urban Intelligence Platform Using Public Transport Fleet

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26124` (SIH26124) |
| **Problem Statement Title** | AI-Powered Mobile Urban Intelligence Platform Using Public Transport Fleet |
| **Organization** | Bharat Electronics Limited |
| **Department** | Bharat Electronics Limited |
| **Category** | Software |
| **Theme** | Fitness & Sports |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Urban public transport buses traverse almost every major road in a city every day. Modern buses are increasingly equipped with multiple cameras covering the front, rear, sides, and passenger cabin. However, these cameras are primarily used for recording incidents and are not leveraged as intelligent sensing platforms. At the same time, city authorities rely on fixed CCTV cameras, manual inspections and citizen complaints to identify road defects, traffic congestion,missing infrastructure and unsafe driving behaviour. This results in delayed response,incomplete situational awareness and inefficient maintenance planning.

**Description:**

Develop an AI-powered onboard and centralized software platform that transforms public transport buses into mobile urban sensing units. The onboard software shall analyse video streams from multiple bus-mounted cameras to detect road defects such as potholes, damaged roads, missing road dividers, missing zebra crossings, damaged or missing traffic signboards,waterlogging and other road hazards. It shall estimate vehicle density through vehicle detection, classification and counting, identify traffic bottlenecks, and detect vulnerable pedestrian situations such as school children crossing roads. During incidents such as hit-and-run or rash driving, the system should detect and track the offending vehicle, extract the registration number with a confidence score, timestamp and GPS location, and securely share alerts with a central command system. The centralized platform shall aggregate information from the entire bus fleet, visualize events on a GIS map, generate congestion heat maps,identify infrastructure deficiencies, analyse origin–destination traffic patterns, estimate route delays and provide actionable insights for transport authorities.

**Expected Solution:**

The solution should provide an edge-AI onboard processing framework integrated with a centralized urban intelligence platform. It should generate reliable alerts, GIS-based dashboards, road condition maps, traffic analytics and incident reports to support proactive road maintenance, improved traffic management, enhanced public safety and evidence-based decision making while minimizing bandwidth through intelligent edge processing.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26125"></a>[125] SIH26125: Blockchain-Based Secure Platform for Identity,Access Control, and Digital Asset Management

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26125` (SIH26125) |
| **Problem Statement Title** | Blockchain-Based Secure Platform for Identity,Access Control, and Digital Asset Management |
| **Organization** | Bharat Electronics Limited |
| **Department** | Bharat Electronics Limited |
| **Category** | Software |
| **Theme** | Blockchain & Cybersecurity |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Organizations today rely heavily on centralized identity and access management systems, which create significant security and operational risks. These systems are vulnerable to cyber attacks, identity theft, unauthorized access, and single points of failure. Additionally, digital and physical asset ownership is often managed through disconnected or semi-centralized systems, making verification of authenticity, access rights, and ownership history difficult and unreliable. There is a growing need for a decentralized, tamper-proof system that can securely manage user identities, control access permissions, and ensure transparent ownership of digital assets

- Detailed Description The system aims to introduce a blockchain-based framework that integrates decentralized identity management, access control, and NFT-based digital asset ownership. Each user is assigned a decentralized identifier, which serves as a secure and verifiable digital identity independent of centralized authorities and authenticated using cryptographic proofs. Digital assets are represented as Non-Fungible Tokens (NFTs),ensuring each asset is unique, traceable, and permanently recorded on the blockchain.These NFTs are directly allocated to user identities, establishing verifiable ownership that cannot be altered or duplicated.Smart contracts govern all operations within the platform, allowing only authorized administrators to mint NFTs and assign them to user identities, ensuring controlled asset creation and secure distribution. The system also implements Role-Based Access Control (RBAC), where administrators define roles such as Admin, Manager, Auditor,and User and assign specific access rights to each identity. These permissions are enforced automatically by smart contracts during all operations. Every activity, including identity creation, NFT creation, asset allocation, access rights assignment, ownership transfers, and permission updates, is immutably recorded on the blockchain, providing a transparent and tamper-proof audit trail for verifying ownership, authenticity, and access history.

**Expected Solution:**

The expected solution is a decentralized blockchain-based platform that integrates secure digital identity management, NFT-based asset ownership, and access control into a unified and trustless system. It utilizes decentralized identifiers to provide users with self-sovereign, cryptographically verifiable identities that function independently of centralized authorities. Digital assets are issued as Non-Fungible Tokens (NFTs), ensuring uniqueness, traceability, and immutable ownership, with each NFT directly linked to a user's decentralized identity to establish a permanent and verifiable connection between assets and their owners.The system should be governed by smart contracts that enforce strict rules for NFT creation, allocation, transfer, and validation. Only authorized administrators are allowed to create NFTs and assign them to identities, ensuring secure and controlled asset governance while preventing unauthorized duplication or reassignment. Additionally, the platform should implement Role-Based Access Control (RBAC), where administrators define roles and assign access permissions that determine user privileges within the system. All identity operations, NFT transactions, and access control updates are permanently recorded on the blockchain, ensuring complete transparency, auditability,and tamper-proof verification of ownership, permissions, and transaction history.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26126"></a>[126] SIH26126: Vision Based Autonomous Navigation for Unmanned Ground Vehicle for Outdoor environment

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26126` (SIH26126) |
| **Problem Statement Title** | Vision Based Autonomous Navigation for Unmanned Ground Vehicle for Outdoor environment |
| **Organization** | Bharat Electronics Limited |
| **Department** | Bharat Electronics Limited |
| **Category** | Software |
| **Theme** | Robotics and Drones |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Outdoor Unmanned Ground Vehicles (UGVs) face unpredictable terrain, changing light, and unreliable GPS signals. To achieve true autonomy in applications like search-and-rescue,agriculture, or delivery, UGVs must rely on onboard computer vision. Visual perception provides a cost-effective, data-rich way for vehicles to understand and safely navigate complex,unstructured outdoor surroundings.

**Description:**

The objective is to build an autonomous navigation system for a UGV operating in a GPS-denied outdoor environment using camera feeds as the primary sensor. Students must solve three key challenges:

1. Path Detection: Real-time identification of safe, traversable paths vs. hazards (e.g., rocks,ditches, trees).

2. Visual Localization: Estimating the UGV's position and orientation without GPS using visual data.

3. Collision Avoidance: Dynamically routing the vehicle around sudden obstacles toward a destination.

**Expected Solution:**

A functional software module consisting of:

- Perception AI: A lightweight model for obstacle and path detection.

- Visual SLAM/Odometry: A pipeline to track vehicle movement.

- Path Planner: An algorithm to translate visual data into wheel/motor commands.

- Success Criteria: Successful, collision-free navigation from Point A to Point B across outdoor scenarios

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26127"></a>[127] SIH26127: City-Wide AI Engine for Multi-Camera ANPR Trajectory Tracking and Urban Traffic Analytics

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26127` (SIH26127) |
| **Problem Statement Title** | City-Wide AI Engine for Multi-Camera ANPR Trajectory Tracking and Urban Traffic Analytics |
| **Organization** | Bharat Electronics Limited |
| **Department** | Bharat Electronics Limited |
| **Category** | Software |
| **Theme** | Transportation & Logistics |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Modern urban centers deploy vast networks of CCTV and Automatic Number Plate Recognition(ANPR) cameras to manage traffic, enforce traffic laws, and maintain public security. However,most existing systems process these feeds in isolated silos, performing basic license plate detection without effectively linking data across space and time. This lack of integration prevents city authorities from automatically tracking high-interest vehicles across different sectors and limits their ability to extract macro-level traffic movement trends from the existing camera infrastructure.

**Description:**

The objective is to develop a robust, centralized AI software platform that processes multicamera feeds across a city-wide ANPR network to accomplish three core functionalities. First, the platform must feature a High-Accuracy ANPR and OCR Engine, which utilizes an advanced Optical Character Recognition model capable of achieving greater than 90% accuracy across diverse realworld conditions such as varying lighting, poor weather, angled shots, motion blur, and dirty or damaged license plates. Second, it requires a Single Plate Trajectory Tracking module to build a spatial-temporal tracking system capable of reconstructing the complete travel trajectory of any specific vehicle plate across the entire city network. This system will map a vehicle's movement history, timestamps, direction, and route on a GIS map using inputs from geographically distributed ANPR cameras. Third, the system must perform Macro Traffic Flow and Movement Analytics by analyzing aggregated camera data to compute and visualize general city-wide traffic dynamics. This includes measuring traffic density, identifying origin-destination patterns,detecting congestion bottlenecks, and providing real-time heatmaps of city traffic movement.

**Expected Solution:**

The expected solution is a scalable, enterprise-grade software platform equipped with four key components. It will feature a High-Precision OCR Module powered by a deep-learning model exceeding 90% recognition accuracy for license plates in multi-lane traffic streams. It will include a Trajectory Reconstruction Engine providing a query-based tracking interface that plots a vehicle's historical path chronologically across the city map with accurate timestamps and camera locations. Furthermore, it will integrate a City Traffic Analytics Dashboard to serve as a centralized, GIS-integrated web platform displaying heatmaps, average vehicle speeds, route densities, and traffic flow trends across all camera nodes. Finally, the platform will incorporate an Alert System capable of flagging blacklisted vehicles and suspicious route anomalies in real time.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26128"></a>[128] SIH26128: Efficient systems for early detection,prevention,and management of livestock diseases and animal health issues

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26128` (SIH26128) |
| **Problem Statement Title** | Efficient systems for early detection,prevention,and management of livestock diseases and animal health issues |
| **Organization** | Government Of Maharashtra |
| **Department** | Maharashtra State Innovation Society, Department of Skills, Employment, Entrepreneurship and Innovation |
| **Category** | Software |
| **Theme** | Agriculture, FoodTech & Rural Development |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

- Problem Description Livestock owners, field veterinarians,para-veterinary workers and government departments often lack a unified, realtime mechanism to identify emerging animal-health risks at the village, block and district levels. Disease symptoms may be reported late, diagnostic facilities may be distant, vaccination and treatment histories may be incomplete, and information from farms, veterinary dispensaries, laboratories, vaccination drives and surveillance programmes may remain fragmented. These gaps can delay containment, increase livestock mortality and productivity loss, raise the risk of zoonotic transmission, and affect farmers' incomes. The challenge is to create a practical system that enables early warning, rapid reporting, risk assessment, preventive action, referral and coordinated response, including in low-connectivity areas.

**Expected Solution:**

/ Outcome A scalable animal-health surveillance and decision-support solution that can: capture symptom and mortality reports from farmers and field workers; use rulebased or AI-assisted triage to flag suspected outbreaks; integrate geospatial risk mapping, weather and historical disease trends; maintain animal-level or herd-level health,vaccination and treatment records; issue multilingual advisories and alerts; support sample collection, laboratory referral and case escalation; provide dashboards for veterinary officials; and operate through mobile, web, IVR or offline-enabled channels. Expected outcomes include reduced reporting time, earlier outbreak identification, improved vaccination coverage, faster treatment and containment, lower mortality and productivity loss, and stronger evidence-based planning.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26129"></a>[129] SIH26129: System integration and interoperability among government digital platforms,resulting in fragmented service delivery

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26129` (SIH26129) |
| **Problem Statement Title** | System integration and interoperability among government digital platforms,resulting in fragmented service delivery |
| **Organization** | Government Of Maharashtra |
| **Department** | Maharashtra State Innovation Society, Department of Skills, Employment, Entrepreneurship and Innovation |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

- Problem Description Government departments operate multiple portals, mobile applications,registries, workflow systems and databases that have often been developed independently. Differences in data formats, identifiers, authentication methods, APIs, process definitions and ownership structures can prevent seamless information exchange.Citizens and businesses may be required to submit the same information repeatedly, track applications across different portals, or visit multiple offices.Officials may lack a consolidated view of beneficiaries, applications, approvals,grievances and service outcomes. The challenge is to enable secure,standards-based interoperability without requiring complete replacement of existing systems.

**Expected Solution:**

/ Outcome An interoperability framework,middleware layer or federated service delivery architecture that supports API based exchange, common data standards, master-data management, consent-based data sharing, single sign on or federated identity, event-driven notifications, unified application tracking and configurable workflow orchestration.The solution should provide reusable connectors for legacy and modern systems, audit logs, role-based access, data-quality checks, exception handling and monitoring dashboards. Expected outcomes include fewer duplicate submissions, reduced processing time,consistent records, improved citizen experience, better cross-department coordination, and measurable improvement in service-level compliance.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26130"></a>[130] SIH26130: Efficiency in streamlining industrial approvals,compliance processes,and access to government support services

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26130` (SIH26130) |
| **Problem Statement Title** | Efficiency in streamlining industrial approvals,compliance processes,and access to government support services |
| **Organization** | Government Of Maharashtra |
| **Department** | Maharashtra State Innovation Society, Department of Skills, Employment, Entrepreneurship and Innovation |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

- Problem Description Entrepreneurs and industrial units may need to obtain multiple registrations,permissions, licences, no-objection certificates, inspections and renewals from different authorities. Requirements may vary by sector, location, project size and stage of operation. Applicants may find it difficult to identify applicable approvals, understand documentation requirements, monitor timelines,respond to queries and access incentives or support schemes.

Departments may face incomplete applications, repetitive scrutiny, manual coordination, limited visibility of bottlenecks and inconsistent compliance monitoring. The challenge is to simplify and accelerate the end-to-end journey while maintaining statutory safeguards.

**Expected Solution:**

/ Outcome A unified, intelligent approval and compliance management solution that can generate a customised approval checklist, guide applicants through documentation, pre-validate submissions, reuse verified data,coordinate parallel departmental workflows, schedule inspections, track service-level timelines, issue alerts, and provide a single dashboard for applications, approvals, renewals and incentives. It may include a regulatory knowledge engine, risk-based scrutiny,common inspection planning, grievance escalation and analytics for identifying delays. Expected outcomes include reduced approval time, fewer incomplete applications, improved transparency,lower compliance cost, better utilisation of government schemes and stronger ease of doing business.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26131"></a>[131] SIH26131: Early detection and management of crop diseases and pest infestations

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26131` (SIH26131) |
| **Problem Statement Title** | Early detection and management of crop diseases and pest infestations |
| **Organization** | Government Of Maharashtra |
| **Department** | Maharashtra State Innovation Society, Department of Skills, Employment, Entrepreneurship and Innovation |
| **Category** | Software |
| **Theme** | Agriculture, FoodTech & Rural Development |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

- Problem Description Farmers often recognise crop diseases or pest infestations only after visible damage has spread. Extension staff may cover large areas, while laboratory diagnosis and expert advice may not be immediately available. Weather, crop stage, variety, soil condition and local pest history influence risk, but these inputs are rarely combined into actionable farm-level alerts. Incorrect diagnosis may lead to delayed treatment, excessive or inappropriate pesticide use, increased cultivation cost,residue concerns and yield loss. The challenge is to provide timely, reliable and locally relevant detection,forecasting and management support.

**Expected Solution:**

/ Outcome A farmer- and extension-worker-friendly crop-health system that supports image based symptom identification, pest-trap or sensor inputs, weather-based risk forecasting, geospatial hotspot mapping,expert validation and multilingual advisories. The system should recommend integrated pest and disease management actions, safe input usage,referral to extension or laboratories, and follow-up monitoring. It should learn from field confirmations and provide dashboards for agriculture officials.Expected outcomes include earlier detection, reduced crop loss, more targeted pesticide use, faster extension response, improved surveillance coverage and better planning of preventive interventions.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26132"></a>[132] SIH26132: Strengthening market linkages and price discovery for farmers

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26132` (SIH26132) |
| **Problem Statement Title** | Strengthening market linkages and price discovery for farmers |
| **Organization** | Government Of Maharashtra |
| **Department** | Maharashtra State Innovation Society, Department of Skills, Employment, Entrepreneurship and Innovation |
| **Category** | Software |
| **Theme** | Agriculture, FoodTech & Rural Development |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

- Problem Description Many farmers, especially smallholders and producer groups, have limited visibility of current and expected prices across nearby markets, processors,institutional buyers and digital trading channels. Information on quality specifications, demand, logistics,storage, payment reliability and buyer credentials may be fragmented. Farmers may sell immediately after harvest because of liquidity or storage constraints and may have weak bargaining power. Buyers, meanwhile,may struggle to aggregate consistent volumes and verify quality. The challenge is to improve transparent price discovery and create reliable, efficient linkages from farm gate to suitable buyers.

**Expected Solution:**

/ Outcome A market-intelligence and transaction enablement solution that aggregates mandi prices, buyer demand, quality requirements, arrival volumes, transport and storage options; provides localised price trends and sale-window recommendations; matches farmers/FPOs with verified buyers; enables lot creation, quality grading,digital offers, logistics coordination and payment tracking; and supports dispute or grievance processes. Expected outcomes include improved farmer price realisation, reduced information asymmetry, lower transaction cost,stronger FPO aggregation, reduced post harvest loss, more reliable buyer sourcing and transparent transaction records.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26133"></a>[133] SIH26133: Accessibility and quality of public healthcare services,particularly in rural and underserved areas

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26133` (SIH26133) |
| **Problem Statement Title** | Accessibility and quality of public healthcare services,particularly in rural and underserved areas |
| **Organization** | Government Of Maharashtra |
| **Department** | Maharashtra State Innovation Society, Department of Skills, Employment, Entrepreneurship and Innovation |
| **Category** | Software |
| **Theme** | MedTech / BioTech / HealthTech |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

- Problem Description Rural and underserved communities may face long travel distances,shortages of specialists, irregular diagnostics, fragmented medical records, delayed referrals and limited awareness of available services. Primary health facilities may have constrained staff and equipment, while patients may move between sub-centres, primary health centres, rural hospitals and district hospitals without continuity of information. Connectivity, language,health literacy and affordability further affect access. The challenge is to improve timely access, continuity, quality and accountability while strengthening—not replacing—the public-health system.

**Expected Solution:**

/ Outcome An integrated care-access and quality support solution that may combine assisted teleconsultation, appointment and queue management, digital triage,longitudinal patient records, referral tracking, diagnostic coordination,medicine availability, high-risk patient follow-up and facility dashboards. It should support frontline health workers, low-connectivity environments,multilingual interaction, emergency escalation and interoperable health records based on approved standards.Expected outcomes include reduced travel and waiting time, earlier consultation, improved referral completion, better follow-up for maternal, child and chronic conditions,improved medicine/diagnostic availability visibility and enhanced quality monitoring.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26134"></a>[134] SIH26134: Challenges in aligning skill development programs with industry requirements and emerging job market demands

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26134` (SIH26134) |
| **Problem Statement Title** | Challenges in aligning skill development programs with industry requirements and emerging job market demands |
| **Organization** | Government Of Maharashtra |
| **Department** | Maharashtra State Innovation Society, Department of Skills, Employment, Entrepreneurship and Innovation |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

- Problem Description Skill-development programmes may be designed using broad or historical occupation categories that do not fully reflect changing technologies, local industry demand, job roles, productivity standards and employer expectations.Course curricula, equipment, trainer capacity and assessment methods may lag emerging requirements. Employers may struggle to identify job-ready candidates, while trainees may complete courses that have limited placement potential. The challenge is to create a continuous, evidence-based mechanism for translating industry demand into course design, capacity planning, trainer development and candidate guidance.

**Expected Solution:**

/ Outcome A labour-market intelligence and curriculum-alignment platform that combines job-posting signals, employer surveys, industry consultations, sector growth data, placement outcomes and emerging-technology trends to identify demand by role, skill, location and proficiency level. The system should map skill gaps to qualifications and courses,recommend curriculum updates, flag obsolete or oversupplied courses,support employer validation and generate district-level training plans. Expected outcomes include stronger placement rates, reduced mismatch, improved employer satisfaction, timely course revision, better equipment and trainer planning, and clearer career pathways for candidates.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26135"></a>[135] SIH26135: Difficulties in tracking employment outcomes,skill gaps, and the impact of skilling initiatives

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26135` (SIH26135) |
| **Problem Statement Title** | Difficulties in tracking employment outcomes,skill gaps, and the impact of skilling initiatives |
| **Organization** | Government Of Maharashtra |
| **Department** | Maharashtra State Innovation Society, Department of Skills, Employment, Entrepreneurship and Innovation |
| **Category** | Software |
| **Theme** | Smart Education |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

- Problem Description Training systems frequently capture enrolment, attendance, assessment and certification, but reliable information on employment, self-employment, job retention, wage progression, relevance of training and longer-term livelihood outcomes may remain incomplete.Trainees may change phone numbers or locations, employers may not report consistently, and multiple programmes may use different identifiers and definitions. Without longitudinal outcomes, it is difficult to compare providers, improve courses, target future investments or demonstrate public value. The challenge is to establish credible, low-burden and privacy conscious outcome tracking.

**Expected Solution:**

/ Outcome A longitudinal skilling-outcomes and impact-measurement system that creates consent-based trainee records,links training with placement and employment signals, conducts automated and assisted follow-ups,captures self-employment and apprenticeship outcomes, validates employer information, measures wage and retention progression, and provides cohort, course, provider, district and demographic analytics. It should identify skill gaps and reasons for non-placement or attrition. Expected outcomes include higher-quality outcome data, better programme and provider accountability,targeted remedial actions, improved resource allocation and evidence-based policy design.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26136"></a>[136] SIH26136: Startup friendly public procurement mechanism that enables government departments to identify,pilot, procure,and scale innovative solutions from eligible startups

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26136` (SIH26136) |
| **Problem Statement Title** | Startup friendly public procurement mechanism that enables government departments to identify,pilot, procure,and scale innovative solutions from eligible startups |
| **Organization** | Government Of Maharashtra |
| **Department** | Maharashtra State Innovation Society, Department of Skills, Employment, Entrepreneurship and Innovation |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

- Problem Description Government departments often face operational problems that could benefit from innovative startup solutions, but conventional procurement processes are generally designed for standardised goods and established vendors.

Departments may find it difficult to formulate outcome-based problem statements, discover suitable startups, evaluate novel technologies, structure controlled pilots, manage intellectual property and data, measure pilot results, and transition successful pilots into compliant procurement or scale-up.Startups may struggle with prior-turnover or experience requirements, long sales cycles, unclear payment milestones and limited visibility of departmental demand. The challenge is to create a transparent, competitive and legally compliant innovation-procurement pathway.

**Expected Solution:**

/ Outcome A structured end-to-end mechanism for challenge identification, startup discovery, eligibility screening, expert evaluation, sandbox or pilot design,milestone-based contracting,performance measurement, payment,independent validation and scale-up decisions. The mechanism should provide standard templates for problem statements, evaluation criteria, pilot agreements, data/IP clauses, cybersecurity, risk management and procurement pathways. It may integrate with recognised startup databases and government e-marketplaces. Expected outcomes include faster discovery and testing of innovative solutions, higher quality pilots, reduced departmental risk, timely startup payments, evidence-based procurement decisions and successful scaling across departments or districts.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26137"></a>[137] SIH26137: Quantum-Inspired Intelligent Traffic Route Optimization in Transportation Systems Using Metaheuristic Optimization

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26137` (SIH26137) |
| **Problem Statement Title** | Quantum-Inspired Intelligent Traffic Route Optimization in Transportation Systems Using Metaheuristic Optimization |
| **Organization** | Egreen Quanta |
| **Department** | Egreen Quanta |
| **Category** | Software |
| **Theme** | Fitness & Sports |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background Modern urban transportation networks face persistent challenges of traffic congestion, inefficient route planning, and high operational costs. Classical optimization techniques struggle with large-scale Vehicle Routing Problems (VRP) because of their NP-hard nature. While quantum computers offer theoretical advantages for combinatorial optimization,current hardware limitations prevent their direct large-scale use. Quantum-inspired metaheuristic algorithms (e.g., Quantum Particle Swarm Optimization - QPSO) embed quantum-mechanical concepts into classical computation, delivering stronger global search, faster convergence, and a better balance between exploration and exploitation.

Problem Description Develop a quantum-inspired metaheuristic optimization framework that dynamically generates near-optimal vehicle routes under real-time or simulated traffic conditions.The transportation network will be modelled as a weighted graph. The framework will focus on algorithms such as Quantum Particle Swarm Optimization (QPSO) and will be benchmarked against conventional metaheuristics and exact methods.

Objectives 1. Design a quantum-inspired metaheuristic framework capable of solving large-scale VRP and shortest-path problems.

2. Minimize total travel time, distance, and traffic congestion.

3. Reduce computational complexity while improving convergence speed and solution quality compared with classical algorithms.

4. Demonstrate scalability for smart-city logistics and intelligent transportation systems.

Expected Solution A complete software platform that implements a Quantum-Inspired Metaheuristic Optimization Algorithm for intelligent traffic routing. The platform must include graph-based network modelling, mathematical formulation of the optimization problem,constraint handling, convergence analysis, and systematic performance benchmarking.

Add 'Delivery Table (Expected Deliverables)' here

#### Dataset & Reference Links

Public/Open

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26138"></a>[138] SIH26138: Quantum-Inspired Fuel Consumption Prediction and Green Fleet Optimization

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26138` (SIH26138) |
| **Problem Statement Title** | Quantum-Inspired Fuel Consumption Prediction and Green Fleet Optimization |
| **Organization** | Egreen Quanta |
| **Department** | Egreen Quanta |
| **Category** | Software |
| **Theme** | Smart Vehicles |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background The maritime and logistics industries are under increasing pressure to reduce greenhouse gas emissions while maintaining operational efficiency and cost-effectiveness. Fuel consumption constitutes one of the largest operational expenses and environmental impacts of fleet operations. Traditional optimization and prediction methods often struggle with the high-dimensional, non-linear, and multi-objective nature of green fleet management, especially when integrating alternative fuels, varying vessel types, and dynamic operational constraints.

Quantum-inspired metaheuristic algorithms offer a promising approach by combining the global search capabilities of quantum principles with classical computing, enabling more effective solutions for complex, large-scale fleet optimization problems.

Description This problem focuses on developing a quantum-inspired optimization and prediction framework for green fleet management. The framework will predict fuel consumption under varying operational conditions and optimize fleet deployment decisions, including the selection of vessel types, capacities, cruising speeds, and the integration of alternative fuels (LNG, methanol, hydrogen, ammonia) and shore power solutions. The goal is to minimize fuel consumption and lifecycle emissions while satisfying cargo demand, schedule reliability, and operational constraints.

Objectives

- Develop accurate quantum-inspired models for predicting fuel consumption across different vessel types and operating conditions.

- Design a quantum metaheuristic optimization framework to determine the optimal mix of vessel types, capacities, and cruising speeds.

- Minimize total fuel consumption, operational costs, and lifecycle greenhouse gas emissions.

- Ensure operational reliability, cargo demand satisfaction, and compliance with emission regulations.

- Benchmark the proposed quantum-inspired approach against conventional prediction and optimization methods in terms of accuracy, convergence speed, solution quality,and scalability.

Expected Solution A comprehensive software platform that implements quantum-inspired algorithms for fuel consumption prediction and green fleet optimization. The solution should include mathematical modelling, data-driven prediction modules, multi-objective optimization, constraint handling, scenario analysis for alternative fuels, and performance evaluation through benchmarking and case studies.

Add 'Delivery Table (Expected Deliverables)' here

#### Dataset & Reference Links

Public/Open

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26139"></a>[139] SIH26139: Hybrid Quantum Machine Learning Platform for Early Disease Detection

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26139` (SIH26139) |
| **Problem Statement Title** | Hybrid Quantum Machine Learning Platform for Early Disease Detection |
| **Organization** | Egreen Quanta |
| **Department** | Egreen Quanta |
| **Category** | Software |
| **Theme** | MedTech / BioTech / HealthTech |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background Early and accurate detection of diseases significantly improves treatment outcomes and reduces healthcare costs. Classical machine learning models have achieved notable success in medical diagnosis; however, they often face limitations when dealing with high-dimensional, noisy, and complex biomedical data (e.g., genomics, medical imaging, and electronic health records).

Quantum machine learning (QML) offers the potential to capture intricate patterns through quantum superposition and entanglement. Due to current hardware constraints, a hybrid quantum-classical approach provides a practical pathway to leverage quantum advantages while remaining executable on existing quantum simulators and near-term quantum devices.

Description This problem focuses on designing and developing a hybrid quantum machine learning platform for early disease detection. The platform will integrate classical pre-processing and feature engineering with quantum-enhanced learning models (such as quantum support vector machines, quantum neural networks, or variational quantum classifiers). It will be applied to biomedical datasets for the early identification of diseases (e.g., cancer, cardiovascular disorders, or neurological conditions). The system should support data ingestion, hybrid model training, prediction, explainability, and performance evaluation against purely classical baselines.

Objectives

- Design a hybrid quantum-classical machine learning architecture suitable for early disease detection.

- Develop quantum-enhanced classification/regression models that can process high-dimensional biomedical data.

- Improve detection accuracy, sensitivity, and specificity compared with classical machine learning baselines.

- Ensure the platform is scalable, interpretable, and compatible with near-term quantum hardware and simulators.

- Incorporate data pre-processing, feature selection, and model explainability modules.

- Benchmark the hybrid approach against classical models in terms of accuracy,computational efficiency, and generalization performance.

Expected Solution A fully functional hybrid quantum machine learning software platform capable of performing early disease detection on real or benchmark biomedical datasets. The solution must include data handling pipelines, hybrid quantum-classical model implementation, training and inference workflows, performance evaluation, explainability features, and comprehensive documentation.

Add 'Delivery Table (Expected Deliverables)' here

#### Dataset & Reference Links

Public/Open

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26140"></a>[140] SIH26140: AI-Based Interactive Quantum Algorithm Learning Platform

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26140` (SIH26140) |
| **Problem Statement Title** | AI-Based Interactive Quantum Algorithm Learning Platform |
| **Organization** | Egreen Quanta |
| **Department** | Egreen Quanta |
| **Category** | Software |
| **Theme** | Smart Education |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background Quantum computing is a transformative technology with significant impact across scientific and industrial domains. However, education in this field remains challenging due to the abstract nature of core concepts such as qubits, superposition, entanglement, and quantum algorithms.

Existing learning resources are often static, heavily theoretical, and lack hands-on interaction.

Limited access to real quantum hardware further restricts practical learning. There is a strong need for an integrated, interactive, and intelligent platform that combines theoretical instruction, visual circuit design, real-time simulation, and personalized AI-based guidance to accelerate quantum education and workforce development.

Description The goal is to develop an AI-powered interactive web-based platform that enables students, researchers, and professionals to learn, design, simulate, and visualize quantum algorithms.

The platform will offer structured learning modules covering quantum computing fundamentals, circuit design, and standard quantum algorithms. Users will be able to construct quantum circuits through a drag-and-drop interface or by writing code, execute them on multiple quantum simulators, and visualize quantum states and measurement outcomes. AI-assisted features will provide real-time explanations, error detection, optimization suggestions,and personalized learning paths. The system will support major quantum software development kits and promote collaborative and modular learning.

Objectives

- Design and develop an interactive web-based platform for learning quantum computing and quantum algorithms.

- Provide graphical (drag-and-drop) and code-based quantum circuit design tools.

- Enable real-time execution and simulation of quantum circuits using multiple backends(Qiskit Aer, PennyLane, Cirq, qBraid, etc.).

- Integrate AI-assisted tutoring for concept explanation, code generation, debugging, and personalized learning recommendations.

- Support visualization of quantum states, Bloch spheres, measurement probabilities, and circuit execution results. Include assessment modules, coding challenges, progress tracking, and instructor dashboards.

Expected Solution A comprehensive AI-based interactive quantum learning platform that seamlessly integrates education, programming, simulation, visualization, and intelligent tutoring. The solution will offer structured theoretical content, visual circuit builders, integrated code editors, multi-framework simulation support, AI-powered assistance, assessment tools, and progress analytics. The platform will be designed to be scalable and accessible, contributing to the development of a quantum-ready workforce.

Add 'Delivery Table (Expected Deliverables)' here

#### Dataset & Reference Links

Public/Open

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26141"></a>[141] SIH26141: Quantum-Inspired Cyber Threat Detection for Digital Signature Security

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26141` (SIH26141) |
| **Problem Statement Title** | Quantum-Inspired Cyber Threat Detection for Digital Signature Security |
| **Organization** | Egreen Quanta |
| **Department** | Egreen Quanta |
| **Category** | Software |
| **Theme** | Blockchain & Cybersecurity |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background The rapid advancement of quantum computing poses a serious threat to classical public-key cryptographic systems such as RSA and Elliptic Curve Cryptography (ECC), which can be broken by algorithms like Shor's algorithm. This vulnerability endangers the security of critical digital infrastructures. Quantum Digital Signature (QDS) protocols offer information-theoretic security by exploiting fundamental principles of quantum mechanics. Among these, teleportation-based QDS protocols are particularly promising because they enable secure signature generation and verification through quantum teleportation and entanglement, while reducing some of the practical deployment complexities associated with earlier QDS schemes.

Description This problem focuses on developing a quantum-inspired cyber threat detection framework specifically designed for Quantum Digital Signature (QDS) systems. The framework will detect threats to the integrity and authenticity of digital signatures—such as forgery, impersonation, replay attacks, and quantum channel manipulation—without relying on artificial intelligence or machine learning techniques. Instead, it will utilize quantum principles including Pauli eigenstates, projective measurements, and statistical analysis of measurement outcomes to evaluate forgery probabilities and verification accuracy, while preserving information-theoretic security guarantees.

Objectives

- Design a quantum-inspired threat detection framework for teleportation-based Quantum Digital Signature protocols.

- Detect digital signature forgery, impersonation, replay attacks, and unauthorized verification attempts.

- Utilize Pauli eigenstates, quantum measurement analysis, and statistical threshold methods for threat identification.

- Ensure efficient verification algorithms that maintain information-theoretic security.

- Evaluate the framework through forgery probability analysis, attack simulations, and performance metrics.

Expected Solution A software framework for Quantum-Inspired Cyber Threat Detection tailored to teleportation-based Quantum Digital Signature protocols. The solution will simulate quantum public key distribution using Bell-state entanglement and quantum teleportation, apply Pauli correction operations and projective measurements for signature verification, and detect malicious activities through statistical evaluation and threshold-based decision rules. The framework will include mathematical modelling, attack simulation capabilities, security analysis, and performance evaluation, ensuring deterministic acceptance of legitimate signatures, low computational complexity, and strong security guarantees.

Add 'Delivery Table (Expected Deliverables)' here

#### Dataset & Reference Links

Public/Open

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26142"></a>[142] SIH26142: Deep Learning Based Super Resolution Mapping (SRM) from Medium Resolution Satellite Imageries

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26142` (SIH26142) |
| **Problem Statement Title** | Deep Learning Based Super Resolution Mapping (SRM) from Medium Resolution Satellite Imageries |
| **Organization** | National Technical Research Organisation (NTRO) |
| **Department** | National Technical Research Organisation (NTRO) |
| **Category** | Software |
| **Theme** | Smart Education |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Medium-resolution satellite imagery, typically ranging from 10 to 30 meters, is widely used in change detection, agriculture, land-cover mapping, disaster monitoring, and urban planning because it offers broad coverage and frequent revisit time. However, the spatial detail is often insufficient for fine-scale analysis, such as identifying small buildings, narrow roads, field boundaries, or localized damage assessment. This creates a need for advanced deep learning based generative enhancement techniques that can extract greater value from existing Earth observation data.

**Description:**

Medium-resolution satellite imagery, usually ranging from 10 to 30 meters, is widely used in remote sensing for agriculture monitoring, land-cover mapping, urban planning, disaster assessment, and environmental observation because it provides large-area coverage and frequent revisit capability. However, its spatial resolution is often not sufficient to clearly identify fine details such as narrow roads, small buildings, field boundaries, water edges, or localized damage. This limitation reduces the accuracy and confidence of interpretation and decision-making in applications that require detailed ground-level information. Generative AI super-resolution addresses this problem by using advanced models such as GANs, diffusion models, and deep neural networks to enhance medium-resolution satellite images into sharper and more information-rich finer outputs. These models learn spatial textures, patterns, edges, and spectral relationships from training data containing both medium-resolution and high-resolution image pairs. The goal is not simply to make the image visually clearer, but to reconstruct useful fine-scale details while preserving the original geographic and spectral consistency of the satellite data.

The expected solution is a robust AI-based super-resolution framework that can take medium-resolution satellite imagery as input, perform pre-processing, apply a trained generative model, and produce an enhanced spatial resolution image, suitable for analysis. The system should improve feature visibility, support better classification, change detection, crop monitoring, urban mapping, and disaster response. At the same time, it must clearly manage uncertainty because some reconstructed details are inferred by the model and not directly observed. Therefore, validation against high-resolution reference data is essential to ensure that the enhanced outputs are scientifically reliable and useful for real-world remote sensing applications.

**Expected Solution:**

The expected solution is a robust super-resolution framework model based on the choice of participating team (Transformers/Generative/CNN etc.) that can transform the input medium-resolution satellite imagery (10m Sentinel-2 Satellite Imagery) into sharper, information-rich products (<4m) while preserving geospatial and spectral consistency. The solution should include pre-processing, model training with paired datasets, accuracy assessment, and validation against high-resolution references. Ideally, it should support applications such as crop monitoring, urban analysis, and disaster assessment. The final outcome should improve in-terms of interpretability and analytical utility, while clearly accounting for uncertainty and error components.

#### Dataset & Reference Links

https://browser.dataspace.copernicus.eu

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26143"></a>[143] SIH26143: Leveraging satellite imagery to determine Oil spills at sea along with AIS data correlations to identify vessel responsible for the spill.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26143` (SIH26143) |
| **Problem Statement Title** | Leveraging satellite imagery to determine Oil spills at sea along with AIS data correlations to identify vessel responsible for the spill. |
| **Organization** | National Technical Research Organisation (NTRO) |
| **Department** | National Technical Research Organisation (NTRO) |
| **Category** | Software |
| **Theme** | Space Technology |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Marine oil spills inflict great damage on marine ecosystems and several times remains un-attributable to the vessel causing such spills. Leveraging satellite imagery along with AIS data will enable detection of oil spills and vessel responsible for the same.

**Description:**

The core challenge attempts to facilitate detection of oil spills and also in identifying the polluting vessel using remote sensing satellite data, such as SAR and EO imagery and AIS data. Participants are to design an intelligent automated pipeline to do the following: (a) Detect and characterise the oil spill and calculating geometric properties and age if feasible. (b) Using oceanographic and meteorological data, it is envisaged to trace the slick towards the origin point and time, predict the future flow of the slick, and (c) analyse and attribute the spill to a vessel using historic AIS data to reconstruct vessel traffic around the origin window in space and time. The irrelevant traffic is to be filtered out and potential suspect vessels are to be scored considering various aspects such as proximity, trajectory, behavioural anomalies etc.

**Expected Solution:**

An automated detection and hindcasting machine learning model that identified oils slicks from satellite imagery, mapping their drift paths backward and forward. It also ranks potential culprit vessel based on spatio-temporal correlation with AIS data. A suitable visual interface is also to be developed.

#### Dataset & Reference Links

AIS Data 1.Format of AIS data can be obtained from sample AIS data available to https://marinecadastre.gov/accessais/.

2.Real AIS if available may be used else synthetic data can be prepared for the region of oil spill to demonstrate the functioning of the algorithm.

Satellite Imagery Data of Oil spills 3.Zenodo - Sentinel-1 SAR Oil Spil

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26144"></a>[144] SIH26144: Design & Development of a High-Sensitivity Micro barometer Infrasound sensor

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26144` (SIH26144) |
| **Problem Statement Title** | Design & Development of a High-Sensitivity Micro barometer Infrasound sensor |
| **Organization** | National Technical Research Organisation (NTRO) |
| **Department** | National Technical Research Organisation (NTRO) |
| **Category** | Hardware |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

The Infrasound sensors are precision instruments designed to detect and measure low frequency atmospheric pressure waves, known as infrasound, that fall below the range of human hearing, typically under 20 Hz. These waves can travel long distances through the atmosphere and are produced by a variety of natural and human-made sources including distant Industrial explosions, volcanic eruptions, severe weather systems, meteors, rocket launches, and other energetic phenomena. Detection and analysis of these signals are important for atmospheric monitoring, geophysical research, disaster warning systems and security applications.

**Description:**

It is required to design and develop a high-sensitivity atmospheric microbarometer Infrasound sensor capable of measuring infrasonic pressure fluctuations in the frequency range of approximately 0.01 Hz to 20 Hz.

**The sensor should address the complete hardware architecture, including:**

(a).Pressure sensing mechanism.

(b).Mechanical transducer design.

(c).Differential pressure measurement technique.

(d).Low-noise analog front-end electronics.

(e).Temperature compensation.

(f).Long-period pressure equalization system.

(g).Environmental enclosure.

(h).Wind-noise reduction interface.

(i).Calibration methodology.

The design should aim to detect very small pressure variations while maintaining long-term stability, low drift, and high signal fidelity. The data acquisition (digitizer) and real time waveform display & analysis software available in open market to be included to demonstrate complete functional sensor system.

**Expected Solution:**

The prototype infrasound sensor should have high sensitivity, long-term stability and low-noise signal condition to measure infrasound signals accurately. Sensor should demonstrate:

(a).Detection of low-frequency pressure signals.

(b).Laboratory characterization of frequency response.

(c).Noise floor measurements.

(d).Sensitivity estimation.

(e).Stability testing.

The evaluation will be conducted based on the achievement of the following parameters Attach Table Here The digitizer and data acquisition software (available in open market) for real time waveform display & analysis will be arranged by candidates themselves to demonstrate the complete functional sensor system.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26145"></a>[145] SIH26145: AI-Based Detection of Cyber Threats in Unidirectional IP Traffic

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26145` (SIH26145) |
| **Problem Statement Title** | AI-Based Detection of Cyber Threats in Unidirectional IP Traffic |
| **Organization** | National Technical Research Organisation (NTRO) |
| **Department** | National Technical Research Organisation (NTRO) |
| **Category** | Software |
| **Theme** | Blockchain & Cybersecurity |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Critical-infrastructure operators observe their gateway and peering links using passive mirroring or hardware data diodes that copy traffic into a monitoring enclave in one direction only. The enclave can see everything crossing the link, but it has no physical or protocol-level path back into the production network. This is deliberate as it removes an entire class of attack in which a compromised monitoring or analytics system becomes a pivot into the core network, and it preserves a clean chain of custody for forensic use. The trade-off is that any intelligence layer sitting in that enclave must work purely from what it can passively observe such as packet captures, exported flow records (NetFlow/IPFIX/sFlow), and derived metadata with no ability to send probes, complete handshakes with the traffic source, or push a mitigation command back.

**Description:**

The objective is to design and build an AI/ML pipeline that ingests a one-directional stream of IP traffic from a simulated IP data and detects, classifies, and scores cyber-security threats in near real time, using only passively collected data. The pipeline must assume it can never re-contact the traffic's source or destination, cannot rely on completing any handshake itself, and cannot issue any action back across the ingest path. Its output is intelligence as labelled alerts, confidence scores, and supporting evidence displayed on visualisation dashboard. The system is designed to detect the following types of threat:

a. Volumetric / protocol DDoS: SYN floods, UDP reflection/amplification, and spoofed-source floods identified from flow-level rate and source-IP entropy statistics.

b. Botnet C2 beaconing: Periodicity and inter-arrival analysis on flows that repeat at regular intervals toward a small set of destinations.

c. DGA domains and DNS tunnelling: Entropy/n-gram analysis of DNS query names, plus query-length and record-type anomalies.

d. Malware inside encrypted sessions: Detection from TLS/QUIC metadata alone (JA3/JA3S or JA4 fingerprints, packet-size and timing sequences), without decrypting payload.

e. Reconnaissance and port scanning: Fan-out patterns from a single source across many destination ports or hosts.

f. Data exfiltration: Asymmetric flow-volume anomalies and unusual outbound-to-inbound byte ratios.

Expected Solution The system must be delivered as working prototype (source repository) implementing ingest, feature extraction, model inference, and alert output. Accompanying documentation of the model(s) used, features engineered, and the training/validation approach. The prototype must also include a simple dashboard of live or replayed detections with severity and confidence adhering to the following architectural constraints:

a. Read-only ingest: Treat the input as strictly read-only. Any design that assumes a return path, a live query to the source, or an inline block is out of scope.

b. No payload decryption: TLS/QUIC sessions must be analysed from metadata only, never from decrypted content.

c. Streaming, not batch: The pipeline must process traffic incrementally and raise alerts with bounded latency, not just produce an end-of-run report.

d. Defined throughput target: Solutions must state and demonstrate the traffic rate they were tested against (e.g., flows/sec or Mbps sustained).

e. Standardized alert schema: Alerts must be structured records for instance timestamp, flow identifier, threat class, confidence score, and supporting evidence feature.

#### Dataset & Reference Links

a)Synthetic and lab-generated traffic: Benign load from iperf3, Ostinato, or TRex; attack traffic from hping3 (SYN/UDP floods), Slowloris (slow HTTP exhaustion), dnscat2/iodine (DNS tunnelling), and DGA samples from published algorithms (e.g., via DGArchive) or a sandboxed C2 emulator for realistic beaconing timing.

b)Feature extraction : Extrac

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26146"></a>[146] SIH26146: AI-Powered Monitoring & Analysis of Bitcoin Transaction Traffic

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26146` (SIH26146) |
| **Problem Statement Title** | AI-Powered Monitoring & Analysis of Bitcoin Transaction Traffic |
| **Organization** | National Technical Research Organisation (NTRO) |
| **Department** | National Technical Research Organisation (NTRO) |
| **Category** | Software |
| **Theme** | Transportation & Logistics |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Bitcoin's pseudonymous, peer-to-peer design lets criminal actors move, layer, and cash out illicit funds — ransomware payments, darknet-market proceeds, extortion, and laundering — while evading traditional financial surveillance.

The objective of problem statement is to design and build a complete system (offline) that ingests bulk Bitcoin transaction/network metadata (in CSV/JSON/XML), correlates network-layer (IP/port/timing) observations with blockchain-layer (wallet/TXID/amount) data, and applies AI/ML to detect anomalies, cluster entities, and generate prioritized, explainable investigative leads.

**Description:**

i.Challenge Objectives-
- Ingest & parse a bulk metadata dataset (timestamp, src/dst IP & port, TXID, input/output wallet addresses, amounts, fee, script type).

- Build an entity/transaction graph linking IPs, wallets, and transactions.

- Implement AI/ML detection use case (see Section 4) with a working model — not just rules.

- Generate a ranked, explainable alert list (why a wallet/transaction was flagged, with a confidence score).

- Present findings via a simple dashboard or link-analysis visualization.

ii.Suggested AI/ML Focus Areas Attach Table Here of AI/ML Focus Areas iii.Dataset: Parameters & Synthetic Generation Participants will work with a synthetic dataset modelled on real Bitcoin P2P/transaction fields (no real seized or live-intercept data will be provided). Minimum fields: timestamp, src_ip, dst_ip, src_port, dst_port, txid, input_addresses[], output_addresses[], input_amounts[], output_amounts[], geo_country/asn (integrate open source downloadable Geo IP database).

**Expected Solution:**

- Workable complete offline solution for linux platform.

- Working prototype (code repo) with ingestion, correlation, and AI/ML model.

- Short technical write-up: approach, model choice, and explain ability method.

- Dashboard/visualization showing flagged entities and evidence for each flag.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26147"></a>[147] SIH26147: Automated model for analysis of .IQ and .wav files along with signal parameter extraction

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26147` (SIH26147) |
| **Problem Statement Title** | Automated model for analysis of .IQ and .wav files along with signal parameter extraction |
| **Organization** | National Technical Research Organisation (NTRO) |
| **Department** | National Technical Research Organisation (NTRO) |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

The raw data for analysis of signal collected off the air typically range from few Khz to Ghz bands. The analysis is being carried out manually to identify the signal parameters and the resultant data is then utilised for processing signals in the designated sensors. This data is often insufficient for fine grain analysis for parameter extraction such as modulation type, sampling rate, FEC, interleaving, etc. This creates a need for advanced data processing to extract the observation data.

**Description:**

The terrestrial signals received from various sources includes data in HF, VHF and UHF bands. The raw data collected in the form of .wav or .IQ format to retain the characteristics of wave form. The analysis of signals is primarily dependent on the basic characteristics of data points selected during recording of these signals. Since the data point are recorded from different sensors and different locations, the parameters may vary. Therefore, the data available for analysis is often insufficient to clearly identify fine details such as sampling rate, modulation type, interleaving, FEC etc. This limitation reduces the accuracy and confidence of interpretation and data analysis that require detailed information. The data saved as .IQ and .wav have different parameters and therefore they store the raw information in different format. These files have to be processed in different ways for signal analysis to extract signal parameters. The problem can be addressed using advanced models such as GNU Radio, python, C++ to enhance the parameter extraction capability and more information rich inputs. The spectral relationship from training data containing both .IQ and .wav formats can be utilised for identifying signal parameters and carry out deeper analysis. The expected solution should be able to demodulate signals.

The GUI based model will have features to take .IQ or .wav file as input data and perform following tasks.

i.Identify signal parameters (Sampling frequency, Modulation, FEC, Interleaving). Additional features if feasible may be included.

ii.Demodulate signals (FSK, QAM PSK)

iii.Carry out de-interleaving (Block, Convolution, Diagonal, Pseudo Random).

iv.FEC (short-constrained convolution codes with Viterbi decoding, RS block codes, Concatenated codes, LDPC).

v.Bit stream correlation.

**Expected Solution:**

The expected system should improve feature visibility of signals with the help of GUI, enable automated signal analysis to identify spectral features such as sampling frequency, constellation plot, water fall (time-frequency domain), demodulate signals, carry out de-interleaving and error correction. The output can then be used to carry out correlation of bit stream for identification of header and payload.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26148"></a>[148] SIH26148: Creation of scripts/functions with new programming language to commence Computer & Network forensic analysis without triggering security solutions

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26148` (SIH26148) |
| **Problem Statement Title** | Creation of scripts/functions with new programming language to commence Computer & Network forensic analysis without triggering security solutions |
| **Organization** | National Technical Research Organisation (NTRO) |
| **Department** | National Technical Research Organisation (NTRO) |
| **Category** | Software |
| **Theme** | Blockchain & Cybersecurity |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Modern antivirus solutions restrict proprietary software from executing or creating custom scripts designed to analyze the system for deep forensic system analysis. They rely heavily on behavioral heuristics, static signature matching, common compiler outputs (like standard MSVC or GCC artifacts), typical API call sequences and kernel-level monitoring to intercept activities. However, a significant paradigm shift may occur when programmers adopt sophisticated software engineering practices—specifically continuous integration and continuous deployment (CI/CD).

**Description:**

Creating 'Next-Gen' programming language framework, named as 'JOCKY' using cross-platform compiler (windows & ubuntu) which enables systematic creation of scripts for analyzing malicious activities and also provide the complete digital forensics of the computer or network. By utilizing this specific new developed programming language, the framework will not be hindered by any of the existing anti-virus in the environment. This framework should include various scripts/functions which combined with automated polymorphic engines, custom encryption, and multi-vector in-memory execution via native components or Bring your own vulnerable driver (BYOVD) techniques. Framework also able to handle multiple system analysis simultaneously using central management interface. The traffic b/w management interface and client should be routed through trusted cloud infrastructure or content delivery networks (CDNs) using domain fronting or legitimate cloud APIs.

**Expected Solution:**

The scope of the problem is to create scripts/functions in the proprietary programming language (named JOCKY) which enables the user to detect the adversaries:

1. Independent programming Language - Programming language or custom Language-independent intermediate representation (LLVM) frontend alters basic control-flow graphs, token generation, and binary structures, rendering signature-based detection ineffective.

2. Polymorphism in scripts/function generated - Rather than manually packing a binary, the scripts/function in framework uses a continuous delivery pipeline. Every iteration automatically passes through integrated obfuscators, variable-encryption routines, and polymorphic engines. This ensures that every deployment instance possesses unique hashes, modified entry points, and altered import tables, neutralizing traditional file-reputation databases.

3. Living-off-the-Land & BYOVD Execution - The scripts/functions in framework should avoid standard, noisy API calls for core operations like persistence, privilege escalation, and network routing (SOCKS5). Instead, it relies on:

A. In-Memory Execution: Utilizing multiple distinct file-less techniques (e.g., process hollowing, reflective DLL injection, API unhooking, direct system calls, or thread execution hijacking) to run secondary script entirely within the memory space of trusted processes.

B. Kernel-Level Subversion: Detection of legitimate or vulnerable third-party drivers (BYOVD) to disable EDR callbacks or manipulate kernel structures directly, blinding security agents running in user or kernel space.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26149"></a>[149] SIH26149: Design and Development of an Integrated Secure Data Erasure and Advanced File Recovery Tool for Digital Forensics and Data Sanitization

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26149` (SIH26149) |
| **Problem Statement Title** | Design and Development of an Integrated Secure Data Erasure and Advanced File Recovery Tool for Digital Forensics and Data Sanitization |
| **Organization** | National Technical Research Organisation (NTRO) |
| **Department** | National Technical Research Organisation (NTRO) |
| **Category** | Software |
| **Theme** | Blockchain & Cybersecurity |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

With the rapid growth of digital storage technologies, organizations, government agencies, law enforcement units, enterprises, and individual users face two major challenges: securely destroying sensitive data to prevent unauthorized recovery and recovering deleted digital evidence during forensic investigations. Existing solutions generally focus on either secure data deletion or file recovery and often support limited storage technologies and file systems. This forces investigators and cybersecurity professionals to use multiple tools, increasing complexity, cost, and operational inefficiencies. Therefore, there is a need for a unified platform that integrates secure data sanitization with advanced forensic-grade file recovery and carving capabilities.

**Description:**

The proposed solution aims to develop an integrated software platform consisting of three core modules: (1) Secure Drive Eraser, (2) Secure File & (3) Folder Eraser, and Advanced File Carving and Recovery. The Secure Drive Eraser Module should securely sanitize HDDs, SSDs, USB drives, memory cards, and external storage devices while providing verification mechanisms, audit logging, tamper-resistant reporting, and compliance with industry and government data destruction standards. The Secure File and Folder Eraser Module should enable selective secure deletion of files and folders, remove associated metadata and residual traces, support batch operations, verify erasure success, and provide audit reporting across multiple file systems and operating systems. The Advanced File Carving and Recovery Module should recover deleted files from formatted, damaged, or corrupted media using signature-based, structure-based, and intelligent carving techniques. It should support recovery without file system metadata, fragmented file reconstruction, automatic classification of recovered files, confidence scoring, and comprehensive forensic reporting while preserving evidential integrity.

**Expected Solution:**

The expected outcome is an integrated software platform that combines secure data sanitization and forensic recovery capabilities within a single environment. The solution should provide (1) secure drive erasure with verification and reporting, (2) secure file and folder deletion with metadata cleansing, (3) advanced file carving and recovery from formatted media, support for multiple storage devices and file systems, automated classification and validation of recovered files, comprehensive audit logs and forensic reports, a user-friendly graphical interface, and compliance with forensic and data sanitization standards. Expected deliverables include an integrated software tool, (1) Secure Drive Eraser Module, (2) Secure File and Folder Eraser Module, (3) Advanced File Carving and Recovery Module, Reporting and Audit Management System, User Interface Dashboard, validation and testing documentation, user manuals, technical documentation, and performance evaluation reports. The solution should improve secure data disposal practices, reduce the risk of unauthorized data recovery, enhance forensic investigation capabilities, increase recovery rates from damaged storage media, reduce investigation time, improve compliance and auditability, and provide a unified platform for secure sanitization and forensic recovery operations.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26150"></a>[150] SIH26150: Development of a Multi-Vendor DVR/NVR Forensic Analysis Tool for Standardized Acquisition, Recovery, and Analysis of Surveillance Evidence.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26150` (SIH26150) |
| **Problem Statement Title** | Development of a Multi-Vendor DVR/NVR Forensic Analysis Tool for Standardized Acquisition, Recovery, and Analysis of Surveillance Evidence. |
| **Organization** | National Technical Research Organisation (NTRO) |
| **Department** | National Technical Research Organisation (NTRO) |
| **Category** | Software |
| **Theme** | Blockchain & Cybersecurity |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Digital/Network Video Recorders (DVR/NVRs) are widely used for surveillance in government agencies, law enforcement, critical infrastructure, businesses, and residential environments. Major DVR/NVR manufacturers such as Dahua Technology, CP Plus, Honeywell Security, TP-Link, Godrej, Uniview, HIKVISON, and Matrix use proprietary storage formats, file systems, metadata structures, and video encoding mechanisms. During forensic investigations, surveillance footage serves as crucial digital evidence; however, the lack of standardization across DVR/NVR vendors makes acquisition, recovery, analysis, and validation difficult. Investigators often rely on multiple vendor-specific tools, resulting in increased investigation time, inconsistent results, timestamp synchronization issues, challenges in deleted footage recovery, and difficulties in maintaining evidence integrity. Therefore, a unified vendor-agnostic DVR/NVR forensic analysis platform is required to provide standardized workflows for evidence acquisition, recovery, analysis, validation, and reporting.

**Description:**

The proposed solution aims to overcome challenges such as non-standard forensic acquisition methods, proprietary file systems and video formats, difficulty in recovering deleted or damaged recordings, inconsistent timestamps, limited event correlation across cameras, challenges in maintaining chain of custody, dependence on multiple tools, lack of standardized reporting, and limited use of intelligent video analytics. The tool should support major DVR/NVR OEMs including Dahua Technology, CP Plus, Honeywell Security, HIKVISON, TP-Link, Godrej, Uniview, Matrix, and other commonly used platforms. It should automatically identify DVR models, parse proprietary file systems, create forensic images, extract videos and metadata, decode proprietary formats, recover deleted footage, normalize timestamps, generate cryptographic hashes (MD5 and SHA-256), correlate events across cameras, maintain chain-of-custody records, generate reports, and perform AI-based analytics such as face, object, and motion detection. Key modules include Device Identification, Acquisition, File System & Format Parsing, Recovery, Timeline Analysis, Reporting, and Machine Learning.

**Expected Solution:**

The expected outcome is a software-based forensic platform capable of performing standardized acquisition, recovery, analysis, validation, and reporting of surveillance evidence across multiple DVR/NVR vendors. The solution should support at least five to six major DVR/NVR OEMs (Dahua Technology, CP Plus, Honeywell Security, TP-Link, Godrej, Uniview, HIKVISON and Matrix), provide a unified forensic workflow, reduce dependency on vendor-specific tools, automate evidence acquisition and analysis, improve deleted video recovery, ensure evidence integrity and admissibility, and generate comprehensive forensic reports. Deliverables include a comparative analysis of major DVR/NVR OEMs (Dahua Technology, CP Plus, Honeywell Security, TP-Link, Godrej, Uniview, and Matrix), DVR/NVR forensic Image, system architecture documentation, a functional prototype, Standard Operating Procedures (SOPs), validation reports, user manuals, and a final project report. The tool should successfully parse proprietary file systems, decode video formats, recover deleted recordings,verify evidence integrity through cryptographic hashing, generate standardized reports, reduce analysis time, and produce reliable and legally defensible forensic results.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26151"></a>[151] SIH26151: Dark web threat actor de-anonymization

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26151` (SIH26151) |
| **Problem Statement Title** | Dark web threat actor de-anonymization |
| **Organization** | National Technical Research Organisation (NTRO) |
| **Department** | National Technical Research Organisation (NTRO) |
| **Category** | Software |
| **Theme** | Blockchain & Cybersecurity |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

The dark web has become a preferred operating space for threat actors in the modern age, mainly because it lets them hide their identity behind Tor hidden services, which makes attribution of threat actors operating on darkweb the main challenge for any investigation. Such threat actors carry out a wide range of unlawful activities such as drugs and arms sale, stolen data and hacking services, money laundering, terror financing, etc. The objective of this problem statement is to build a system for the deanonymization of dark web threat actors and link them to suspect real-world entities.

**Description:**

The system shall deanonymize dark web threat actors by continuously gathering their footprints from a range of sources (marketplaces, forums, deep web etc.) and linking them to the identifying information available on those sources. The system envisages three core capabilities. First, finding misconfigurations in Tor hidden services—such as exposed server-status pages, SSL certificates tied to clearnet domains, default service banners, descriptor inconsistencies, etc and matching them with clearnet infrastructure to point to the likely origin servers. Second, mapping threat actors across multiple marketplaces into a single relationship graph of handles, PGP keys, wallets and trust links. Third, using AI-based analysis, including stylometric persona identification and behavioural profiling, to link rebranded or migrated personas to known threat actors. The system shall provide an analytical front end to query the database across a chosen timeline and shall work in an autonomous mode, drawing on available sources of good quality and reliability.

**Expected Solution:**

An end-to-end system shall be developed for the collection, storage, contextualization and querying (through GUI/dashboards) of dark web threat actor intelligence—covering actor profiles, identifiers (handles, PGP keys, wallets etc.), hidden service infrastructure indicators, persona linkages, attribution confidence, category, last scan date and source. The system shall also provide the facility to export the result set in CSV, JSON and report formats.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26152"></a>[152] SIH26152: Social Media Analytics

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26152` (SIH26152) |
| **Problem Statement Title** | Social Media Analytics |
| **Organization** | National Technical Research Organisation (NTRO) |
| **Department** | National Technical Research Organisation (NTRO) |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Social media platforms are complex ecosystems driven by human emotion, diverse demographics, and interconnected networks. To truly understand an online community, it is required look beneath the surface. This requires understanding how followers feel (Sentiment Analysis), who those followers are (Demographics), what topics are captivating them (Trend Tracking), and how they influence one another (Link Analysis). Combining these four vectors using AI is the key to unlocking true audience intelligence.

**Description:**

Participants will be challenged to design and build an AI-driven Social Media Analytics Framework that processes raw platform data to extract deep, actionable audience insights. The system must leverage advanced Artificial Intelligence and Machine Learning techniques to simultaneously infer follower sentiment, map audience demographics, identify top trending narratives, and perform link/network analysis to uncover how information and influence flow among followers.

**Expected Solution:**

AI solution must address the following five core components:

A. Continuous Data Collection & Timeline Management: Design a multi-platform data ingestion pipeline capable of pulling live data, posts, user interactions, and comments. The architecture must support a structured, time-stamped historical database to map out the exact chronology of conversations. The pipeline platform requirements are categorized as follows:

- Essentials (Must-Have): X (formerly Twitter) & Telegram.

- Desirable (Good-to-Have): Instagram & Facebook.

- Appreciable Additions: Reddit or YouTube (for extracting text-based context from video comments).

B. Multi-Dimensional Sentiment Inference: Use Natural Language Processing (NLP) to detect nuanced emotions (e.g., sarcasm, anxiety, excitement, supportive, against etc.) within user posts and comment threads, mapping how these sentiments fluctuate along the established data timeline.

C. Automated Demographic Profiling: Develop models to infer aggregate, anonymized follower demographics (such as age brackets, geographic distribution, language, and professional interests) based on public profile indicators, bio text, behavioral patterns etc.

D. Real-Time Trend & Topic Detection: Automatically identify, rank, and predict rising trends, viral keywords, and shifting discussions as they emerge chronologically in the dataset.

E. Link Analysis & Network Topology: Map the relationships among followers. Identify 'nodes of high influence' (key opinion leaders) and visualize how a trend or sentiment spreads from one user segment to another over time.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26153"></a>[153] SIH26153: AI based Network Attack Forecasting from Network Traffic Data

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26153` (SIH26153) |
| **Problem Statement Title** | AI based Network Attack Forecasting from Network Traffic Data |
| **Organization** | National Technical Research Organisation (NTRO) |
| **Department** | National Technical Research Organisation (NTRO) |
| **Category** | Software |
| **Theme** | Blockchain & Cybersecurity |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

This challenge seeks AI systems capable of learning network behaviour, anticipating attacker progression and supporting proactive cyber defence using the emerging concept of World Models. Design and develop a software prototype that learns the evolving state of a computer network from traffic telemetry and predicts the likelihood and progression of malicious activity before compromise is completed. The solution should ingest network traffic, learn temporal behaviour, forecast future attack states and provide interpretable decision support for defenders. Solutions should demonstrate applicability to enterprise environments and Critical Information Infrastructure.

- Represent network state using feature vectors or graphs.

- Learn state-transition dynamics using sequence models (LSTM, Transformer), Graph Neural Networks, latent state models or other AI techniques.

- Forecast future network states and estimate the probability of attacker progression.

- Map predicted behaviour to recognised attack stages (e.g. MITRE ATT&CK).

- Provide explain ability using attention mechanisms, feature attribution or equivalent techniques
- Detailed Description Participants are encouraged to build world models based AI systems that move beyond static intrusion classification towards predictive cyber defence. The solution may utilise flow records, packet captures, authentication logs or other publicly available cybersecurity telemetry. It should model temporal relationships, infer evolving network state, predict future attack progression and present meaningful explanations for its predictions.

Traditional machine learning classifiers applied to network traffic treat each flow in isolation and map it to a binary benign/malicious label. This discards the temporal and causal structure of an infiltration: the sequence in which ports are probed, the pattern in which SYN flags precede ACK floods, the inter-arrival timing of reconnaissance packets before lateral movement begins. An infiltration is a process unfolding over time, not a single anomalous packet.

- World Models — AI architectures that learn an internal causal simulation of how environment states evolve — offer a fundamentally different approach. Rather than classifying traffic, a world model learns the transition dynamics P(S_t+1 | S_t): given the current observed network state (active flows, flag distributions, port activity, packet timing), what is the probability distribution over future states. This enables forward simulation: roll out K steps ahead and identify whether the current trajectory converges to an infiltration state, before the attacker completes the kill chain.

1. Input Data — Two Levels of Traffic Feature Teams must work with both flow-level and packet-level features drawn from open-source network traffic datasets:

- Flow-level features (NetFlow / IPFIX format): source and destination IP/port pairs, TCP flag bitmask (SYN, ACK, FIN, RST, PSH, URG), protocol, bytes transferred per flow, packets per flow, flow duration, inter-arrival time (IAT) statistics (mean, variance, max), and bidirectional flow ratios.

- Packet-level features (PCAP-derived): Time-To-Live (TTL) values and their variance across a session, TCP window size, IP fragment flags, payload size distribution, port scan signatures (sequential or randomised port access patterns), and retransmission counts.

The combination of both levels is required because flow-level features capture aggregate behaviour (a SYN flood) while packet-level features expose timing and sequencing patterns (a slow reconnaissance scan designed to evade flow-based thresholds).

2. World Model Architecture The core deliverable is a learned model of network state transition dynamics — not a static classifier. The model must:

- Represent network state as a structured feature vector or graph encoding active flows at time t.

- Learn P(S_t+1 | S_t) — the probability distribution over the next network state given the current state — using a sequence model such as an LSTM, Temporal Transformer, or Graph Neural Network (GNN) operating over time-windowed traffic observations.

- Be trained on labelled open-source datasets using supervised dynamics learning, where ground-truth state transitions are derived from the attack timeline annotations in the dataset.

- Generalise to unseen attack patterns — not merely memorize signatures from the training set.

3. Infiltration Prediction and Attack Stage Mapping The world model must support forward simulation: given current observed traffic, roll out K steps and output

- A time-series probability score: likelihood of infiltration in the next K time windows.

- Predicted attack stage: mapping to MITRE ATT&CK phases — Reconnaissance, Initial Access, Lateral Movement, Command & Control, or Exfiltration — based on the predicted future state.

- Driving features: which specific flags, ports, or flow patterns are contributing most to the infiltration prediction (via attention weights or SHAP values).

The approaches are provided only as examples and are not mandatory. Teams are free to propose alternative architectures that satisfy the objectives.

**Expected Solution:**

(Indicative)

**A software-based, fully open-source solution is expected. The solution may include:**

- A feature extraction pipeline that ingests CIC-IDS-2018 or CTU-13 CSV flow records and/or raw PCAP files (parsed using Scapy or PyShark) and outputs a timestamped, normalised feature matrix covering both flow-level and packet-level attributes described above.

- A trained world model (LSTM, Transformer, or GNN architecture) that demonstrably learns traffic state transition dynamics — not a static input-output classifier. Training scripts, model weights, and a reproducible training configuration must be included.

- An infiltration prediction engine that performs K-step forward simulation from a current traffic snapshot and outputs: infiltration probability score, predicted MITRE ATT&CK stage, and top contributing traffic features.

- An explainability output for each prediction — using SHAP values or model attention weights — identifying which flags, ports, or flow statistics are driving the prediction. Black-box outputs without interpretability are not acceptable.

- A working demonstration interface (Streamlit, Flask web app, or CLI) that accepts a PCAP or CSV file as input, runs the world model inference, and displays the infiltration probability timeline, flagged flows, and attack stage annotations. The interface must run fully offline without cloud API dependencies.

- Benchmark results comparing model performance (F1 score, precision, recall, false positive rate) against a logistic regression baseline trained on the same features, demonstrating that the world model's temporal dynamics learning provides measurable improvement.

**Expected Solution:**

/Deliverables for Evaluation

- Source Code Link (GitHub/Drive Link)

- Readme with Setup Instructions

- Architecture Document (Max 2 Pages)

- Demo Video (Max 2 Minutes)

- Technical Presentation (Max 5 Slides) .

#### Dataset & Reference Links

- Check nciipc.gov.in; helpdesk1@nciipc.gov.in

- Use publicly available datasets such as CIC-IDS2017/2018, UNSW-NB15, CTU-13, CICIoT2023, LANL Authentication Dataset, DARPA Intrusion Detection datasets, together with public knowledge bases such as MITRE ATT&CK, CAPEC, CVE/NVD and other open cybersecurity resources.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26154"></a>[154] SIH26154: Gen AI Platform for Automated Content Transformation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26154` (SIH26154) |
| **Problem Statement Title** | Gen AI Platform for Automated Content Transformation |
| **Organization** | National Technical Research Organisation (NTRO) |
| **Department** | National Technical Research Organisation (NTRO) |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Organisations frequently need to convert information available in different forms such as news articles, reports, advisories, threat intelligence, policy documents, research papers, announcements, incident reports or free-form prompts into specific communication artefacts suitable for various purposes. The process of manually analysing the source content, understanding the desired objective and creating the required output format is time-consuming, resource-intensive and often requires expertise in content creation, communication and domain knowledge.

There is a need for an intelligent platform that can transform user-provided content into a desired output format through a simple and configurable interface.

**Description:**

The system shall act as an AI-powered content transformation engine that converts a common source of information into the specific deliverable requested by the operator, thereby reducing manual effort, improving consistency, accelerating content creation and enhancing operational efficiency.

The platform shall provide a dashboard through which an operator can submit source content in the form of high quality English language text, documents, articles, reports, prompts, images, videos or contextual information. In addition to providing the source content, the operator shall select one or more desired output types through configurable parameters available on the dashboard.

Based on the submitted content and the selected output type(s), the platform shall analyze the input, understand the context and intent, and generate the requested output artefact. The platform should support multiple output formats and allow operators to control generation parameters such as target audience, tone, language, level of detail, communication objective and content style.

In summary, platform shall generate output corresponding to the option(s) selected by the operator on the dashboard.

- Examples include

- If 'Video' is selected, generate a complete video package including script, storyboard, scene descriptions, narration text, subtitles and visual recommendations.

- If 'LinkedIn Post' is selected, generate a professional LinkedIn post suitable for publication.

- If 'Twitter/X Post' is selected, generate platform-optimized tweets or tweet threads.

- If 'Advisory' is selected, generate a structured advisory document.

- If 'Infographic' is selected, generate infographic content, layout recommendations and key messaging.

- If 'Executive Summary' is selected, generate a concise executive briefing.

- If 'Presentation' is selected, generate presentation slides and speaker notes.

- If multiple output formats are selected, generate all selected deliverables from the same source content.

**Expected Solution:**

/Deliverables for Evaluation

- Source Code Link (GitHub/Drive Link)

- Readme with Setup Instructions

- Architecture Document (Max 2 Pages)

- Demo Video (Max 2 Minutes)

- Technical Presentation (Max 5 Slides)

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26155"></a>[155] SIH26155: AI-Driven Multi-Vendor Network Security Compliance Auditor

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26155` (SIH26155) |
| **Problem Statement Title** | AI-Driven Multi-Vendor Network Security Compliance Auditor |
| **Organization** | National Technical Research Organisation (NTRO) |
| **Department** | National Technical Research Organisation (NTRO) |
| **Category** | Software |
| **Theme** | Blockchain & Cybersecurity |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Modern enterprise networks are inherently heterogeneous, consisting of a vast array of hardware from diverse vendors. Organizations are mandated to align these devices with rigorous security frameworks, including CIS Benchmarks, NIST SP 800-53, DISA STIGs, and ISO/IEC 27001.

**The network environment includes, but is not limited to:**

- Firewalls & SASE: Palo Alto, Fortinet, Cisco (Firepower/Secure/Meraki), Check Point, Juniper (SRX), Sophos, SonicWall, WatchGuard, Barracuda, Zscaler, Cloud-native firewalls (AWS, Azure, GCP), Sangfor, Hillstone, A10, Forcepoint, Stormshield, Netgate (pf/TNSR), Cato Networks, and others.

- Routers & Switches: Cisco (Catalyst/Nexus), HPE Aruba, Juniper (EX/MX/PTX), Arista, Extreme, NVIDIA (Mellanox), Allied Telesis, Huawei, D-Link, MikroTik, Ubiquiti, Alcatel-Lucent, Ruijie, Adtran, and others.

- Specialized Networking: Open/Disaggregated (Dell, Nokia, 'White Box' hardware running SONiC, Cumulus), Hyperscale/AI (NVIDIA, Arista, Juniper), and Physical Infrastructure (Corning).

Note: The aforementioned list is illustrative; the application must be ideally designed to support any network device configuration, regardless of vendor or market segment.

**Description:**

- The Core Challenge:

In modern digital infrastructures, network devices act as the primary gatekeepers of data. However, they are also the most common point of misconfiguration, which accounts for a significant percentage of security breaches. Security frameworks like CIS, NIST, and STIGs offer specific 'hardening' protocols—such as disabling insecure protocols (Telnet/HTTP), enforcing strong cryptographic suites, configuring granular ACLs, and logging all administrative access. Currently, the industry relies on a bifurcated approach: either highly manual, checklist-based human auditing or expensive, vendor-locked enterprise management suites that lack flexibility for heterogeneous, multi-vendor environments.

- Operational Gap:

Administrators managing hybrid networks (composed of firewalls, switches, and routers from various vendors like Palo Alto, Cisco, Arista, etc.) lack a centralized 'Source of Truth' for compliance. The challenge is twofold:

1.Syntactic Diversity: Each vendor uses proprietary Command Line Interface (CLI) syntax, varied hierarchical structures, and distinct firmware/OS versioning. A 'secure password' setting in a Cisco IOS switch is syntactically distinct from the same setting in a Juniper SRX firewall.

2.Scalability & Adaptation: The network landscape is not static. As organizations adopt 'White Box' networking (SONiC), Cloud-native security groups (AWS/Azure), or specialized AI-driven infrastructure, traditional parsers fail because they cannot predict or interpret the configuration structures of newly acquired or proprietary hardware.

The requested solution is an AI-augmented, vendor-agnostic Compliance Engine. Rather than relying on a hard-coded library of commands—which becomes obsolete as vendors release firmware updates—the system will employ Ai based approaches ( for example (Pattern Recognition and Natural Language Processing (NLP)) to interpret configuration files.

**When a configuration file is ingested, the AI-based engine will:**

- Normalization: Extract the configuration and map it into a standardized, vendor-neutral schema (e.g., a 'Security Baseline Model').

- Deviation Analysis: Compare this normalized model against the chosen framework (e.g., checking if the parsed 'ssh_version' is '2' as required by CIS).

- Dynamic Adaptation (The 'Training' Loop): When the system encounters an unrecognized configuration structure, it will trigger an Interactive Training Interface. In this GUI, the administrator will be presented with the 'raw' unrecognized command lines. Using a user-friendly, low-code interface, the administrator will map these commands to specific security categories (e.g., 'This command sets the timeout limit'). The AI engine will then update its internal heuristics, effectively 'learning' to parse this new vendor's logic without requiring backend code redeployment.

**The proposed solution should be a user-friendly, robust software platform featuring:**

1. Unified Ingestion Engine: A dashboard for uploading single or bulk configuration files from any network device.

2. AI-Powered Training Module: A dedicated, intuitive GUI where administrators can 'train' the system to parse unseen vendor formats by mapping specific command outputs to compliance parameters.

3. Multi-Framework Compliance Engine: A logic engine that evaluates configurations against user-selected benchmarks (CIS, NIST, STIGs, ISO).

**4. Actionable Intelligence & PDF Reporting: A comprehensive, single PDF report for each device, covering:**

o Device Identification: Including serial numbers and hardware details.

o Compliance Findings: Clear 'Pass/Fail' results with risk severity assessments.

o Remediation Paths: Device-specific, step-by-step CLI command sequences to resolve non-compliance and harden the device.

5.Vendor-Agnostic Scalability: A modular architecture designed to support new vendors, standards, and OS versions without requiring manual code modifications for every update.

- Suggested Development Workflow The development can be visualized in the following stages:

1. Normalization: Converting proprietary CLI outputs into a structured JSON/Schema model.

2. Compliance Engine: Using Python libraries (e.g., Netmiko or NAPALM) for data collection and custom logic for mapping.

3. AI/ML Integration: Using Natural Language Processing (NLP) or pattern matching to identify keywords in configurations that the system has not been pre-trained on.

4. Reporting: Generating dynamic PDFs (e.g., using ReportLab or FPDF in Python) that are customized based on the device's specific model and software version.

**Expected Solution:**

/Deliverables for Evaluation

- Source Code Link (GitHub/Drive Link)

- Readme with Setup Instructions

- Architecture Document (Max 2 Pages)

- Demo Video (Max 2 Minutes)

- Technical Presentation (Max 5 Slides)

#### Dataset & Reference Links

- Check nciipc.gov.in , helpdesk1@nciipc.gov.in

- CIS Benchmarks, NIST SP 800-53, DISA STIGs, ISO/IEC 27001; Vendor-specific CLI configuration samples.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26156"></a>[156] SIH26156: Universal Log Pre-processing Framework

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26156` (SIH26156) |
| **Problem Statement Title** | Universal Log Pre-processing Framework |
| **Organization** | National Technical Research Organisation (NTRO) |
| **Department** | National Technical Research Organisation (NTRO) |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Modern enterprises generate massive volumes of logs from a wide range of sources, including network devices, servers, operating systems, applications, databases, cloud services, containers, endpoint security tools, identity and access management systems, IoT devices, and other hardware and software platforms. These logs are produced in diverse formats such as Syslog, JSON, XML, CSV, CEF, LEEF, proprietary vendor formats, and application-specific schemas.

The diversity of log structures creates significant challenges in centralized monitoring, security operations, compliance reporting, incident investigation, and threat analytics. Security teams often spend substantial effort developing source-specific parsers and normalization rules before the data can be effectively utilized by SIEM, data lake, or machine learning platforms.

As organizations adopt hybrid, multi-cloud, and AI-driven environments, the need for a universal and extensible log standard that can accommodate both current and future data sources have become increasingly critical.

- Detailed Description Design and develop a Universal Log Pre-processing Framework (ULPF) capable of ingesting, parsing, normalizing, and standardizing logs and events generated by any hardware or software system.

The framework should support diverse event sources while preserving the original event data for forensic and compliance purposes. It should transform heterogeneous logs into a unified schema that enables consistent analytics, correlation, visualization, threat hunting, anomaly detection, and machine learning applications.

The framework must be scalable, extensible, vendor-agnostic, and suitable for deployment in Big Data environments handling billions of events per day.

**Expected Solution:**

s This solution should cover universal event schema and processing framework that enables:

a) Preserve complete raw event data without information loss.

b) Extract and parse source-specific attributes.

c) Normalize fields into a common event taxonomy.

d) Maintain traceability between normalized and original events.

e) Plug-and-play on boarding of new log sources.

f) Unified visibility across enterprise environments.

g) Efficient SIEM and Data Lake integration.

h) AI/ML-ready security and operational analytics.

i) Reduced parser development effort.

j) The solution shall be deployable in an air-gapped network.

k) Solution may be packaged in a container for making it platform independent.

- Current Scope Build a framework that converts any perimeter network device-generated log or event—regardless of source, format, vendor, or technology into a standardized, lossless, analytics-ready representation for next-generation SIEM and cybersecurity platforms.

**Expected Solution:**

/Deliverables for Evaluation

- Source Code Link (GitHub/Drive Link)

- Readme with Setup Instructions

- Architecture Document (Max 2 Pages)

- Demo Video (Max 2 Minutes)

- Technical Presentation (Max 5 Slides)

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26157"></a>[157] SIH26157: Supervisory Analytics Tool for SOC Assessment (SAT-SA)

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26157` (SIH26157) |
| **Problem Statement Title** | Supervisory Analytics Tool for SOC Assessment (SAT-SA) |
| **Organization** | National Technical Research Organisation (NTRO) |
| **Department** | National Technical Research Organisation (NTRO) |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

The National Critical Information Infrastructure Protection Centre (NCIIPC) assesses the cyber resilience of Critical Sector Entities (CSEs).

As part of these assessments, NCIIPC performs manual reviews of samples of security alerts and case-management records generated by Security Operations Centres (SOCs). These reviews have consistently produced valuable supervisory findings that were not evident through policies, audits, self-assessments, management reports, KPI dashboards, or compliance documentation.

The purpose of these reviews is not to assess individual alerts. Rather, alert and case-management data are used as operational evidence to assess whether a CSE possesses effective capabilities relating to:

(i). Threat Detection (ii). Investigation (iii).Escalation (iv). Incident Response (v).Security Operations (vi).Governance and Oversight (vii).Operational Discipline (viii).Cyber Resilience While effective, manual review is resource-intensive and difficult to scale across a growing number of CSEs and increasing volumes of security data.

**Description:**

NCIIPC seeks a deployable Supervisory Analytics Tool for SOC Assessment (SAT-SA) that assists supervisors in analysing SOC alert and case-management data at scale.The tool should help supervisors:

(i). Identify entities requiring supervisory attention.

(ii).Prioritise alert samples and investigations for manual review.

(iii).Detect operational weaknesses and cyber resilience concerns.

(iv).Improve the efficiency, consistency and scalability of supervisory assessments.

The tool is intended to support human examiners and supervisory decision-making. It is not intended to replace supervisory judgement.

1. Out of Scope The proposed solution is not intended to:

(i). Function or replace as a Security Operations Centre (SOC) of CSEs.

(ii).Perform real-time monitoring.

(iii).Act as a SIEM platform.

(iv).Act as a centralized SOC for multiple entities.

(v).Continuously collect logs or telemetry from CSEs.

(vi).Serve as a national cyber monitoring platform.

The solution should be viewed as a supervisory analytics capability, not an operational security capability.

2. Data Environment Participants may assume access to periodic submissions including:

(i). Alert metadata (ii).Case management records (iii).Investigation workflow data (iv).Escalation records (v). Alert disposition and closure information (vi). Asset and system inventory information (where available)

Solutions should minimise dependence on raw logs, packet captures, customer information, or other sensitive operational data unless clearly justified.

3. Core Supervisory Problem Manual reviews often uncover weaknesses that are not visible through conventional reporting mechanisms.These weaknesses generally fall into two categories:

A. Execution Gaps Situations where documented controls, governance arrangements, policies, procedures, metrics or reported capabilities suggest effective operation, but operational evidence indicates otherwise.

- Examples:

(i).Alerts acknowledged but not meaningfully investigated.

(ii).Cases closed unusually quickly.

(iii).Critical alerts closed without escalation.

(iv).Repetitive or template-driven investigations.

(v).Controls deployed but not effectively monitored.

(vi).Operational behaviour designed to satisfy metrics without reducing risk.

B. Negative Space Situations where expected evidence is absent.

**Examples:**

(i).Missing telemetry from critical systems.

(ii).Absence of expected alert categories.

(iii).Missing investigations or escalation records.

(iv).Unexpectedly low activity levels.

(v).Monitoring blind spots.

(vi).Absence of evidence that would normally be expected within comparable environments.

The tool should help supervisors identify both known and previously unknown indicators of these conditions.

4. Functional Requirements Data Ingestion: The tool shall:

1. Ingest structured data from multiple CSEs.

2. Support common formats such as CSV, JSON, database exports and APIs where available.

3. Support analysis of large datasets spanning multiple entities and time periods.

**Supervisory Analytics: The tool shall:**

4. Identify indicators of detection, investigation and escalation weaknesses.

5. Detect potential execution gaps.

6. Detect potential negative space.

7. Identify anomalies, outliers and suspicious operational patterns.

8. Perform peer comparison and benchmarking across entities.

9. Generate entity-level supervisory risk indicators.

10. Prioritise entities, controls, processes and alert samples for manual review.

**Explainability: The tool shall:**

11. Provide clear rationale for findings.

12. Present supporting evidence.

13. Support traceability and auditability of results.

14. Allow supervisors to understand why an entity or activity was flagged.

- Reporting: The tool shall:

15. Generate supervisory dashboards and reports.

16. Support trend analysis across entities and time periods.

17. Enable drill-down from supervisory findings to underlying evidence.

- Illustrative Supervisory Use Cases The following examples are illustrative and not exhaustive.

**The tool may assist in identifying:**

(i). High-severity alerts closed unusually quickly.

(ii). Repeated alerts on the same asset without evidence of root-cause remediation.

(iii). Critical alerts closed without appropriate escalation.

(iv). Critical systems generating little or no security telemetry.

(v). Significant deviations from peer entities.

(vi).Missing monitoring coverage for critical environments.

(vii).Repetitive investigation patterns suggesting superficial review.

(viii).Operational behaviours that satisfy performance metrics without effectively managing cyber risk.

(ix).Investigation or escalation workloads inconsistent with expected activity levels.

Participants are encouraged to identify additional supervisory signals beyond these examples.

5.Deployment Requirements The solution shall operate within an NCIIPC-controlled environment.

**The solution must:**

(i).Operate in a fully offline (air-gapped) network.

(ii).Require no Internet connectivity.

(iii).Have no dependency on cloud services.

(iv).Have no dependency on SaaS platforms.

(v).Have no dependency on externally hosted AI models or APIs.

(vi).Support local deployment and local data processing.

**Where AI or machine learning is proposed, participants shall specify:**

(i).Model architecture.

(ii).Hardware requirements.

(iii).Offline training and inference approach.

(iv).Model update mechanism.

(v).Explainability controls.

(vi).Auditability controls.

6. Deliverables Participants should provide:

(i). Solution architecture.

(ii). Functional design.

(iii).Analytics methodology.

(iv).Data requirements.

(v).Tool or Prototype (vi).Infrastructure requirements.

(vii).Validation methodology.

(viii).Estimated deployment and operational requirements.

7. Performance Criteria Criterion Weight. Ability to Support Supervisory Assessment, Detection of Execution Gaps, Detection of Negative Space, Explainability and Auditability, Scalability and Performance, Innovation and Additional Supervisory Insights 8. Validation Requirement Participants shall explain how the proposed solution will be validated against findings derived from expert manual review.

Solutions should demonstrate their ability to identify supervisory signals, operational weaknesses and areas requiring attention with effectiveness comparable to or better than current manual sampling approaches.

9. Success Criterion A successful solution will enable NCIIPC to efficiently analyse large volumes of SOC alert and case-management data from multiple CSEs, identify entities and operational areas requiring supervisory attention, prioritise manual review effort, and preserve the quality of supervisory assurance currently obtained through expert human examination.

**Expected Solution:**

/Deliverables for Evaluation

- Source Code Link (GitHub/Drive Link)

- Readme with Setup Instructions

- Architecture Document (Max 2 Pages)

- Demo Video (Max 2 Minutes)

- Technical Presentation (Max 5 Slides)

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26158"></a>[158] SIH26158: Single-Pass Drone Video to Accurate 3D Model Generation System

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26158` (SIH26158) |
| **Problem Statement Title** | Single-Pass Drone Video to Accurate 3D Model Generation System |
| **Organization** | National Technical Research Organisation (NTRO) |
| **Department** | National Technical Research Organisation (NTRO) |
| **Category** | Software |
| **Theme** | Robotics and Drones |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Generation of accurate 3D models of buildings, infrastructure, terrain, and objects typically requires multiple drone passes, extensive image overlap, specialized flight planning, and significant post-processing time. In operational scenarios such as disaster response, surveillance, infrastructure inspection, military reconnaissance, and rapid mapping, there is often only a single opportunity to capture data over the target area. A solution capable of generating an accurate and textured 3D model from a single drone pass video would significantly reduce mission time, operator effort, data acquisition requirements, and processing complexity while enabling near real-time situational awareness.

**Description:**

Design and develop an AI-enabled system capable of generating a georeferenced and metrically accurate 3D model of a scene using only a single-pass drone video stream captured from a moving UAV. The system should process video frames captured during one flight path and reconstruct:

(i) 3D terrain and structures (ii) Building facades and rooftops (iii) Roads and infrastructure (iv) Vegetation and obstacles (v) Textured 3D meshes or point clouds

**Expected Solution:**

/Deliverables:

The generated model should be suitable for visualization, measurement, and analysis purposes.

- Key Challenges (i) Limited viewing angles due to single flight path.

(ii) Motion blur and video compression artifacts.

(iii) Variable illumination and shadows.

(iv) Dynamic objects (vehicles,humans, animals).

(v) GPS inaccuracies and sensor noise.

(vi) Real-time or near-real-time processing requirements.

(vii) Reconstruction of occluded surfaces.

(viii) Maintaining metric accuracy without extensive Ground Control Points (GCPs).

- Input Data :

- Mandatory (i) Drone video (1080p/4K)

(ii) GPS coordinates (iii) Flight metadata

- Optional (i) IMU data (ii) Barometric altitude (iii) Camera intrinsic parameters (iv) RTK/PPK corrections Add 'Desired Output' and 'Evaluation Criteria' table here

- Potential Applications :

(i) Border and strategic area mapping (ii) Disaster damage assessment (iii) Urban planning and smart cities (iv) Infrastructure inspection (v) Construction progress monitoring (vi) Archaeological documentation (vii) Digital twin generation (viii) Military reconnaissance and mission planning

#### Dataset & Reference Links

Will be provided real time.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26159"></a>[159] SIH26159: SecureMailScope: AI-Assisted Cryptographic Security Posture Assessment for Secure Email Communications

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26159` (SIH26159) |
| **Problem Statement Title** | SecureMailScope: AI-Assisted Cryptographic Security Posture Assessment for Secure Email Communications |
| **Organization** | National Technical Research Organisation (NTRO) |
| **Department** | National Technical Research Organisation (NTRO) |
| **Category** | Software |
| **Theme** | Blockchain & Cybersecurity |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Electronic mail remains one of the most critical communication services for governments, enterprises, financial institutions, and academic organizations. Despite the widespread adoption of Transport Layer Security (TLS), many SMTP, IMAP, and POP3 deployments continue to suffer from cryptographic misconfigurations such as obsolete TLS versions, weak cipher suites, insecure STARTTLS implementations, expired or improperly configured certificates, and non-compliance with modern security standards. These weaknesses expose email infrastructures to downgrade attacks, man-in-the-middle attacks, passive interception, and other cryptographic threats.

Although existing network analysis tools provide extensive packet-level visibility, they primarily focus on protocol decoding and traffic inspection. They do not automatically evaluate the overall cryptographic security posture of email communications or provide intelligent risk assessment and prioritization for security analysts.

**Description:**

Design and develop an AI-assisted passive network forensic framework capable of analyzing captured network traffic (PCAP files) containing SMTP, IMAP, and POP3 communications to automatically assess the cryptographic security posture of enterprise email infrastructures.

The proposed solution shall reconstruct complete email communication sessions, identify encryption transitions, analyze TLS negotiations, validate digital certificates, detect cryptographic weaknesses, and leverage Artificial Intelligence/Machine Learning techniques to classify security risks, detect anomalous TLS behavior, and generate actionable security recommendations.

The framework should assist Security Operations Centers (SOC), Digital Forensics teams, Incident Response teams, and enterprise administrators in rapidly identifying cryptographic vulnerabilities, prioritizing remediation efforts, and ensuring compliance with modern cryptographic best practices.

- Objectives- The proposed system should be capable of:

- Passive analysis of encrypted SMTP, IMAP, and POP3 traffic from PCAP files.

- Automatic identification of application-layer email protocols.

- Detection of STARTTLS negotiation and encrypted session upgrades.

- Reconstruction of complete TCP communication streams.

- Parsing and reconstruction of TLS handshakes.

- Extraction and validation of X.509 digital certificates.

- Identification of negotiated TLS versions, cipher suites, and key exchange mechanisms.

- Detection of deprecated protocols, weak cipher suites, insecure cryptographic algorithms, and certificate-related vulnerabilities.

- Extraction of cryptographic features for intelligent analysis.

- Application of AI/ML techniques for:

- Cryptographic risk classification.

- Detection of anomalous TLS behavior.

- Security posture scoring.

- Threat prioritization.

- Recommendation of mitigation measures.

- Generation of comprehensive forensic reports and security dashboards.

**Expected Solution/Deliverables:****The solution should provide the following outputs:**

- Automatic identification of SMTP, IMAP, and POP3 protocols.

- STARTTLS negotiation detection and validation.

- Complete TCP stream reconstruction.

- TLS handshake reconstruction.

- Detection of negotiated TLS versions.

- Identification of negotiated cipher suites.

- Identification of key exchange mechanisms.

- Extraction of X.509 certificates.

- Certificate chain validation.

- Certificate expiration analysis.

- Public key algorithm and key length analysis.

- Digital signature algorithm identification.

- Detection of weak cryptographic algorithms and deprecated TLS versions.

- Identification of insecure protocol configurations.

- Forward Secrecy assessment.

- AI-based cryptographic risk scoring.

- AI-assisted anomaly detection for suspicious TLS sessions.

- Prioritized security findings.

- Comprehensive cryptographic security posture assessment.

- Exportable forensic reports in JSON, PDF, and HTML formats.

- Interactive visualization dashboard for security monitoring and analysis.

#### Dataset & Reference Links

Synthetic - Participants May generate IMAPS, POP3S,SMTPS Data using any E-mail server /client of their interest and capture pcap dump

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26160"></a>[160] SIH26160: AI-Powered IPsec VPN Protocol Analyzer and Security Assessment Framework

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26160` (SIH26160) |
| **Problem Statement Title** | AI-Powered IPsec VPN Protocol Analyzer and Security Assessment Framework |
| **Organization** | National Technical Research Organisation (NTRO) |
| **Department** | National Technical Research Organisation (NTRO) |
| **Category** | Software |
| **Theme** | Blockchain & Cybersecurity |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Virtual Private Networks (VPNs) are fundamental to secure communication over untrusted networks. Among the available VPN technologies, IPsec is widely adopted across enterprise, government, military, and cloud infrastructures because of its ability to provide confidentiality, integrity and authentication.

However, the security of an IPsec deployment depends on multiple factors, including the chosen cryptographic algorithms, authentication mechanisms, key exchange protocols, and operational mode (Tunnel or Transport). Misconfigurations, outdated cipher suites, improper key management, or protocol implementation flaws can significantly weaken the overall security posture.

Traditional protocol analysis tools provide packet-level visibility but often require expert interpretation. There is a growing need for intelligent systems capable of automatically analyzing IPsec deployments, identifying protocol characteristics, assessing security risks, and generating actionable recommendations.

**Description:**

Design and develop an AI-driven protocol analysis platform capable of automatically analysing IPsec VPN deployments established under different security configurations. The platform should inspect captured traffic or live network streams, identify protocol characteristics, infer VPN operating modes, evaluate cryptographic configurations and generate an automated security assessment report.

The solution should assist analysts in understanding the security posture of IPsec deployments without requiring manual packet inspection. Participants are expected to develop an intelligent framework capable of performing the following tasks.

a) VPN Testbed Generation: Develop a laboratory environment capable of establishing IPsec VPNs using multiple configurations. The framework should support variations such as:

- Tunnel Mode

- Transport Mode

- AES-128

- AES-256

- AES-GCM

- AES-CBC + HMAC

- Different DH Groups

- Perfect Forward Secrecy enabled/disabled

- IPv4 and IPv6 communication

- Different types of traffic – VoIP, Whatsapp, E-mail, Web-browsing, ICMP, Video streaming etc.

b) Traffic Capture: Acquire network traces using tools such as Wireshark, TCP-dump, Custom packet capture utilities. Captured dataset should include

- IKE negotiation

- ESP packets

- AH packets (optional)

- Normal communication c) AI-Based Protocol Identification: Develop an AI engine capable of automatically identifying

- IPsec protocol

- IKE version

- Tunnel Mode

- Transport Mode

- Encryption algorithm

- Authentication algorithm

- Key exchange method

- Security Association characteristics

- Predict Type of traffic inside ESP-IPsec d) Security Assessment: The framework should automatically evaluate

- Cryptographic strength

- Configuration compliance

- Security Association parameters

- Key lifetime

- Replay protection

- Forward Secrecy configuration

- Cipher suite strength

- Metadata exposure e) The output should include a comprehensive security score, traffic analysis and metadata inference. Automatically generate

- Executive Report & Technical Report

- Risk Score

- Threat Matrix

- AI Confidence Score

**Expected Solution:**

/Deliverables:

- Working software prototype

- AI classification engine

- Interactive dashboard

- Security assessment report

- Demonstration video

- Technical documentation

- Dataset used for training/testing

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26161"></a>[161] SIH26161: Dam Break Inundation Modelling Using Hydrodynamic Modelling of any River

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26161` (SIH26161) |
| **Problem Statement Title** | Dam Break Inundation Modelling Using Hydrodynamic Modelling of any River |
| **Organization** | National Technical Research Organisation (NTRO) |
| **Department** | National Technical Research Organisation (NTRO) |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

In India, due to natural disaster various natural dam / lake formations were observed which can be a major reason of flash flood in the lower catchment, for example, natural lake formed over the Rishi Ganga river of Uttarakhand in Feb 2021, Wapriyang river in Nov 2021, Phuktal river near Sumdo, J&K in Mar 15, Kosi river in 2008 etc. Devastating flood happened in the Kashmir valley, Assam in 2014 and many other places over a period of time. Therefore, simulation modelling for flash flood and scenario generation is important from Humanitarian Assistance and Disaster Relief (HADR) point of view. Another important aspect is water release issues from the Dam of major rivers. In the crisis situation, if the dam brakes, how much water will flow into the river and what are the area it will inundated / impacted need to be estimated. In order to carry out this work simulation modelling needs to be done for the same. In other way if any dam break situation happened then what will be the impacted area. Development of a modelling framework is required which will carry out simulation modelling for the same.

**Description:**

The above problem statement envisages that a software tool need to be developed which should automatically carry out the simulation modelling for Dam break analysis and identify the inundated area due to flash flood in the lower catchment. The modelling framework should be developed using hydrological data, DEM and satellite imagery of any river. The software/ tools should be capable of carrying out the simulation modelling of water flow in case of dam break or water release through 'Smooth Particle Hydrodynamics' and 'Delf3D' model and compare the scenario.

**Expected Solution:**

/Deliverables The proposed study aims to illustrate the current problems regarding framework generation of Humanitarian Assistance and Disaster Relief using simulation modelling related to flood management as follows:

i. Creation of generalized modelling framework to predict / simulate dam break/ river blockage analysis providing the necessary inputs on the basis of sudden water surge as well as loss and damage analysis using 'Smooth Particle Hydrodynamics model and Delf3D model'.

ii. Building a customized tool/ framework so that it is possible to generate a flood inundation simulation scenario using different input datasets.

iii. Developing a Dashboard for providing modelling input and output visualization framework (GUI). The program should support the large volume of data. Output should be converted to .shp or .Kml file.

iv. Additionally, developing a framework for near real time flood analysis through Google Earth Engine with the help of open source data.

v. Simulation needs to be done by taking the any river and Dam data (open source) of India during the final demonstration of the software.

#### Dataset & Reference Links

Open source Remote Sensing data (Sentinel, Landsat or any open source satellite image) and ASTER/ STRM or any other DEM.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26162"></a>[162] SIH26162: AI-Based Detection and Classification of Industrial Fires and Persistent Thermal Sources Using NASA FIRMS, OSM & Satellite Data

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26162` (SIH26162) |
| **Problem Statement Title** | AI-Based Detection and Classification of Industrial Fires and Persistent Thermal Sources Using NASA FIRMS, OSM & Satellite Data |
| **Organization** | National Technical Research Organisation (NTRO) |
| **Department** | National Technical Research Organisation (NTRO) |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Industrial facilities generate thermal signatures that can be observed from space, but current satellite-based monitoring systems like NASA FIRMS cannot distinguish between different types of thermal anomalies. To address this, there is a challenge to develop an AI-enabled geospatial system that integrates thermal data, land-cover information, industrial databases, and satellite imagery to automatically identify, classify, and monitor industrial fires and persistent thermal sources.

**Description:**

Industrial facilities such as oil refineries, petrochemical complexes, thermal power plants, steel industries, mining areas, and LNG terminals generate thermal signatures that can be observed from space. In addition, accidental industrial fires, gas leaks, explosions, and abnormal thermal events pose significant risks to critical infrastructure, public safety, and the environment.

Current satellite-based fire monitoring systems such as NASA FIRMS provide thermal anomaly detections but do not distinguish between industrial fires, gas flares, agricultural burning, mining activity, and wildfires.

The challenge is to develop an AI-enabled geospatial system that can automatically identify, classify, and monitor industrial fires and persistent thermal sources by integrating thermal anomaly data, land-cover information, industrial infrastructure databases, and satellite imagery.

**Expected Solution:**

/Deliverables:

i. Classification and segregation of Industrial fires from forest fires and other natural fires.

ii. GIS based solution for data storage, visualization of the output as an overlay over maps

#### Dataset & Reference Links

firms.modap.eosdis.nasa.gov/map

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26163"></a>[163] SIH26163: Security Assessment of the World Monitor application

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26163` (SIH26163) |
| **Problem Statement Title** | Security Assessment of the World Monitor application |
| **Organization** | National Technical Research Organisation (NTRO) |
| **Department** | National Technical Research Organisation (NTRO) |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

The world Monitor application is a Web/ Mobile platform that provides users with real-time monitoring, analytics, and reporting features. The application handles user authentication, data visualization, API communication, and role-based access controls.

As a security analyst, the task is to evaluate the application's security posture and identify vulnerabilities that could compromise the confidentiality, integrity, or availability of the system.

**Description:**

Conduct an authorized security assessment of the World Monitor application to:

1. Identify security vulnerabilities in the application.

2. Assess the potential impact of each vulnerability.

3. Demonstrate proof-of-concept exploitation in a controlled environment.

4. Recommend remediation measures to mitigate the identified risks.

- Scope The assessment should focus on:

- Authentication and session management

- Authorization and access control

- Input validation and data handling

- API security

- Client-side security controls

- Secure communication mechanisms

- Data storage and privacy protections

- Success Criteria The assessment is considered successful if:

- At least one valid vulnerability is identified and documented.

- Evidence supports the existence of the vulnerability.

- Risk and impact are clearly explained.

- Practical mitigation strategies are provided

**Expected Solution:**

/Deliverables:

**For each vulnerability discovered, provide:**

- Vulnerability title

**Description:**

- Affected component

- Severity rating (e.g., CVSS)

- Steps to reproduce

- Proof of concept demonstrating the issue in a safe testing environment

- Business impact assessment

- Remediation recommendations constraints

- Testing must be performed only on authorized systems.

- No actions should affect production users or data.

- Exploitation should be limited to proof-of-concept validation.

- Compliance with applicable laws, policies, and ethical hacking guidelines is required.

#### Dataset & Reference Links

App link- https://www.worldmonitor.app Source Code: https://github.com/koala73/worldmonitor

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26164"></a>[164] SIH26164: Enterprise Cryptographic Discovery & Analysis Tool (ECDAT)

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26164` (SIH26164) |
| **Problem Statement Title** | Enterprise Cryptographic Discovery & Analysis Tool (ECDAT) |
| **Organization** | National Technical Research Organisation (NTRO) |
| **Department** | National Technical Research Organisation (NTRO) |
| **Category** | Software |
| **Theme** | Blockchain & Cybersecurity |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Transitioning to Post Quantum Cryptography based solutions requires preparedness, risk assessment and financial and operational investment. Towards this, discovery and inventory of Cryptographic Artefacts is the critical first step, that will enable the transition.

**Description:**

i. Identify and catalogue all cryptographic artefacts (algorithms, keys, certificates, protocols, libraries, hardware modules, cloud services) across internal and external facing applications, products and infrastructure.

ii. The tool should perform a comprehensive quantum risk assessment and identify systems prone to potential quantum attacks, and highlight risks to sensitive data.

iii. Classify all the artefacts by type, lifetime and business criticality. Apply structured frameworks such as Mosca's algorithm (compare data lifetime plus migration time against expected arrival of cryptographic relevant quantum computer) to identify and categorize risks.

iv. Recommend suitable alternatives (PQC/ Hybrid algorithms) for applications based on risk profile, latency, cost, etc.

**Expected Solution:**

/Deliverables:

A Comprehensive CBOM analytics tool that can scan Source code repositories, binaries, libraries and container images, for assessing risks (due to quantum computers), classifying artefacts and suggesting alternatives: - Produce a report displaying all cryptographic assets including versions/ modes in standardised formats Interactive GUI platform to visualise the scan, risks and results

#### Dataset & Reference Links

Standard Open source datasets for source code repositories (eg:Github), libraries (eg: Openssl) may be used.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26165"></a>[165] SIH26165: AI/NLP Engine to Detect Serious Injury & Fatality (SIF) Precursors in OIL's Unsafe-Act/Unsafe-Condition and Near-Miss Reports

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26165` (SIH26165) |
| **Problem Statement Title** | AI/NLP Engine to Detect Serious Injury & Fatality (SIF) Precursors in OIL's Unsafe-Act/Unsafe-Condition and Near-Miss Reports |
| **Organization** | Oil India Limited |
| **Department** | Oil India Limited |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

OIL collects large volumes of UA/UC observations, near-miss and incident reports through its HSSE platform but these are triaged manually after certain time intervals such as monthly, quarterly etc.However, Global best practice (DEKRA Martin & Black 2015; EEI SIF Precursor model; VelocityEHS 2024 PSIF classifier) has established that low-severity incidents do not share the same causes as fatalities — non-fatal US accidents fell 51% over 15 years while fatalities fell only 25.5%.Leading operators therefore separately flag the ~20–25% of reports carrying genuine fatal potential.

Problem Description Build a prototype that ingests OIL's free-text safety reports and automatically a) Classifies each as SIF-potential vs non-SIF-potential b) Tags it to the relevant IOGP Life-Saving Rule (e.g., Energy Isolation, Hot Work,Confined Space, Line of Fire)

c) Surfaces recurring precursor patterns (activity, location, barrier failure) via a dashboard.

Expected Outcome/Solution A working AI/NLP with an interactive dashboard that ranks sites/activities by SIF-precursor density and auto-maps to Life-Saving Rules, enabling HSE to focus interventions where fatal potential is highest.

Relevant Data Availability (if any)

OIL's UA/UC observations, near-miss and incident reports.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26166"></a>[166] SIH26166: Multi-modal, Sun angle and scale invariant image correspondence using Chandrayaan-2 optical images (OHRC, TMC and IIRS)

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26166` (SIH26166) |
| **Problem Statement Title** | Multi-modal, Sun angle and scale invariant image correspondence using Chandrayaan-2 optical images (OHRC, TMC and IIRS) |
| **Organization** | Indian Space Research Organisation(ISRO) |
| **Department** | Department of Space / Indian Space Research Organisation |
| **Category** | Software |
| **Theme** | Space Technology |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background Image Registration is the process of aligning two or more images of the same scene taken at different times, from different viewpoints, or by different sensors into a common coordinate system.

**It has two main components:**

- Source Image (Moving): The image that is to be geometrically transformed to align with the reference image.

- Reference Image (Fixed): The target image about which source image is to be geometrically transformed.

Description The process of lunar images registration involves finding match points between source and reference image and then aligning the source image with the reference image. The key challenges involved in this process are as follows:

- Illumination variation: Illumination variation refers to changes in sun azimuth and elevation effect on the surface lighting conditions that affect the appearance of the lunar surface features which is hard to correlate.

- Viewpoint variation: It refers to geometric distortions caused by different camera positions/orientations capturing the same scene. Objects appear shifted, scaled, rotated, or perspective-distorted depending on observing angle.

- Scale Variation: Lunar imaging missions operate at vastly different altitudes and at different spatial resolutions. This creates scale ratios.

Expected Solution Generic software solution for finding correspondence between Chandrayaan-2 acquired optical images and Lunar reference images with a sub-pixel accuracy of source image maintaining uniform distribution across the images.

- Software and registered product with corresponding match points.

- Evaluation metric (eg. RMSE, inlier match count, inlier ratio, etc.)

#### Dataset & Reference Links

Specific datasets link will be provided - TBD

- Chandrayaan-2 orbiter optical payload: OHRC, TMC-2, IIRS lunar images. (Link: https://chmapbrowse.issdc.gov.in/)

- Reference: LRO NAC Images (Lunar Reconnaissance Orbiter Narrow Angle Camera) (Link: https://lroc.im.-ldi.com/images/downloads/ , https://quickmap.lroc.im-ldi.com/ ), SE

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26167"></a>[167] SIH26167: SatQuery AI - An Interactive Vision-Language Assistant for Multimodal Remote Sensing Image Analysis through Text Queries

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26167` (SIH26167) |
| **Problem Statement Title** | SatQuery AI - An Interactive Vision-Language Assistant for Multimodal Remote Sensing Image Analysis through Text Queries |
| **Organization** | Indian Space Research Organisation(ISRO) |
| **Department** | Department of Space / Indian Space Research Organisation |
| **Category** | Software |
| **Theme** | Space Technology |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background Remote-sensing imagery is widely used for agricultural monitoring, disaster management, urban planning, forest monitoring, water-resource assessment, infrastructure mapping, and environmental analysis. However, most existing remote-sensing AI solutions are developed as isolated applications for a single predefined task, such as land-cover classification, object detection, visual question answering, or change detection. These systems often require users to understand satellite-data characteristics, GIS workflows, model selection, and task-specific parameters. Consequently, non-expert users may find it difficult to obtain meaningful information from satellite imagery through simple natural-language queries.

Many operational remote-sensing questions cannot always be answered reliably using a single optical image. Relevant information may be distributed across paired or multiple observations acquired at different times or by different sensors. Optical and multispectral imagery provides spectral and contextual information, whereas synthetic aperture radar (SAR) provides complementary structural information and supports day-and-night acquisition through cloud cover. Multitemporal image pairs are required to identify and interpret changes over time, while co-registered optical–SAR pairs can provide more complete and reliable information than either modality alone.

A general-purpose large language model (LLM) or vision-language model (VLM) cannot be expected to perform these specialised tasks reliably without adaptation to remote-sensing imagery, sensor characteristics, and domain-specific terminology. The proposed solution must therefore include remote-sensing fine-tuning or domain adaptation and may employ multiple specialised models for different tasks. BigEarthNet.txt will serve as the primary dataset for adapting image–text representations to multisensor remote-sensing data. VRSBench and RSVQA will be used to evaluate single-image captioning, grounding, and visual question answering, while CDVQA will be used to evaluate multitemporal change-based visual question answering.

The novelty of SatQuery AI lies in its agentic, query-driven framework. Instead of applying a single generic VLM, the system selects and executes suitable remote-sensing specialist models, validates inputs, combines their outputs, and returns an evidence-grounded response.

Description The objective is to develop SatQuery AI, a software-based agentic vision-language assistant for analysing single and paired remote-sensing images through natural-language queries. Single-image understanding is a mandatory baseline, while the principal focus is joint reasoning over paired cross-modal and multitemporal imagery.

Defined Input Scope

- Single image: One optical/multispectral or SAR image for captioning, visual question answering, and text-guided region grounding.

- Cross-modal pair: Co-registered optical/multispectral and SAR images of the same geographic area for joint information extraction and cross-modal analysis.

- Bi-temporal pair: Two spatially corresponding images of the same geographic area acquired at different times for change detection, change description, and change-based visual question answering.

- Supported formats: GeoTIFF or TIFF for geospatial imagery. PNG and JPEG inputs may be accepted only for the prescribed public benchmark datasets.

Mandatory Functional Scope

- Remote-sensing adaptation: At least one visual or vision-language component must be fine-tuned or otherwise adapted using BigEarthNet.txt or the any open source training data.

- Single-image baseline: Visual question answering shall be mandatory. Each solution must additionally implement either captioning/scene description or text-guided region grounding.

- Multi-image change analysis: Change description or change-based visual question answering from a bi-temporal image pair shall be mandatory. A spatial change map may also be generated where reference masks are available.

- Cross-modal pair analysis: The system must extract complementary information from a co-registered optical/multispectral and SAR image pair.

- Agentic orchestration: The system must automatically select, sequence, and execute the appropriate specialist models or tools according to the query and input configuration.

Representative Queries

- 'Describe the land-cover and major objects visible in this image.'

- 'Highlight the water body referred to in the query.'

- 'What changed between these two dates, and where did the change occur?'

- 'Use the optical and SAR images together to identify built-up and water-covered regions.'

- 'Has the built-up area increased, decreased, or remained unchanged?'

Agentic Model and Tool Orchestration The system may use multiple specialised components, such as a remote-sensing VQA or captioning model, a grounding model, a change-understanding or change-VQA model, and an optical–SAR fusion or information-extraction model.

- interpret the query and classify the requested task;

- check the number, modality, format, metadata, and compatibility of the input images;

- select one or more models or tools from a predefined registry;

- configure only permitted task parameters and execute the selected workflow;

- combine textual and spatial outputs, estimate confidence, and return visual evidence; and

- provide an auditable execution summary containing the selected task, model/tool names, and key parameters.

The controller may perform internal task planning; however, only the observable execution trace, including the selected task, models or tools, permitted parameters, and outputs will be evaluated. Internal reasoning text is neither required nor evaluated.

Expected Solution The expected solution is an interactive GUI or web application with an agentic remote-sensing AI backend. It should accept supported image inputs and natural-language queries, select the appropriate specialist workflow, and return evidence-grounded textual and visual results.

**The solution should include:**

- Input upload and compatibility checking.

- A remote-sensing-adapted vision-language component.

- Specialist tools for VQA, captioning or grounding, change understanding, and optical–SAR analysis.

- An agentic controller for task routing, tool execution, and output integration.

- Visual evidence, confidence information, execution summaries, and downloadable reports.

Each solution must demonstrate single-image VQA, one additional single-image task, multitemporal change understanding, optical–SAR paired-image analysis, and agentic model/tool orchestration. A generic LLM or VLM without remote-sensing adaptation will not satisfy the requirements.

Deliverables An interactive GUI or web application with an agentic remote-sensing AI backend, Codes and models including test and demonstration.

Implementation Scope The system shall support single optical/multispectral or SAR images, co-registered optical–SAR pairs, and bi-temporal pairs in GeoTIFF/TIFF or approved benchmark formats. It must perform single-image VQA, one additional single-image task, change analysis, optical–SAR joint analysis, and agentic model/tool selection through an interactive GUI or web application.

Evaluation/Judging Criteria Final evaluation will use prescribed public benchmark test subsets and an ISRO/SAC evaluation dataset. Scores will be normalised before combining different metrics.

Add 'Evaluation/Judging Criteria' table here Public benchmarks will be evaluated using the prescribed test splits. The ISRO/SAC evaluation set will contain pre-georeferenced and co-registered Cartosat-2S optical and RISAT SAR image pairs, with task-specific reference answers, labels, bounding boxes, or masks, as applicable. Evaluation annotations will not be disclosed to participating teams.

#### Dataset & Reference Links

Training / Fine-Tuning Dataset BigEarthNet.txt — primary dataset for remote-sensing adaptation using co-registered Sentinel-1 SAR, Sentinel-2 multispectral imagery, and diverse text annotations. Link: https://arxiv.org/abs/2603.29630. All datasets are available online open source.

Public Evaluation Benchmarks

- VRSBench — for r

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26168"></a>[168] SIH26168: AI-ML based Intelligent Dead Reckoning system for seamless navigation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26168` (SIH26168) |
| **Problem Statement Title** | AI-ML based Intelligent Dead Reckoning system for seamless navigation |
| **Organization** | Indian Space Research Organisation(ISRO) |
| **Department** | Department of Space / Indian Space Research Organisation |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background Vehicle logistics, ride-hailing services, quick commerce and emergency responders heavily rely on smartphone-based navigation apps (like Google Maps or MapmyIndia) powered by GNSS (GPS/Galileo/NavIC etc). However, when a vehicle enters a long underground tunnel/ underpass, a multi-level parking lot, a dense forested highway, or a deep urban canyon surrounded by skyscrapers, GNSS connectivity drops entirely. GNSS signals are inherently weak and vulnerable to structural blockage (urban canyons, dense foliage, tunnels, deep valleys) and unintentional electromagnetic interferences from variety of sources such as jamming. This causes navigation apps to freeze, jump erratically, or miscalculate upcoming turns, leading to missed exits, delivery delays, and safety hazards.

In these environments, systems must rely on self-contained Inertial Navigation Systems (INS) built from Inertial Measurement Units (IMUs) (accelerometers and gyroscopes) to calculate position via dead reckoning during GNSS outage and switch back to GNSS aided INS after blackout. While INS is immune to external jamming, low-cost tactical or MEMS-grade IMUs suffer from inherent sensor biases, deterministic errors, and thermo-mechanical noise. While modern high-end cars possess factory-fitted, wheel-connected Inertial Navigation Systems (INS), the vast majority of vehicles on Indian roads—including commercial trucks, older cars, and millions of two-wheelers (motorcycles/scooters)—rely solely on the driver's smartphone mounted on the dashboard or placed in mobile holder.

Using a smartphone's internal MEMS IMU (accelerometer and gyroscope) to track vehicle position via dead reckoning during a GNSS blackout is highly challenging. The smartphone is subjected to severe chassis vibrations, engine harmonics, sudden braking, and road potholes. Without an external speedometer feed from the vehicle's OBD-II port, calculating distance and velocity exclusively from consumer-grade smartphone sensors results in exponential error accumulation, causing the estimated location to drift away within seconds. To overcome these challenges, there is a need for AI-ML enhanced dead reckoning and sensor fusion(GNSS+INS) techniques that integrate AI and machine learning models with real-time correction strategies.

Description The goal is to develop a lightweight, edge-deployable software engine and mobile application that transforms a standalone smartphone into an Intelligent Dead Reckoning (IDR) system with GNSS Fusion. When a GNSS outage occurs, the application must instantly transition to inertial tracking(INS), maintaining lane-level accuracy without requiring any physical connection to the vehicle's internal computer and seamlessly switch back to GNSS aided INS solution.

To bypass the need for an external speedometer, the solution must employ AI/ML models trained on vehicle kinematics to accurately predict vehicle speed and acceleration profiles solely from the smartphone's noisy accelerometer/gyro inputs. It must dynamically detect and filter out non-navigation motions such as engine idling vibrations, pothole shocks, bumps, and accidental phone misalignments on the mount.

Furthermore, the navigation engine should implement a smart Map-Matching Filter. By overlaying the inertial trajectory onto an offline map database (e.g., Open Street Map), the system should use the road layout as a constraint. For instance, it can apply Non-Holonomic Constraints (NHC), assuming a car cannot slide sideways or fly upwards, to dramatically snap the drifting IMU path back onto the actual road grid.

Also, the GNSS+INS fusion Algorithm should employ AI/ML techniques to develop an AI based fusion model to mitigate drift errors and provide accurate position.

The Final solution and AI/ML models developed should not be constricted to smart phone IMU sensors data alone (Mobile application). These algorithms/models should also work with any other external IMU sensors data (Edge deployable software engine).

Dataset Details: IO-VNBD: Inertial and Odometry benchmark dataset for ground vehicle positioning.

This dataset should be used to train & test the models and submit for screening of proposals. Teams are required to include the preliminary AI models and the results of the position plot inferenced from the subset of IO-VNBD dataset as part of their proposals submitted for evaluation. During the screening process more datasets will be provided for further evaluation of the AI models.

The On-Device Workflow Dead reckoning and GNSS fusion algorithms are hybrid. Complex training happens in the cloud/desktop apriori, while inference happens on the smartphone.

1. Model Training (Cloud/Desktop): Teams should train AI-ML models using IMU sensors datasets collected using a smartphone mounted on their vehicles or datasets available in open-source domain (for eg. 'IO-VNBD dataset') and bring trained models with them for SIH finale. Teams can bring the downloaded map database (e.g., Open Street Map).

2. On-Device Execution (Smartphone): During SIH Finale, the trained, lightweight model will need to be exported to the smartphone. It should receive live inputs from the phone's built-in Inertial Measurement Unit (IMU)—the accelerometer, gyroscope, and magnetometer/compass and GNSS data if available. The AI-ML based algorithms should remove IMU sensors noise & bias, predict corrections, perform map matching and determine continuous position using AI-ML based algorithms for both dead reckoning and GNSS+INS Fusion. For complete details regarding final solution, refer to the expected solution section.

Expected Solution The final deliverable must be a working mobile application and an Edge deployable software engine exhibiting the following technical capabilities:

- In-Vehicle Alignment & Calibration Engine: An algorithmic module that automatically determines the phone's pitch, roll, and yaw relative to the vehicle's driving direction, whether the phone is strictly dashboard-mounted or placed in mobile holder.

- AI Speed & Vibration Filter: A deep-learning or statistical signal-processing model running locally on the phone that filters out high-frequency road noise/potholes and directly estimates vehicle forward velocity from IMU signals.

- Advanced Map-Matching & Kinematic Constraints: A framework (e.g., AI-ML framework or Unscented Kalman Filter + Hidden Markov Map Matching) that binds the calculated position to known road networks and geometric paths during a dropout.

- GNSS+INS Fusion Engine: An innovative AI based Sensor Fusion Algorithm that combines GNSS & IMU measurements and provides significant improvement in overall output by eliminating drift errors and providing accurate position and velocity.

- Seamless GNSS Deficit Handler: An instant seamless transition mechanism between GNSS aided INS and Dead reckoning modes within milliseconds of GNSS signal blackout and vice-versa.

- Real-time Navigation Interface: A functional mobile application with UI displaying a smooth, uninterrupted vehicle icon showing seamless navigation.

**Performance Benchmark:**

Dead Reckoning: The solution must restrict positional drift to less than 10% of the total distance travelled using smartphone IMUs sensors during GNSS signals blackout (for e.g., in case of smartphones IMU, a drift of less than 5 meters is desired over 50m GNSS denied environment in <1 minutes OR less than 100m of drift over a 1km GNSS denied environment at a speed of 60kmph in tunnels/underground metro OR similar simulated environments where GNSS signals are unavailable).

GNSS+INS Fusion: Position update rate of 10Hz with processing on smartphones (Mobile application) and higher update rates on Edge deployable software engine using FOG based IMU sensors data (around 200Hz).

#### Dataset & Reference Links

IO-VNBD: Inertial and Odometry benchmark dataset for ground vehicle positioning (https://github.com/onyekpeu/IO-VNBD)

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26169"></a>[169] SIH26169: Development of an AI-Based Virtual Camera Tracking System for Coarse Alignment of Mobile Free Space Optical Communication (FSOC) Terminals

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26169` (SIH26169) |
| **Problem Statement Title** | Development of an AI-Based Virtual Camera Tracking System for Coarse Alignment of Mobile Free Space Optical Communication (FSOC) Terminals |
| **Organization** | Indian Space Research Organisation(ISRO) |
| **Department** | Department of Space / Indian Space Research Organisation |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background Free Space Optical Communication (FSOC) offers unprecedented advantages for next-generation mobile networks, including gigabit-to-terabit data rates, license-free spectrum operation, high immunity to electromagnetic interference, etc. However, deploying FSOC links between mobile platforms (satellites, UAVs presents a severe challenge of pointing, acquisition and tracking (PAT) of highly narrow laser beams. PAT typically happens in two stages: coarse alignment and fine alignment. Coarse alignment is one of the key challenges of PAT, where the transmitting terminal must first locate and maintain the remote terminal within its camera Field-of-View (FOV).

Developing and testing such algorithms on real hardware requires expensive cameras, pan-tilt mechanisms, and optical components & equipment. A software based virtual camera tracking provides an inexpensive and accessible platform for algorithm development and learning.

Description Unlike conventional radio-frequency systems, FSOC relies on a highly directional optical beam. Even a small angular error can prevent successful communication. Before fine pointing mechanism can take over, a coarse alignment stage must:

- Observe the surrounding environment,

- Acquire and detect the remote terminal or beacon,

- Estimate the position, and

- Continuously adjust the pointing direction to maintain visibility.

The participants shall develop this coarse alignment process in software, allowing to develop and validate tracking algorithms without specialized hardware and setup. The following section provides reference parameters and performance criteria to be considered for the software development.

Parameters and Specifications Functional Objective: Develop a software system that autonomously detects, identifies, and continuously tracks a designated moving target within a virtual scene by controlling a virtual camera viewport.

Add 'Parameters and Specifications' table here Expected Solution Participants shall develop an AI-assisted camera tracking system capable of automatically detecting and continuously tracking a moving optical beacon in a simulated video stream while controlling a virtual pan-tilt camera.

**The developed software shall be able to:**

- Generate a configurable virtual environment,

- Generate one or more moving targets,

- Implement a movable virtual camera,

- Detect the target beacon automatically,

- Track the beacon continuously using computer vision,

- Control and reposition the virtual camera,

- Generate and introduce disturbances due to atmospheric turbulence, platform vibrations, camera motion, noise, etc., in the virtual camera feed,

- Display tracking performance and statistics in real-time Deliverables Each participating team shall submit the following mandatory deliverables:

Software Application A standalone executable application implementing the complete virtual camera tracking system. The application shall provide all the mandatory functions and features as described above.

Source Code Complete source code with proper documentation. The code shall be modular and adequately commented.

Technical Report The technical report (about 10-15 pages) containing problem understanding, system architecture, description of software modules, tracking methods, AI methods (if used), test methodology, performance analysis and future improvements shall be submitted.

User Manual The user manual with the description of installation of software, application operation, parameter configuration, GUI description, etc. shall be submitted. A 3–5 minutes video may also be provided as an optional deliverable for demonstration of the application.

Performance Log The software should be capable of automatically generating a performance report containing simulation duration, FPS, acquisition time, average and maximum tracking error, lock retention rate, processing time, etc.

Evaluation Method and Criteria The solutions developed by participating teams will be evaluated using multi-layered evaluation method. The following table describes stages of evaluation, their weightage and methods.

Add 'Evaluation Method and Criteria' table here

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26170"></a>[170] SIH26170: AI-Driven Anomaly Detection in Component Burn-In & Screening

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26170` (SIH26170) |
| **Problem Statement Title** | AI-Driven Anomaly Detection in Component Burn-In & Screening |
| **Organization** | Indian Space Research Organisation(ISRO) |
| **Department** | Department of Space / Indian Space Research Organisation |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background In high-reliability sectors (like space) electronic components undergo rigorous environmental stress screening (ESS), including Burn-In testing (operating components at elevated temperatures, e.g., 125°C for extended periods).

Traditional screening relies on static parametric pass/fail limits. However, 'latent defects'—components that pass the absolute limits but exhibit subtle, anomalous drift over time—often escape into final payloads, leading to catastrophic field failures.

Description Development of a predictive machine learning model that analyzes time-series parametric data (e.g., standby current Iddq, leakage currents, or propagation delays measured at intervals like 0h, 24h, 96h, and 168h to detect anomalous components.

Expected Solution Module A: The outlier detection system Static limits catch obvious failures. Participants need to develop a 'Dynamic' outlier detection system. If a lot has an average leakage current of 10µA, a part showing 45 µA is a massive anomaly, even if the absolute datasheet maximum limit is 50 µA.

Module B: Time-Series Drift Predictor Build a predictive regression model that takes Value_0h and Value_24h as inputs and forecasts Value_168h. If the predicted 168h drift rate exceeds a calculated safety slope, the system flags the component for early rejection.

**Evaluation Metrics:**

- Anomaly Detection Score: a False Negative (missing a defective part) is catastrophic, penalizing teams that let bad parts escape.

- Drift Prediction Accuracy : The mean absolute error between the predicted Value_168h and the actual hidden ground-truth values.

- Explainability : Can the model justify its classification to a QA inspector, or is it a complete black box?

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26171"></a>[171] SIH26171: On-device Visual Perception for Light-weight Browser Agents

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26171` (SIH26171) |
| **Problem Statement Title** | On-device Visual Perception for Light-weight Browser Agents |
| **Organization** | Indian Space Research Organisation(ISRO) |
| **Department** | Department of Space / Indian Space Research Organisation |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background AI agents are becoming omnipresent in the current era and can play an important role in our digital interactions. If an agentic AI pipeline has access to our visual context, screen states, they can assist users in complex workflows and automate many tasks. Most of the agentic AI pipelines are deployed on server side which limits the type to data that a user can share with it. It would open a new dimension of possibilities, if a local agent is deployed on user machine particularly browser which can eliminate the need to share the sensitive data with the server. Local system generally has fewer resources than server and is unable to host a full-fledged pipeline therefore only the non-sensitive data such as structure of the screen, application fields etc can be sent to server for processing.

Modern browser APIs (such as WebGPU and WebAssembly) and local inference libraries (like ONNX Runtime Web and Transformers.js) have unlocked the ability to run lightweight machine learning models directly on the client. The aim is to bridge these two environments: leveraging the reasoning power of cloud or server based AI while strictly enforcing data privacy at the client side.

Description Participants are required to build a privacy-preserving vision agent which runs on browser. This involves implementing a client-side architecture where a local Vision Transformer (ViT) or equivalent computer vision model 'reads' the user's screen and takes decision based on that. If it requires the visual context to be sent to server, it shall sanitize the sensitive/PII data using DOM tags or any other method, before any network request is made. It should dynamically detect and redact sensitive elements. For example, blurring faces, blacking out passwords, and masking PII etc. Only this anonymized, unidentifiable data should be transmitted to the central server which should be aware for this redaction scheme and can process data accordingly. The server will then process the sanitized context and return actionable commands for the browser agent to execute. Participants must balance the trade-offs between inference latency and the accuracy.

Expected Solution A successful submission should include a working prototype consisting of client side extension and server that demonstrates the following:

**Client-side (extension/JS) running in popular browsers (chrome, Firefox) components:**

- Local Vision Processing: Implementation of a client-side vision model running in the browser (e.g., via WebGPU) that evaluates the current screen state.

- Privacy Preserving Filter: A mechanism for sanitizing sensitive or personal visual data. This can be achieved through local bounding-box redaction, semantic obfuscation, masking etc. This should be clearly demonstrated.

**Server-side implementation components:**

- Server Side Integration: The transmission of the anonymized visual context to a centralized LLM/VLM, which successfully interprets the sanitized data and returns the response which may be processed data to be again ingested by local client or an UI action (e.g., 'click the submit button,' 'scroll down') that the local client executes.

- Participants are free to use any offline deployable (open-source/open-weights) model on server side. During SIH they can use cloud hosted version of these. An end-to-end task assisting the user should be demonstrated.

**Evaluation will be done on the following metrics:**

1-Accuracy of visual context from screen – 25% 2-Recall and precision for detection of sensitive/PII data – 20% 3-Precision of redaction – 20% 4-Client side resource utilization – 20% 5-Overall end-to-end latency of the provided task -15%

#### Dataset & Reference Links

Any open-source data can be used. Use cases for evaluation will provided during finale

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26172"></a>[172] SIH26172: Low Latency and Efficient Voice Activator for Edge Devices

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26172` (SIH26172) |
| **Problem Statement Title** | Low Latency and Efficient Voice Activator for Edge Devices |
| **Organization** | Indian Space Research Organisation(ISRO) |
| **Department** | Department of Space / Indian Space Research Organisation |
| **Category** | Hardware |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background As voice-controlled IoT proliferate, processing everything in the cloud is too costly, privacy-invasive, and slow. The future belongs to hybrid architectures where the edge handles the initial 'wake-up' and the cloud handles the heavy lifting.

Description Build an ultra-lightweight, highly accurate keyword spotting (KWS) model that runs locally on a low-power device. Upon detecting the keyword, the system must instantly and efficiently stream the subsequent audio to a remote Automated Speech Recognition (ASR) server with minimal data overhead and latency.

Key Metrics for Evaluation

- Efficiency: Model size (RAM/Flash footprint) and CPU usage during idle listening.

- Accuracy: High true-positive rate for the keyword with near-zero false activations.

- Latency: The time delta between the keyword ending and the cloud ASR receiving the audio stream.

Software & Framework Restrictions

- Open-Source Only: The use of proprietary, closed-source, or commercial voice-activation SDKs is strictly prohibited.

- Allowed Frameworks: Teams must build their keyword spotting (KWS) pipelines using open-source machine learning and TinyML frameworks. Recommended tools include TensorFlow Lite for Microcontrollers, PyTorch Mobile or similar.

- No Pre-Trained Global Keywords: Teams cannot use models pre-trained on generic smart-assistant keywords like 'Hey Google' or 'Alexa'. They need to train on a custom key word.

Expected Solution Teams are expected to deliver a robust, deployable system architecture. A successful submission must strictly satisfy the following technical boundaries:

- Hardware & Runtime Environment: The edge software application must run smoothly within an environment restricted to less than 256KB of RAM and consume under 10% CPU utilization while idling in continuous listening mode. Heavy or uncompressed pre-trained transformers are disqualified. Solutions will be formally evaluated on physical low-power microcontrollers (e.g., Raspberry Pi or ESP32).

- Model should work for the given custom key word.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26173"></a>[173] SIH26173: iTantra -Indian Multilingual TTS & STT Aided Neural Transceiver Radio Access for low bitrate links

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26173` (SIH26173) |
| **Problem Statement Title** | iTantra -Indian Multilingual TTS & STT Aided Neural Transceiver Radio Access for low bitrate links |
| **Organization** | Indian Space Research Organisation(ISRO) |
| **Department** | Department of Space / Indian Space Research Organisation |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background As vocal audio information is very data intensive making it difficult to transmit through low data rate links. In alert and distress based scenarios Transmitting Audio information is critical instead of written message as it will be more inclusive and will cater to everyone even if they are literate or not.

Description Build an Android App with lightweight, highly accurate STT and TTS models for 10 Indian Languages (Hindi, Gujarati, Marathi, Kannada, Malayalam, Tamil, Telugu, Odia, Bengali, English) that runs locally on a low-power device. The system's STT module when activated after detecting pauses and stoppages should form the sentences detected and must instantly and efficiently stream the data through wifi/Bluetooth connected embedded device or another phone with same application with minimal latency. The systems TTS module when activated after receiving the Text data should convert it into intelligible speech which will be played as a voice note and alert type messages will be announced at highest volume non-interruptible. To verify the complete loop two phones with same app one in TTS mode and another in STT mode can be connected via wifi or Bluetooth and it should work like a walkie talkie using push to talk feature, if turned off it should work like a phone.

Key Metrics for Evaluation

- Efficiency: Model size, App size (RAM/Flash footprint) and CPU usage during idle listening. (20%)

- Accuracy: Low Word Error Rate for STT and High human legibility and flow for TTS. (40%)

- Latency: The Time delay between the Words said and STT completion, Time delay between the text received and audio processed and played for TTS along with RTF (Real Time Factor). The time delta between the sentence said and the same sentence started as audio in another phone. (20%)

Software & Framework Restrictions

- Open-Source Only: The use of proprietary, closed-source, or commercial voice-activation SDKs is strictly prohibited.

- Allowed Frameworks: Teams must build their pipelines using open-source machine learning and TinyML frameworks. Recommended tools include TensorFlow Lite for Microcontrollers, PyTorch Mobile or similar.

- Fully Offline Working: Model or pipeline should work fully offline only and no internet hosted API based solutions are expected and encouraged for the STT or TTS.

Expected Solution Teams are expected to deliver a robust, deployable system architecture. A successful submission must strictly satisfy the following technical boundaries:

- Hardware & Runtime Environment: The Android application must run smoothly on Low and Mid rage mobile phones.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26174"></a>[174] SIH26174: AI Human Activity Recognition for On-board BAS Experiments

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26174` (SIH26174) |
| **Problem Statement Title** | AI Human Activity Recognition for On-board BAS Experiments |
| **Organization** | Indian Space Research Organisation(ISRO) |
| **Department** | Department of Space / Indian Space Research Organisation |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background As humanity aims for space missions such as BAS and lunar missions, real-time ground support becomes impossible due to communication delays. An AI-based HAR system acts as an on-board assistant that supports the execution of scientific experiments, ensuring the success of science beyond Earth's orbit.

In the space environment, AI-based HAR system may act as mission-critical support for astronauts. By tracking astronaut movements and activities in real time, HAR ensures scientific experiments and related protocols are executed flawlessly without requiring constant, high-bandwidth communication with mission control.

Description Challenge is to design and train an AI model that recognizes and validates the sequence of a pre-defined experiment using human activity recognition techniques.

Standalone operation: Space stations operate on restricted data bandwidth to Earth. Rather than streaming raw video to ground control, data is processed locally at the 'edge.' Inputs are given from fixed-payload cameras.

Dataset generation to train model for object detection, pose estimation and hand-object interaction based on the steps of the experiment.

Optional: Another challenge is that Standard 2D or ground-based 3D posture models fail because astronauts do not have a fixed 'up' or 'down' orientation. The AI model should use orientation-agnostic 3D Human Mesh Recovery (HMR) to track the astronaut's body relative to the payload rack, not the floor.

Expected Solution

- The software should continuously process local video feeds to track the sequence of experiment.

- At the start or after each step, the model should suggest the next step to be performed.

- It should alert when a step is skipped or an out of sequence step is added. It should be a voice based alert.

- Using the live video, it should generate a timestamped and structured lightweight text file of the conducted steps with outcomes/ status.

- Stream the video of the experiment to specific IP and also store the video locally.

- A graphical user interface for monitoring the above activities.

- Deliverable: A trained AI model that runs on offline standalone system

#### Dataset & Reference Links

This problem requires synthetic dataset generation. Teams have to build a custom, highly focused local dataset (even just using a webcam) replicating a specific experiment. For this particular problem, following is the sequence of steps in a sample experiment:

Sample Experiment You are given a box that contains two smaller boxes of color red and

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26175"></a>[175] SIH26175: DepthWizard - Single-View Height Estimation and 3D Flythrough

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26175` (SIH26175) |
| **Problem Statement Title** | DepthWizard - Single-View Height Estimation and 3D Flythrough |
| **Organization** | Indian Space Research Organisation(ISRO) |
| **Department** | Department of Space / Indian Space Research Organisation |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background Accurate Digital Elevation Models (DEMs) and Digital Surface Models (DSMs) are fundamental to urban planning, disaster management, and military reconnaissance. Traditionally, elevation data is acquired through stereo-imaging pairs, LiDAR, or Interferometric Synthetic Aperture Radar (InSAR). These approaches can be cost-prohibitive, dependent on specific sensor availability, and computationally intensive. Single-view height estimation offers an agile alternative, but foundational monocular depth models are trained largely on natural egocentric imagery and predict relative depth. When applied to remote sensing, they face domain gaps, structural variations, and a lack of absolute-scale mapping. Converting relative depth into metric elevation remains a critical challenge, alongside the operational need to transform static elevation profiles into interactive 3D assets that can be navigated in real time.

Description Develop an end-to-end software pipeline that transforms single-view optical RGB remote-sensing images into high-precision elevation maps. The framework must support both non-georeferenced and georeferenced imagery.

- Non-Georeferenced RGB Imagery (for example, PNG or JPG): Produce a Relative Digital Surface Model (rDSM) for images without spatial metadata.

- Georeferenced RGB Imagery (for example, GeoTIFF): Produce an Absolute Digital Surface Model (DSM) with metric height values for images containing coordinate-system metadata.

The solution should use a pre-trained monocular depth-estimation backbone to generate initial relative-depth maps. For georeferenced imagery, a lower-resolution DEM source such as SRTM or a limited set of Ground Control Points may be used to map scale-agnostic depth features to absolute metric elevations. For non-georeferenced imagery, relative height may be used directly in the visualization stage.

After computing the elevation map, the system should project the original optical image onto a generated 3D terrain mesh and integrate the result with a rendering engine such as Unity, Three.js, or Babylon.js. The interface should support seamless first-person navigation and analysis of structural heights and slopes from arbitrary aerial perspectives.

Key Milestones

- Elevation Extraction: Use a robust pre-trained monocular depth model to extract geometric and structural representations from single-view optical imagery.

- Scale Calibration: Develop a module that converts relative depth to absolute height using scene-level statistics, low-resolution DEMs, semantic priors, or minimal Ground Control Points for georeferenced inputs.

- Visualization Layer: Build an immersive, preferably interactive, rendering pipeline that converts the optical texture and derived depth map into a navigable 3D environment deployable as a standalone application.

**Evaluation Criteria:**

- DSM Estimation - Accuracy and Validation (50%): Evaluate RMSE, MAE, and correlation against LiDAR or reference data, including performance stability across urban, sparse, hilly, and forested landscapes.

- Visualization - Rendering Quality and User Experience (50%): Assess projection accuracy, visual fidelity, navigability of the 3D flythrough, interface intuitiveness, software stability, and successful standalone deployment.

Expected Solution Deliver a fully integrated software suite with complete source code and technical documentation. The solution must be deployable as a unified module containing the following components:

- Elevation Estimation Module: Accept single-view optical satellite imagery in PNG, JPG, or TIFF format and output a high-fidelity DSM in a standard geospatial format.

- Interactive Visualization Platform: Provide a user-friendly 3D flythrough experience that lets users upload imagery, visualize reconstructed terrain, and validate estimated height values against reference datasets.

#### Dataset & Reference Links

Any high-resolution remote-sensing dataset openly available on the internet may be used for development. Reference dataset: https://github.com/IMG-PROCESS-SAC/SIH2026/. A lower-resolution DEM source such as SRTM 30 m may be used to map scale-agnostic depth features to absolute metric elevations. During final evaluation, ISRO RGB-band optical satellite i

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26176"></a>[176] SIH26176: ORCA Marine EcOsystem Reasoning with Collaborative Agents

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26176` (SIH26176) |
| **Problem Statement Title** | ORCA Marine EcOsystem Reasoning with Collaborative Agents |
| **Organization** | Indian Space Research Organisation(ISRO) |
| **Department** | Department of Space / Indian Space Research Organisation |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background The marine ecosystem plays a vital role in supporting livelihoods, food security, biodiversity, maritime transportation, coastal resilience, and the blue economy. Every day, vast volumes of satellite Earth Observation and oceanographic data, including Sea Surface Temperature (SST), chlorophyll concentration, and weather forecasts, are generated by ISRO and other global agencies.

Marine stakeholders such as fishermen, researchers, coastal authorities, disaster management agencies, and maritime operators rely on timely access to oceanographic and meteorological information for operational planning and decision-making. As the volume, diversity, and complexity of marine data continue to increase, there is a growing need for an intelligent conversational platform that enables users to interact naturally with marine information, ask questions, explore scenarios, and receive synthesized, evidence-based recommendations tailored to their context.

Advances in Agentic AI, conversational intelligence, and geospatial technologies present an opportunity to fundamentally transform how marine information is accessed and utilized. By integrating satellite Earth Observation data with autonomous AI agents, intelligent conversational decision-support systems should be able to answer questions such as 'Where is the nearest Potential Fishing Zone today?', 'Is it safe to venture into the sea tomorrow morning?', or 'What are the tide, weather, and sea conditions near my fishing location?' and provide explainable, context-aware recommendations.

Description Develop an Agentic AI-powered conversational platform that enables users to access, analyze, and reason over marine information using natural language.

The platform should autonomously interpret user intent, decompose complex requests into executable tasks, coordinate multiple specialized AI agents, retrieve relevant marine and geospatial datasets, perform spatial-temporal reasoning, and synthesize actionable recommendations through a conversational interface.

The solution should be capable of integrating information from multiple sources, including satellite Earth Observation products, GIS layers, weather services, oceanographic observations, and marine advisories available in the public domain.

**Typical user queries include:**

- Where is the nearest Potential Fishing Zone (PFZ) today?

- Is it safe to venture into the sea tomorrow morning?

- What are the tide, weather, and sea conditions near my fishing location?

- Are there any lightning or cyclone alerts in my area?

- Which regions show high chlorophyll concentration and favourable sea surface temperature?

- What is the safest route for a fishing vessel considering weather and sea-state conditions?

- Why has fish productivity declined in a particular coastal region?

- Which fishing zones should be avoided due to hazardous marine conditions or geofencing restrictions?

The platform should not merely retrieve information from individual datasets but intelligently correlate observations from multiple sources, explain the reasoning behind its recommendations, and present insights through conversational responses, maps, alerts, and interactive geospatial visualizations.

Expected Solution Participants are expected to develop an Agentic AI-powered Marine Intelligence Platform that leverages collaborative AI agents, geospatial technologies, and satellite Earth Observation data to provide intelligent conversational decision support.

The solution should demonstrate the core principles of Agentic AI, including autonomous planning, reasoning, tool selection, task execution, collaboration among specialized agents, and explainable decision-making.

**The platform should be capable of:**

- Understanding user intent expressed in natural language.

- Automatically identifying the language of the user's query and responding in the same language, with emphasis on supporting Indian regional languages.

- Supporting contextual, multi-turn conversations that enable users to refine queries and explore related scenarios.

- Autonomously discovering, retrieving, and integrating relevant satellite, marine, meteorological, and geospatial datasets.

- Performing spatial, temporal, and contextual reasoning by correlating observations from multiple heterogeneous data sources.

- Generating explainable, evidence-based recommendations supported by maps, charts, geospatial visualizations, and marine advisories.

- Enhancing fishermen safety through proactive alerts for adverse weather, high waves, lightning, cyclones, and other hazardous marine conditions.

- Providing geofencing-based notifications when approaching international maritime boundaries, restricted waters, marine protected areas, ecologically sensitive zones, or other predefined operational boundaries.

- Assisting with route optimization, safe navigation, and operational planning based on prevailing and forecast marine conditions.

- Delivering reliable recommendations together with the supporting evidence and reasoning used to derive each response.

Participants are encouraged to design a modular multi-agent architecture comprising specialized AI agents for planning, marine data discovery, weather intelligence, ocean analytics, geospatial reasoning, risk assessment, visualization, reporting, and user interaction. The architecture should demonstrate autonomous collaboration among agents to solve complex marine intelligence problems while providing an intuitive conversational experience.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26177"></a>[177] SIH26177: A deployable AI-powered autonomous drone that aids search-and-rescue operations by detecting people and hazards, thereby improving responder safety and reducing victim discovery time.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26177` (SIH26177) |
| **Problem Statement Title** | A deployable AI-powered autonomous drone that aids search-and-rescue operations by detecting people and hazards, thereby improving responder safety and reducing victim discovery time. |
| **Organization** | Qualcomm Inc |
| **Department** | Qualcomm Inc |
| **Category** | Hardware |
| **Theme** | Robotics and Drones |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background India is highly vulnerable to natural disasters including floods, cyclones,earthquakes, landslides, and flash floods, which often result in damaged infrastructure, inaccessible terrain, and delayed rescue operations. During the first few critical hours after a disaster, responders need rapid situational awareness to locate survivors, assess hazards, and prioritize rescue efforts.Traditional ground-based assessments can be slow, dangerous, and resource-intensive, particularly in remote or heavily damaged areas. Autonomous drones equipped with on-device AI can provide real-time aerial intelligence while operating in environments with limited connectivity.

Description Develop an autonomous drone system capable of navigating disaster-affected areas and performing real-time detection of survivors and hazards using on-device AI. The drone should use RGB and thermal cameras to identify stranded individuals, detect signs of human presence, and recognize environmental hazards such as fire, floodwaters, damaged structures, exposed electrical lines,debris, landslides, or chemical leaks. The solution must process data locally on the drone to ensure low latency and continued operation even when network connectivity is unavailable. The drone should autonomously map affected regions,generate situational reports, and transmit actionable insights to emergency response teams. This concept aligns with existing edge-AI drone approaches for incident response and disaster assessment.

Expected Solution The proposed solution should include some or all of the following:

- Autonomous Navigation: GPS-enabled and GPS-denied navigation capabilities using AI, SLAM, and obstacle avoidance for operation in damaged environments.

- On-Device AI Inference: Real-time detection of people, survivors, and disaster-related hazards without dependence on cloud connectivity.

- Multi-Sensor Fusion: Integration of RGB cameras, thermal cameras, IMU,and GPS sensors for accurate identification and localization of victims.

- Hazard Classification: Detection and classification of floods, fires, smoke,debris, unstable structures, landslide zones, and other safety threats.

- Geo-Tagged Mapping: Creation of live disaster maps highlighting survivor locations, hazard zones, and safe access routes for rescue teams.

- Emergency Alerting: Automatic generation of alerts and prioritized rescue recommendations based on detected risks.

- Offline Resilience: Ability to function in communication-constrained environments with optional 5G/Wi-Fi connectivity when available.

- Command Center Dashboard: Visualization of drone feeds, detected survivors, hazard markers, and mission status to support disaster management agencies.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26178"></a>[178] SIH26178: A resilient, AI-powered environmental monitoring network that provides early detection, localized intelligence, and actionable alerts for floods, forest fires, pollution events, and other environmental hazards common in India, enabling authorities and communities to shift from reactive disaster response to proactive risk prevention.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26178` (SIH26178) |
| **Problem Statement Title** | A resilient, AI-powered environmental monitoring network that provides early detection, localized intelligence, and actionable alerts for floods, forest fires, pollution events, and other environmental hazards common in India, enabling authorities and communities to shift from reactive disaster response to proactive risk prevention. |
| **Organization** | Qualcomm Inc |
| **Department** | Qualcomm Inc |
| **Category** | Hardware |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background India faces a growing range of environmental and climate-related risks including urban flooding, river floods, cyclones, forest fires, air pollution, droughts, landslides, and extreme weather events. Floods remain among the most frequent disasters across states such as Assam, Bihar, Kerala, and Maharashtra, while forest fires increasingly affect Uttarakhand, Himachal Pradesh, and central Indian forests. Air pollution continues to impact major urban centers, and climate change is increasing the frequency and intensity of these hazards. Government agencies such as NDMA, IMD, and ISRO already rely on environmental monitoring and early warning systems to support disaster management.

Traditional monitoring systems often depend on centralized infrastructure and may not provide sufficiently localized, real-time intelligence. A distributed network of smart sensors powered by edge AI can improve early detection, reduce response times, and enable communities to act before environmental risks escalate into disasters.

Description Design an Environmental Intelligence Network, a distributed system of interconnected AI-powered sensor nodes deployable across cities, rivers, forests, industrial zones, and vulnerable communities. Each node should use local (on device) AI inference to continuously monitor environmental conditions and identify emerging risks such as:

- Rising water levels and flash flooding

- Forest fires and smoke events

- Hazardous air pollution

- Extreme heat conditions

- Landslide precursors

- Industrial emissions or chemical leaks

- Water quality degradation The sensor network should process data locally to reduce latency, minimize bandwidth requirements, and continue operating even during network outages.

Only critical alerts, summarized insights, and risk assessments should be transmitted to regional control centers or disaster management authorities. Edge AI approaches enable devices to operate effectively in low-connectivity environments while providing rapid detection and decision support.

Expected Solution The proposed solution should include:

1. Distributed Smart Sensor Nodes

- Environmental sensors for water level, rainfall, temperature, humidity,smoke, air quality (PM2.5/PM10), gas leakage, soil moisture, and vibration.

- Solar-powered, low-maintenance deployments suitable for remote locations.

2. On-Device AI Analytics

- Real-time anomaly detection at the edge.

- AI models capable of identifying flood risk, wildfire indicators, air-quality deterioration, and landslide warning signs.

- Operation without continuous cloud connectivity.

3. Multi-Hazard Early Warning System

- Automated alerts for:

o Flooding and flash floods o Forest fires o Hazardous pollution episodes o Extreme weather conditions o Industrial safety incidents 4. Regional Environmental Risk Mapping

- Geospatial visualization of sensor data.

- Dynamic risk maps showing hotspots, risk trends, and affected zones.

- Integration with emergency management dashboards.

5. Community and Authority Notification

- Mobile and web alerts for local authorities and citizens.

- Prioritized warning levels based on severity and confidence scores.

6. Cloud and Edge Hybrid Architecture

- Edge processing for immediate decisions.

- Centralized analytics for long-term trend analysis, forecasting, and policy support.

7. Scalable and Cost-Effective Deployment

- Modular architecture that can scale from a single village to a smart city or state-wide deployment.

- Support for IoT protocols such as LoRaWAN, NB-IoT, Wi-Fi, or 5G.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26179"></a>[179] SIH26179: To build an AI-powered retail intelligence platform that delivers real-time shopper analytics, automated inventory visibility, and proactive queue management through on-device AI,enabling retailers to reduce stock-outs, improve customer experience, optimize staffing, and increase operational efficiency while maintaining privacy and minimizing cloud dependency.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26179` (SIH26179) |
| **Problem Statement Title** | To build an AI-powered retail intelligence platform that delivers real-time shopper analytics, automated inventory visibility, and proactive queue management through on-device AI,enabling retailers to reduce stock-outs, improve customer experience, optimize staffing, and increase operational efficiency while maintaining privacy and minimizing cloud dependency. |
| **Organization** | Qualcomm Inc |
| **Department** | Qualcomm Inc |
| **Category** | Hardware |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background India's retail sector includes millions of neighborhood stores, supermarkets,pharmacies, and large-format retail outlets that serve high customer volumes every day. Retailers face challenges such as inventory shrinkage, stock-outs, long billing queues, inefficient shelf replenishment, and limited visibility into shopper behavior. Many stores, especially in Tier-2 and Tier-3 cities, also operate with constrained internet connectivity and require solutions that can function reliably without continuous cloud access.

Recent advances in edge AI allow cameras and sensors to perform real-time analytics directly on local devices, enabling faster decisions, improved privacy,reduced bandwidth consumption, and uninterrupted operation even during connectivity outages. Hybrid and edge AI approaches are increasingly being adopted for real-time monitoring and decision support across multiple industries.

Description Design an Intelligent Retail Analytics System that uses smart cameras and on-device AI to monitor retail operations in real time. The system should analyze shopper movement, inventory levels, and checkout queues without requiring constant cloud processing.The solution should automatically identify customer traffic patterns, measure dwell time in different store sections, detect out-of-stock products, monitor shelf compliance, and predict queue congestion before it impacts customer experience.AI inference should happen locally on the edge devices to enable low-latency decisions while preserving customer privacy and minimizing network dependency.The system should convert video streams into actionable business insights that help retailers improve operational efficiency, optimize staffing, increase product availability, and enhance customer satisfaction. Edge-based analytics can provide real-time intelligence while reducing dependence on cloud connectivity.

Expected Solution The proposed solution should implement some or all of the following:

1. Shopper Analytics

- Detect and count customers entering and exiting the store.

- Analyze footfall trends by time, day, and store zone.

- Measure shopper dwell time near products and promotional displays.

- Generate heatmaps showing customer movement patterns.

2. Inventory Monitoring

- Detect low-stock and out-of-stock situations using shelf-facing cameras.

- Monitor planogram compliance and product placement.

- Alert store staff when replenishment is required.

- Track merchandise availability in real time.

3. Queue Intelligence

- Monitor checkout counters and queue lengths.

- Predict congestion before queues become excessive.

- Recommend opening additional billing counters.

- Measure average waiting and service times.

4. Edge AI Processing

- Run all computer vision models locally on edge hardware.

- Operate even during internet disruptions.

- Reduce cloud bandwidth and operational costs.

- Support rapid, low-latency decision-making.

5. Privacy-Aware Analytics

- Use anonymous people detection and tracking.

- Avoid storing personally identifiable information.

- Process sensitive data locally where possible.

6. Store Operations Dashboard

- Real-time alerts for stock shortages and queue build-up.

- Daily and weekly analytics reports.

- KPI visualization including footfall, conversion indicators, inventory status, and staff efficiency.

7. Scalable Deployment

- Support deployment across small stores, supermarkets, and retail chains.

- Integrate with POS, inventory management, and ERP systems.

- Allow centralized monitoring of multiple locations.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26180"></a>[180] SIH26180: A field-deployable AI-powered Smart Farming Assistant that helps farmers detect crop diseases, pests, nutrient deficiencies, and irrigation needs at an early stage, while improving resilience against droughts, floods, heat waves, and other agricultural risks common in India. The solution should enable higher yields, lower input costs, more efficient water usage, and faster response to emerging threats through real-time on-device intelligence.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26180` (SIH26180) |
| **Problem Statement Title** | A field-deployable AI-powered Smart Farming Assistant that helps farmers detect crop diseases, pests, nutrient deficiencies, and irrigation needs at an early stage, while improving resilience against droughts, floods, heat waves, and other agricultural risks common in India. The solution should enable higher yields, lower input costs, more efficient water usage, and faster response to emerging threats through real-time on-device intelligence. |
| **Organization** | Qualcomm Inc |
| **Department** | Qualcomm Inc |
| **Category** | Hardware |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background Agriculture remains a primary livelihood for millions of people in India, but farmers face recurring challenges from droughts, erratic rainfall, floods, pest infestations, crop diseases, heat stress, and soil degradation. Climate variability is increasing the frequency of these risks, affecting crop productivity and farm incomes. Many small and marginal farmers lack access to timely diagnostics and expert advice, particularly in regions with limited internet connectivity.

Environmental monitoring, edge AI, and local sensing technologies can help deliver real-time insights directly at the farm level without relying on continuous cloud access.Early detection of crop stress, pest outbreaks, irrigation issues, and adverse environmental conditions can significantly reduce crop losses and improve resilience against agricultural disasters such as droughts, floods, and disease outbreaks.

Description Develop a Smart Farming Assistant, an edge AI-powered solution that continuously monitors crop health and environmental conditions directly in the field. Using a combination of cameras, environmental sensors, and on-device AI,the system should identify crop diseases, pest infestations, nutrient deficiencies,water stress, and irrigation requirements in real time.The solution should operate locally on edge devices deployed in farms, enabling rapid analysis and recommendations even in areas with poor connectivity. The system should help farmers make informed decisions about irrigation, pesticide application, fertilizer usage, and crop protection while minimizing water consumption and input costs.The platform should provide actionable alerts and recommendations through a simple mobile or field display interface, enabling farmers to respond quickly to emerging risks before they become large-scale crop failures. Edge AI enables realtime decision-making while reducing dependence on cloud infrastructure.

Expected Solution The proposed solution should implement some or all of the following:

1. Crop Health Monitoring

- Detect visible signs of crop diseases from leaf and plant images.

- Identify nutrient deficiencies through color, texture, and growth analysis.

- Monitor crop growth stages and overall field health.

2. Pest Detection and Early Warning

- Detect common insect pests and infestation patterns using camera-based AI.

- Generate early alerts before infestations spread across fields.

- Support targeted intervention rather than blanket pesticide application.

3. Smart Irrigation Management

- Monitor soil moisture, temperature, humidity, and weather conditions.

- Detect water stress and over-irrigation scenarios.

- Recommend optimal irrigation schedules to conserve water.

4. Environmental Risk Monitoring

- Track conditions associated with drought, excessive rainfall, flooding, heat stress, and disease outbreaks.

- Identify abnormal environmental patterns affecting crop productivity.

- Provide localized field-level alerts.

5. Edge AI Processing

- Perform image analysis and sensor data processing directly on the device.

- Operate in remote areas with limited or intermittent connectivity.

- Deliver low-latency recommendations and alerts.

6. Farmer Advisory System

- Provide simple recommendations such as:

o Irrigate now / delay irrigation o Possible disease detected o Pest activity increasing o Heat-stress warning o Flood-risk alert

- Deliver advice through a mobile app, local display, or SMS notifications.

7. Farm Analytics Dashboard

- Historical trends in crop health and environmental conditions.

- Field-level performance monitoring.

- Yield-risk forecasting and decision-support insights.

8. Scalable Deployment

- Suitable for smallholder farms, cooperatives, and large agricultural enterprises.

- Support integration with weather data, farm equipment, and irrigation systems.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26181"></a>[181] SIH26181: A secure, AI-powered Personal Health Companion that delivers real-time, privacy-preserving health monitoring and early warning capabilities, helping individuals recognize health risks before they become emergencies. The solution should improve resilience during heat waves, floods, pollution events, and other disasters common in India while enabling continuous health support through on-device intelligence.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26181` (SIH26181) |
| **Problem Statement Title** | A secure, AI-powered Personal Health Companion that delivers real-time, privacy-preserving health monitoring and early warning capabilities, helping individuals recognize health risks before they become emergencies. The solution should improve resilience during heat waves, floods, pollution events, and other disasters common in India while enabling continuous health support through on-device intelligence. |
| **Organization** | Qualcomm Inc |
| **Department** | Qualcomm Inc |
| **Category** | Hardware |
| **Theme** | MedTech / BioTech / HealthTech |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Background India faces recurring public health challenges during and after disasters such as heat waves, floods, cyclones, air pollution events, disease outbreaks, and extreme weather conditions. Heat stress, dehydration, respiratory illnesses, cardiovascular complications, and delayed access to healthcare are common during such events.

Rural populations, elderly citizens, outdoor workers, and people with chronic medical conditions are particularly vulnerable. Climate-related hazards are increasing in frequency and intensity, creating a need for continuous, personalized health monitoring that can function even when connectivity and healthcare access are disrupted.

Advances in edge AI now enable wearable devices and mobile phones to analyze health data locally, providing real-time insights while preserving user privacy and operating without constant cloud connectivity. Local AI processing can support health monitoring in remote and underserved areas where internet access may be limited.

Description Develop a Personal Health Companion, a privacy-preserving wearable or mobile application that continuously monitors an individual's physiological and environmental data and uses on-device AI to detect potential health anomalies in real time.The solution should analyze data from sensors such as heart rate, blood oxygen (SpO?), body temperature, activity levels, sleep patterns, and environmental conditions. The system should identify early indicators of heat stress, dehydration, respiratory distress, abnormal vital signs, fatigue, falls, and other health risks that may be exacerbated during disasters and environmental emergencies.All sensitive health data should be processed locally on the device to maximize privacy, minimize latency, and ensure continuous operation even during network outages. The application should provide actionable alerts, wellness recommendations, and emergency notifications while allowing users to maintain control over their personal health information. Edge AI approaches provide faster responses, improved privacy, and offline functionality.

Expected Solution The proposed solution should implement some or all of the following:

1. Continuous Health Monitoring

- Monitor heart rate, SpO?, body temperature, activity levels, and sleep quality.

- Track changes in baseline health patterns.

- Generate personalized wellness indicators.

2. AI-Based Health Anomaly Detection

- Detect abnormal heart rate patterns.

- Identify indicators of heat stress, dehydration, fatigue, and respiratory issues.

- Recognize sudden changes that may require medical attention.

- Provide risk assessments using on-device AI inference.

3. Disaster-Specific Health Alerts

- Heat-wave exposure warnings.

- Air-quality and respiratory-risk alerts.

- Flood and cyclone-related health advisories.

- High-risk notifications for vulnerable individuals during extreme weather events.

4. Environmental Awareness

- Integrate data from local temperature, humidity, and air-quality sensors.

- Assess environmental conditions that may affect health.

- Generate personalized recommendations based on local risks.

5. Privacy-Preserving Edge AI

- Perform all health analysis locally on the device.

- Minimize transmission of sensitive personal information.

- Operate effectively with intermittent or no internet connectivity.

- Maintain user control over data sharing.

6. Emergency Assistance Features

- Automatic detection of falls or medical distress.

- SOS alerts to caregivers or emergency contacts.

- Location-enabled emergency assistance when permitted by the user.

7. Personal Wellness Dashboard

- Daily health summaries and trend analysis.

- Risk scores for heat, respiratory, and cardiovascular stress.

- Personalized recommendations for hydration, rest, activity, and medical consultation.

8. Scalable Deployment

- Support smartphones, smartwatches, fitness bands, and specialized healthcare wearables.

- Suitable for individual consumers, healthcare providers, disaster-response agencies, and public health programs.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26182"></a>[182] SIH26182: Automated Attribution of Unknown Cryptocurrency Wallets to Nearest Virtual Asset Service Providers (VASPs) through Blockchain Intelligence APIs

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26182` (SIH26182) |
| **Problem Statement Title** | Automated Attribution of Unknown Cryptocurrency Wallets to Nearest Virtual Asset Service Providers (VASPs) through Blockchain Intelligence APIs |
| **Organization** | Ministry of Home Affairs |
| **Department** | Indian Cyber Crime Coordination Centre (I4C),CIS Division |
| **Category** | Software |
| **Theme** | Blockchain & Cybersecurity |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

The rapid adoption of Virtual Digital Assets (VDAs) and decentralized blockchain ecosystems has significantly increased the complexity of cybercrime investigations globally. Law Enforcement Agencies (LEAs) frequently encounter cryptocurrency wallet addresses linked to cyber frauds, ransomware, investment scams, darknet activities, and laundering of crime proceeds.

Under the existing investigation workflow, LEAs raise lawful information disclosure requests through the SAHYOG Portal to Virtual Asset Service Providers (VASPs) such as crypto exchanges, custodial wallet providers, and trading platforms. However, in many cases, the suspect wallet identified during investigations belongs to an unhosted wallet or a wallet for which the associated VASP is unknown. This creates major delays in attribution, freezing of assets, and identification of the beneficial owner.

Blockchain transactions generally pass through multiple intermediary wallets before reaching centralized exchanges. Identifying the 'nearest direct deposit accepting exchange' manually through blockchain analysis is time-consuming and requires specialized expertise.

**Description:**

The proposed system envisages development of an Automated Blockchain Intelligence & VASP Attribution Engine integrated with the SAHYOG Portal through APIs.

**The system should:**

- Automatically analyze suspect cryptocurrency wallet addresses reported during investigations on the Sahyog Platform

- Automatically trace blockchain transaction paths to identify:

o nearest centralized exchange, o custodial wallet service, o or VASP receiving direct deposits from the suspect wallet.

- Map blockchain of deposit addresses and transaction flows across multiple blockchain networks such as:

o Bitcoin, o Ethereum, o Tron, o BNB Chain, o Solana, o Polygon o and other major chains.

- Support identification of:

o exchange clusters, o hot wallets, o deposit wallets, o mixers/tumblers, o DeFi bridges, o and cross-chain swap services.

- Integrate Sahyog with blockchain intelligence APIs and graph analytics engines.

- Provide automated tagging and confidence scoring for suspected VASPs.

- Generate investigation-ready reports for LEAs.

- Assist investigators in automatically routing lawful disclosure or freezing requests to the correct VASP through the SAHYOG Portal.

**The system may additionally support:**

- visualization of fund movement,

- cross-chain transaction mapping,

- risk scoring,

- identification of laundering typologies,

- and alerting for high-risk wallets linked to ransomware, darknet, terrorism financing, or fraud ecosystems.

**Expected Solution:**

A software-based blockchain intelligence platform integrated with the SAHYOG ecosystem capable of:

- Automated identification of nearest VASP/exchange linked to unknown wallets.

- API-driven blockchain tracing and attribution support.

- Multi-chain transaction analysis and visualization.

- Real-time generation of investigative intelligence.

- Risk classification of wallets and transaction flows.

- Dashboard for LEAs with case-based analytics and reporting.

- Scalable architecture capable of handling large-volume blockchain transaction analysis.

**The solution should aim to:**

- reduce investigation time,

- improve asset freezing efficiency,

- enhance attribution capabilities,

- and strengthen cross-border cybercrime investigations involving VDAs

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26183"></a>[183] SIH26183: Real-Time Identification of Fraud-Linked Cryptocurrency Exchanges from Victim-Reported Suspect Wallet Addresses through Automated Blockchain Analytics

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26183` (SIH26183) |
| **Problem Statement Title** | Real-Time Identification of Fraud-Linked Cryptocurrency Exchanges from Victim-Reported Suspect Wallet Addresses through Automated Blockchain Analytics |
| **Organization** | Ministry of Home Affairs |
| **Department** | Indian Cyber Crime Coordination Centre (I4C),CIS Division |
| **Category** | Software |
| **Theme** | Blockchain & Cybersecurity |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Cyber fraud victims increasingly report suspect cryptocurrency wallet addresses used by fraudsters for collection of funds in cases involving:

- investment scams,

- task-based frauds,

- sextortion,

- ransomware,

- phishing,

- darknet transactions,

- and organized cyber-enabled financial crimes.

**During investigations, the reported wallet addresses are often:**

- non-custodial wallets,

- temporary burner wallets,

- or intermediary wallets used for layering and laundering.

The inability to quickly identify the cryptocurrency exchange or VASP associated with these wallets delays:

- freezing of assets,

- preservation of evidence,

- tracing of fund flows,

- and victim fund recovery.

Manual blockchain tracing requires significant technical expertise and time, particularly in cases involving:

- multi-chain transfers,

- DeFi protocols,

- mixers/tumblers,

- bridges,

- and privacy-enhancing mechanisms.

**Description:**

The proposed solution envisages a Real-Time Crypto Fraud Attribution System capable of automatically analyzing victim-reported wallet addresses and identifying the nearest exchange or VASP receiving direct deposits.

**The system should:**

- ingest wallet addresses reported through cybercrime complaint systems,

- automatically perform blockchain tracing,

- identify associated exchanges or VASPs,

- detect fund movement patterns,

- and generate actionable intelligence for investigators.

**Key features may include:**

- blockchain transaction graph analysis,

- clustering of exchange wallets,

- detection of intermediary laundering wallets,

- identification of cross-chain fund movement,

- integration with SAHYOG and NCRP platforms,

- automated alert generation,

- and risk categorization of wallets.

**The system should support multiple blockchain ecosystems and provide:**

- real-time tracing capability,

- automated investigative recommendations,

- and analytics dashboards for law enforcement agencies

**Expected Solution:**

A software platform capable of:

- real-time blockchain intelligence generation,

- automated VASP identification,

- tracing of suspect wallets,

- cross-chain transaction analytics,

- fund-flow visualization,

- integration with LEA systems,

- and generation of standardized investigation reports.

**The system should:**

- reduce response time in cyber fraud investigations,

- improve freezing of proceeds of crime,

- enhance coordination with VASPs,

- and strengthen digital evidence collection capabilities.

**The platform should further support:**

- API integrations,

- scalable blockchain indexing,

- AI/ML-assisted risk detection,

- and automated pattern recognition for fraud typologies.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26184"></a>[184] SIH26184: Development of a Predictive Analytics Framework for Cybercrime Complaints to Forecast Likely Cash Withdrawal Locations in Advance, Enabling Generation of Actionable Intelligence for Timely and Proactive Cybercrime Intervention.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26184` (SIH26184) |
| **Problem Statement Title** | Development of a Predictive Analytics Framework for Cybercrime Complaints to Forecast Likely Cash Withdrawal Locations in Advance, Enabling Generation of Actionable Intelligence for Timely and Proactive Cybercrime Intervention. |
| **Organization** | Ministry of Home Affairs |
| **Department** | Indian Cyber Crime Coordination Centre (I4C),CIS Division |
| **Category** | Software |
| **Theme** | Blockchain & Cybersecurity |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

The National Cybercrime Reporting Portal is the centralized Portal, which is serving the whole country. Currently, the Portal facilitates citizens in filing complaints, LEAs act on complaints, Banking/Financial Institutions for their actions along with reports/graphs being pulled on daily basis. Presently, the Portal is receiving approximately 8000 complaints on daily basis. The number of complaints has increased manifold during the past months, and this will continue to rise in future. To address the issue of increasing cybercrimes, the proactive approach shall be adopted.

**Description:**

This framework focuses on the mitigation of cybercrimes by adopting a proactive approach. The framework's output will enable the prediction of likely cash withdrawal locations, which, in turn, will allow law enforcement agencies (LEAs)

at the state and local levels, coordinated by I4C, to implement proactive interventions. These interventions could include deploying special teams or alerting local banks and ATMs in high-risk areas. The intelligence generated would also help banks and financial institutions (FIs) through the Citizen Financial Cyber Fraud Reporting and Management System, enabling faster fund blocking and increasing the chances of recovery. By supporting real-time actionable intelligence sharing across jurisdictions, law enforcement agencies and Banks/FIs will be able to respond faster and more effectively to cyber threats. This approach goes beyond merely reacting to complaints and creates a powerful, data-driven defense against financial cyber frauds, strengthening India's overall cybersecurity posture.

Enhancing coordination between law enforcement and financial entities will ensure better detection and prevention of financial crimes, creating a more unified and efficient approach to combating cybercrime.

- Key Deliverables Component:- Description a. Predictive Analytics Engine :-AI/ML-based system to analyse historical cybercrime and financial data to predict potential withdrawal hotspots. Features include pattern detection, geospatial risk modelling, and real-time alerts.

b. Risk Heatmap Dashboard:-GIS-enabled dashboard visualizing real-time and potential risk zones with drill-down filters by time, location, and crime category etc.

c. Law Enforcement Interface:-Secure interface for investigators to access alerts, intelligence reports, and evidence documentation.

d. Alert & Notification System:-Real-time notifications to law enforcements, banks, and I4C officers via SMS,email, API, or dashboard triggers.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26185"></a>[185] SIH26185: Helmet mounted conformal antenna for tactical communications in urban CQB environments.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26185` (SIH26185) |
| **Problem Statement Title** | Helmet mounted conformal antenna for tactical communications in urban CQB environments. |
| **Organization** | Ministry of Home Affairs |
| **Department** | National Security Guard (NSG), Police II Division |
| **Category** | Hardware |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

During high-intensity urban counter-terrorism (CT) and Close-Quarter Battle (CQB) operations, the National Security Guard (NSG) operates in highly restrictive indoor spaces like closed rooms, basement areas, narrow corridors and stairwells. For seamless communication, commandos rely on vest-mounted handheld tactical radios. These systems traditionally use rigid, protruding omnidirectional whip antennas mounted on top of the radio itself. In fast-paced operations in confined spaces, these external whip antennas not only restricts ranges but also present an obstruction or cause frequent snagging on obstacles like door frames, windows or loose and hanging objects which can damage the the radio interface or obstruct his tactical movement.

**Description:**

Traditional whip antennas pose significant operational limitations.

When an assault team enters a reinforced concrete or steel/glass-framed building, the RF signals radiated from a vest-mounted antenna suffers from severe attenuation and fading as the signals are tend to be blocked by virtue of its low positioning. Additionally, omnidirectional radiation patterns make the team vulnerable to electronic eavesdropping or directional tracking by sophisticated adversaries. To address these challenges, the antenna system needs to be elevated to the highest physical point of the commando - the helmet - without adding bulk or altering ballistic integrity. There is an immediate requirement to develop a low-profile, flexible conformal antenna array that integrates seamlessly into or onto tactical ballistic helmets while maintaining high gain and minimal protruding hardware.

**Expected Solution:**

A ruggedized, zero-profile wearable antenna system should be developed with the following parameters:- (a) Lightweight, ultra-thin and flexible microstrip patch antenna elements designed for integration with NSG ballistic helmets without degrading impact or ballistic protection ratings.

(b) The conformal array must support UHF and L band frequencies to be able to operate with handheld radios and with the svl equipment like helmet mounted/ body worn cameras to transmit live video streams.

(c) Advanced RF shielding layers built into the underside of the array to isolate the commando's head from radiation while directing an optimized radiation pattern upward and outward.

(d) A ruggedized coaxial interface cable routed cleanly along the helmet to connect directly into the NSG existing handheld radios and body-worn camera systems being procured.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26186"></a>[186] SIH26186: AI-Based Predictive Personnel Stress and Welfare Monitoring System for Uniformed Forces

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26186` (SIH26186) |
| **Problem Statement Title** | AI-Based Predictive Personnel Stress and Welfare Monitoring System for Uniformed Forces |
| **Organization** | Ministry of Home Affairs |
| **Department** | Central Reserve Police Force (CRPF), Police II Division |
| **Category** | Software |
| **Theme** | MedTech / BioTech / HealthTech |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Personnel serving in Central Armed Police Forces (CAPFs), Armed Forces, and other uniformed services operate under physically demanding, psychologically stressful, and often hazardous conditions.Extended deployments, operational pressures, separation from families,irregular working hours, and exposure to traumatic incidents can significantly impact mental well-being.Currently, stress identification largely depends on manual observation and self-reporting, which may delay timely intervention. There is a need for a proactive, technology-driven solution that can identify early indicators of stress, burnout, and psychological distress while maintaining privacy and organizational trust.

**Description:**

The proposed solution aims to develop an AI-powered Personnel Stress and Welfare Monitoring System capable of identifying potential indicators of stress, burnout, emotional fatigue, and welfare concerns through analysis of organizational and voluntarily provided wellness data.The system should:

- Analyze HR-related indicators such as leave patterns,deployment history, duty schedules, transfer frequency, training commitments, and workload trends.

- Support optional self-reporting and wellness assessments through a secure mobile application.

- Incorporate voluntary biometric and wellness data, where authorized and legally permissible.

- Detect behavioral patterns associated with elevated stress risk.

- Generate risk assessments and welfare recommendations for authorized welfare officers and commanders.

- Enable proactive counseling, welfare interventions, and workload balancing measures.

The system must be designed with strong privacy safeguards and focus on welfare support rather than disciplinary actions.

**Expected Solution:**

Develop an AI-driven predictive analytics platform comprising:

- Personnel Wellness Monitoring Dashboard.

- Mobile-based Wellness and Self-Assessment Application.

- Predictive Behavioral Analytics Engine.

- Stress and Burnout Risk Prediction Models.

- Welfare Intervention Recommendation System.

- Role-based Access Control and Privacy Management Framework.

- Automated Alerts for authorized welfare personnel.

- Data anonymization and secure storage mechanisms.

The solution should identify trends and risk factors while ensuring that individual dignity, confidentiality, and data protection requirements are maintained.

- Expected Benefits 1. Early identification of personnel requiring welfare support.

2. Reduction in stress-related incidents and operational fatigue.

3. Improved mental well-being and workforce resilience.

4. Enhanced readiness and operational effectiveness.

5. Better workload distribution and personnel management.

6. Improved retention and job satisfaction.

7. Data-driven welfare planning and resource allocation.

8. Reduction in incidents arising from prolonged occupational stress.

- Preliminary Scope 1. Development of predictive behavioral analytics algorithms.

2. Mobile-based wellness self-reporting platform.

3. AI-driven stress and burnout risk assessment engine.

4. Commander and Welfare Officer dashboard.

5. Automated intervention recommendation system.

6. Secure integration with HRMS and personnel management systems.

7. Privacy-preserving analytics and role-based access controls.

- Key Technical Challenges 1. Ensuring privacy and confidentiality of sensitive personnel data.

2. Preventing stigmatization of personnel identified as potentially at risk.

3. Minimizing false positives and false negatives in risk prediction.

4. Ensuring ethical and transparent AI decision-making.

5. Securing highly sensitive psychological and welfare-related information against cyber threats.

6. Building trust among personnel regarding system usage and data protection.

- Strategic Importance

- Enhances force readiness and personnel welfare.

- Supports evidence-based welfare management.

- Strengthens organizational resilience and operational effectiveness.

- Promotes preventive mental health care rather than reactive interventions.

- Creates an indigenous capability tailored to the unique operational and cultural environment of Indian CAPFs and Armed Forces.

- Potential Market 1. Central Armed Police Forces (CAPFs).

2. Indian Armed Forces.

3. State Police Organizations.

4. Disaster Response and Emergency Services.

5. Government Organizations with high-stress workforces.

6. Corporate Human Resource and Employee Wellness Platforms.

7. International security and workforce welfare markets.

- Expected Impact The proposed AI-enabled Personnel Stress and Welfare Monitoring System will help transform welfare management from a reactive process to a proactive and preventive framework. By enabling early identification of stress indicators and facilitating timely interventions,the solution can improve personnel well-being, enhance operational effectiveness, and strengthen the long-term resilience of uniformed services while maintaining the highest standards of privacy, ethics, and data security.

#### Dataset & Reference Links

Anonymized HR datasets, deployment records, leave history, wellness survey data, workload data, and simulated behavioral datasets.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26187"></a>[187] SIH26187: AI-Based Intelligent Video Analytics Platform for Border Surveillance using existing CCTV Infrastructure.

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26187` (SIH26187) |
| **Problem Statement Title** | AI-Based Intelligent Video Analytics Platform for Border Surveillance using existing CCTV Infrastructure. |
| **Organization** | Ministry of Home Affairs |
| **Department** | Sashastra Seema Bal (SSB), Police II Division |
| **Category** | Software |
| **Theme** | Smart Automation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Border security forces deploy CCTV cameras at Border Out Posts(BOPs), check posts, border roads, and other strategic locations for surveillance and monitoring. However, conventional CCTV systems primarily provide video recording and live monitoring capabilities,requiring continuous human observation. Advanced surveillance functionalities such as Facial Recognition Systems (FRS), Automatic Number Plate Recognition (ANPR), intrusion detection, and object tracking often require specialized hardware and proprietary solutions,making large-scale deployment costly and difficult, particularly in remote border areas.

**Description:**

The proposed solution aims to develop an AI-driven software platform capable of transforming existing CCTV infrastructure into an intelligent surveillance network without requiring dedicated FRS, ANPR, or smart-camera hardware. The platform shall ingest live video streams from standard IP-based CCTV cameras and perform real-time video analytics using Artificial Intelligence and Computer Vision techniques.

**The solution should provide capabilities such as:**

- Human detection and tracking

- Vehicle detection and classification

- Face detection

- Automatic Number Plate Recognition (ANPR)

- Virtual fence intrusion detection

- Suspicious activity detection

- Night-time movement detection

- Real-time alert generation and event logging

**Expected Solution:**

The proposed system should leverage Artificial Intelligence, Machine Learning, Computer Vision, and Video Analytics to create a software-defined surveillance platform capable of extracting actionable intelligence from existing CCTV infrastructure.

**The solution should:**

- Eliminate dependence on expensive dedicated surveillance hardware.

- Enable intelligent monitoring through AI-powered video analytics.

- Provide real-time alerts for security incidents and border intrusions.

- Support facial recognition, vehicle identification, and behavioral analytics through software.

- Improve situational awareness and response time for border security forces.

- Support integration with existing command and control systems.

- The final solution should be cost-effective, scalable, and suitable for deployment across remote border locations and strategic installations.

- Possible Project Name IBVAP – Intelligent Border Video Analytics Platform

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26188"></a>[188] SIH26188: Al-Based Fake Identity & Document Screening System

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26188` (SIH26188) |
| **Problem Statement Title** | Al-Based Fake Identity & Document Screening System |
| **Organization** | Ministry of Home Affairs |
| **Department** | Sashastra Seema Bal (SSB), Police II Division |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Common challenges faced at border checkpoints:

- Fake passports and visas

- Altered photographs

- Modified dates of birth

- Tampered visa stamps

- Identity impersonation

- Multiple identities used by the same person Expired or blacklisted travel documents

- High passenger volume causing delays Current verification methods rely heavily on human inspection and basic database lookups.

- Detailed Description Border checkpoints process thousands of identity documents every day,including passports, visas, national identity cards, permits, and travel authorizations. Manual verification is time-consuming, prone to human error, and often unable to detect sophisticated forgeries, tampering, or identity fraud.Develop an Al-powered document screening platform that automatically analyzes identity and travel documents, detects signs of tampering or forgery, validates information against rules and databases,and generates a risk score to assist border security personnel in making faster and more accurate decisions.

**Expected Solution:**

- Module 1: OCR Extraction

- Module 2: Document Validation

- Module 3: Tampering Detection

- Module 4: Face Detection Module 1: OCR Extraction Objective: Automatically extract all relevant information from identity documents.

**Inputs:**

- Passport image

- Visa image

- National ID image

- Driving license

- Permit documents Extracted Fields:

Passport

- Name

- Passport Number

- Nationality

- Date of birth

- Date of expiry

- Gender Visa

- Visa Number

- Visa Type

- Entry Validation

- Stay Duration Module 2: Document Validation Objective: Verify whether the extracted information follows official document standards.

Module 3: Tampering Detection (Core AI Innovation)

Objective: Detect digitally or physically altered documents.

**Use Cases:**

- Photo Replacement

- Text Manipulation

- Stamp Forgery Detection

- Image Metadata Analysis Module 4: Face Verification Objective: Ensure document owner matches the presented individual.

- Expected Impact

- Reduce document verification time from several minutes to a few seconds.

- Improve detection of forged and tampered documents.

- Standardize screening decisions across checkpoints.

- Enable data-driven risk assessment instead of purely manual inspection.

- Create a digital trail for investigations and intelligence analysis.

Possible Project Name Al-Based Fake Identity & Document Screening System.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26189"></a>[189] SIH26189: AI-Powered Criminal Network Analysis System

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26189` (SIH26189) |
| **Problem Statement Title** | AI-Powered Criminal Network Analysis System |
| **Organization** | Ministry of Home Affairs |
| **Department** | National Crime Records Bureau (NCRB), Women Safety Division |
| **Category** | Software |
| **Theme** | Blockchain & Cybersecurity |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Modern criminal activities are increasingly organized and interconnected. Criminals often operate through networks involving associates, intermediaries, financial channels, communication links,locations, and events. Law enforcement agencies collect large volumes of data from sources such as:

- FIRs and police reports

- Call Detail Records (CDRs)

- Financial transaction records

- Surveillance reports

- Social media intelligence

- Criminal history databases

- Intelligence agency reports Despite having access to this information, investigators frequently face challenges in identifying hidden relationships among suspects because the data is fragmented, unstructured, and distributed across multiple systems. Manual analysis can be slow, labor-intensive, and prone to missing critical connections.With advances in Artificial Intelligence (AI), Machine Learning (ML),Natural Language Processing (NLP), and Graph Analytics, it is now possible to automatically discover relationships, detect patterns, and generate insights that can assist investigators in understanding criminal networks more effectively.

**Description:**

The objective is to develop an AI-powered system that can analyze large volumes of criminal and intelligence-related data to uncover hidden networks and relationships among individuals, organizations, locations,and events.

**The system should:**

- Collect and process data from multiple sources.

- Extract important entities such as people, locations, vehicles, phone numbers, and organizations.

- Build relationship maps showing how different entities are connected.

- Identify key individuals who play influential roles within criminal networks.

- Detect suspicious patterns and unusual activities.

- Assist investigators by providing visual and analytical insights.

**Expected Solution:**

Develop an AI-powered system that automatically analyzes structured and unstructured crime-related data to uncover criminal networks,identify key influencers, detect suspicious patterns, and provide actionable intelligence for investigators.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26190"></a>[190] SIH26190: Secure Digital Document Management System for Legal and Investigation Documents

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26190` (SIH26190) |
| **Problem Statement Title** | Secure Digital Document Management System for Legal and Investigation Documents |
| **Organization** | Ministry of Home Affairs |
| **Department** | National Crime Records Bureau (NCRB), Women Safety Division |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Law enforcement agencies, courts, legal departments, and investigative organizations handle vast amounts of sensitive documents throughout the lifecycle of a case. These documents may include:

- FIRs and police reports

- Investigation records

- Witness statements

- Charge sheets

- Court filings

- Evidence records

- Forensic reports

- Legal notices and judgments Many organizations still rely on paper-based systems or fragmented digital storage solutions. This often leads to challenges such as:

- Difficulty in locating documents quickly

- Unauthorized access to confidential information

- Document tampering risks

- Lack of version control

- Inefficient collaboration between departments

- Delays in legal and investigative processes

- Poor auditability and compliance tracking As the volume of legal and investigation-related data continues to grow,there is an increasing need for a secure, centralized, and intelligent document management system that ensures data integrity, accessibility,confidentiality, and efficient case management.Modern technologies such as Cloud Computing, Artificial Intelligence (AI), Blockchain, Digital Signatures, and Secure Access Control can significantly improve the management and security of legal and investigative documents.

**Description:**

The objective is to develop a Secure Digital Document Management System (DMS) that enables law enforcement agencies, legal institutions, and investigative departments to securely store, organize, manage,retrieve, and share sensitive legal and investigation documents.

**The system should:**

- Digitize and centralize document storage.

- Ensure secure access and confidentiality.

- Prevent unauthorized modifications.

- Maintain a complete audit trail of document activities.

- Enable efficient document search and retrieval.

- Support collaboration among authorized stakeholders.

- Ensure compliance with legal and regulatory requirements.

The challenge is to create a secure, scalable, and intelligent platform that streamlines document handling while preserving legal validity and evidentiary integrity.

**Expected Solution:**

Develop a system to monitor and manage police assets throughout their lifecycle.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26191"></a>[191] SIH26191: Intelligent Identification of Hazard-Based Red Zones, Carrying Capacity Assessment, and Immediate Relocation Needs for Vulnerable Habitations

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26191` (SIH26191) |
| **Problem Statement Title** | Intelligent Identification of Hazard-Based Red Zones, Carrying Capacity Assessment, and Immediate Relocation Needs for Vulnerable Habitations |
| **Organization** | Ministry of Home Affairs |
| **Department** | National Disaster Response Force (NDRF), DM Division |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

India's disaster-prone regions face recurring hazards such as landslides,floods, coastal erosion, and cloudbursts. Vulnerable habitations often remain in unsafe zones, leading to repeated loss of lives and property.Current relocation efforts are largely reactive, initiated after disasters strike, rather than proactively planned.

**Description:**

The initiative seeks to develop an intelligent, GIS-enabled decision support platform. This platform will dynamically identify and update multi-hazard Red Zones (areas unsuitable for permanent habitation),assess the carrying capacity of safer alternative sites, and prioritize vulnerable habitations for relocation. The system will integrate hazard intensity, population vulnerability, and disaster history to guide evidence-based decisions.

**Expected Solution:**

A robust, AI-driven GIS platform that Maps and updates hazard-based Red Zones in real time, assesses suitability and carrying capacity of safer relocation sites, prioritizes vulnerable habitations for immediate,short-term, and medium-term relocation and provides actionable insights to State Disaster Management Authorities for proactive planning.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26192"></a>[192] SIH26192: Flash Flood Prediction System for Hilly Regions using Multi-Source Data Theme

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26192` (SIH26192) |
| **Problem Statement Title** | Flash Flood Prediction System for Hilly Regions using Multi-Source Data Theme |
| **Organization** | Ministry of Home Affairs |
| **Department** | National Disaster Response Force (NDRF), DM Division |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

**Background:**

Hilly states in India are highly vulnerable to landslides and flash floods,which often occur with very short warning times. These sudden events result in significant loss of lives and property, and current early warning mechanisms are inadequate for hyper-local prediction and timely evacuation.

**Description:**

The proposed initiative aims to develop a predictive system that integrates multiple data sources - rainfall data, soil moisture sensors,slope stability models, historical landslide inventories, and real-time IoT inputs. By combining these datasets, the system will generate hyper-local forecasts at the village or ward level, providing sufficient lead time for evacuation and risk mitigation.

**Expected Solution:**

A comprehensive flash flood prediction system that Integrates rainfall,soil moisture, slope stability, and historical disaster data, utilizes IoT sensors for real-time monitoring, issues hyper-local early warnings at village/ward level, and provides actionable lead time for evacuation and disaster preparedness.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26193"></a>[193] SIH26193: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26193` (SIH26193) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Software |
| **Theme** | Smart Resource Conservation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Ideas focused on the intelligent use of resources for transforming and advancements of technology with combining the artificial intelligence to explore more various sources and get valuable insights.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26194"></a>[194] SIH26194: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26194` (SIH26194) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Software |
| **Theme** | Fitness & Sports |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Ideas that can boost fitness activities and assist in keeping fit.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26195"></a>[195] SIH26195: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26195` (SIH26195) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Software |
| **Theme** | Heritage & Culture |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Ideas that showcase the rich cultural heritage and traditions of India.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26196"></a>[196] SIH26196: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26196` (SIH26196) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Software |
| **Theme** | MedTech / BioTech / HealthTech |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Cutting-edge technology in these sectors continues to be in demand. Recent shifts in healthcare trends, growing populations also present an array of opportunities for innovation.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26197"></a>[197] SIH26197: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26197` (SIH26197) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Software |
| **Theme** | Agriculture, FoodTech & Rural Development |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Developing solutions, keeping in mind the need to enhance the primary sector of India - Agriculture and to manage and process our agriculture produce.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26198"></a>[198] SIH26198: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26198` (SIH26198) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Software |
| **Theme** | Transportation & Logistics |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Creating intelligent devices to improve commutation sector.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26199"></a>[199] SIH26199: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26199` (SIH26199) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Software |
| **Theme** | Fitness & Sports |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Submit your ideas to address the growing pressures on the city's resources, transport networks, and logistic infrastructure.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26200"></a>[200] SIH26200: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26200` (SIH26200) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Software |
| **Theme** | MedTech / BioTech / HealthTech |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

There is a need to design drones and robots that can solve some of the pressing challenges of India such as handling medical emergencies, search and rescue operations, etc.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26201"></a>[201] SIH26201: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26201` (SIH26201) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Software |
| **Theme** | Smart Resource Conservation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Solutions could be in the form of waste segregation, disposal, and improve sanitization system.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26202"></a>[202] SIH26202: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26202` (SIH26202) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Software |
| **Theme** | Travel & Tourism |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

A solution/idea that can boost the current situation of the tourism industries including hotels, travel and others.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26203"></a>[203] SIH26203: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26203` (SIH26203) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Software |
| **Theme** | Renewable / Sustainable Energy |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Innovative ideas that help manage and generate renewable /sustainable sources more efficiently.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26204"></a>[204] SIH26204: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26204` (SIH26204) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Software |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Provide ideas in a decentralized and distributed ledger technology used to store digital information that powers cryptocurrencies and NFTs and can radically change multiple sectors.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26205"></a>[205] SIH26205: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26205` (SIH26205) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Software |
| **Theme** | Smart Education |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Smart education, a concept that describes learning in digital age. It enables learners to learn more effectively, efficiently, flexibly and comfortably.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26206"></a>[206] SIH26206: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26206` (SIH26206) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Software |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Disaster management includes ideas related to risk mitigation, Planning and management before, after or during a disaster.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26207"></a>[207] SIH26207: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26207` (SIH26207) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Software |
| **Theme** | Travel & Tourism |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Technology ideas in tertiary sectors like Hospitality, Financial Services, Entertainment and Retail.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26208"></a>[208] SIH26208: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26208` (SIH26208) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Software |
| **Theme** | Heritage & Culture |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Challenge your creative mind to conceptualize and develop unique toys and games based on our civilization, history, and culture etc.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26209"></a>[209] SIH26209: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26209` (SIH26209) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Software |
| **Theme** | Space Technology |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Space technology refers to the application of engineering principles to the design, development, manufacture, and operation of devices and systems for space travel and exploration.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26210"></a>[210] SIH26210: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26210` (SIH26210) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Hardware |
| **Theme** | Smart Resource Conservation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Ideas focused on the intelligent use of resources for transforming and advancements of technology with combining the artificial intelligence to explore more various sources and get valuable insights.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26211"></a>[211] SIH26211: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26211` (SIH26211) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Hardware |
| **Theme** | Fitness & Sports |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Ideas that can boost fitness activities and assist in keeping fit.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26212"></a>[212] SIH26212: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26212` (SIH26212) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Hardware |
| **Theme** | Heritage & Culture |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Ideas that showcase the rich cultural heritage and traditions of India.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26213"></a>[213] SIH26213: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26213` (SIH26213) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Hardware |
| **Theme** | MedTech / BioTech / HealthTech |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Cutting-edge technology in these sectors continues to be in demand. Recent shifts in healthcare trends, growing populations also present an array of opportunities for innovation.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26214"></a>[214] SIH26214: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26214` (SIH26214) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Hardware |
| **Theme** | Agriculture, FoodTech & Rural Development |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Developing solutions, keeping in mind the need to enhance the primary sector of India - Agriculture and to manage and process our agriculture produce.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26215"></a>[215] SIH26215: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26215` (SIH26215) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Hardware |
| **Theme** | Transportation & Logistics |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Creating intelligent devices to improve commutation sector.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26216"></a>[216] SIH26216: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26216` (SIH26216) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Hardware |
| **Theme** | Fitness & Sports |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Submit your ideas to address the growing pressures on the city's resources, transport networks, and logistic infrastructure.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26217"></a>[217] SIH26217: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26217` (SIH26217) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Hardware |
| **Theme** | MedTech / BioTech / HealthTech |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

There is a need to design drones and robots that can solve some of the pressing challenges of India such as handling medical emergencies, search and rescue operations, etc.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26218"></a>[218] SIH26218: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26218` (SIH26218) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Hardware |
| **Theme** | Smart Resource Conservation |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Solutions could be in the form of waste segregation, disposal, and improve sanitization system.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26219"></a>[219] SIH26219: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26219` (SIH26219) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Hardware |
| **Theme** | Travel & Tourism |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

A solution/idea that can boost the current situation of the tourism industries including hotels, travel and others.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26220"></a>[220] SIH26220: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26220` (SIH26220) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Hardware |
| **Theme** | Renewable / Sustainable Energy |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Innovative ideas that help manage and generate renewable /sustainable sources more efficiently.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26221"></a>[221] SIH26221: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26221` (SIH26221) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Hardware |
| **Theme** | Miscellaneous |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Provide ideas in a decentralized and distributed ledger technology used to store digital information that powers cryptocurrencies and NFTs and can radically change multiple sectors.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26222"></a>[222] SIH26222: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26222` (SIH26222) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Hardware |
| **Theme** | Smart Education |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Smart education, a concept that describes learning in digital age. It enables learners to learn more effectively, efficiently, flexibly and comfortably.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26223"></a>[223] SIH26223: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26223` (SIH26223) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Hardware |
| **Theme** | Disaster Management |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Disaster management includes ideas related to risk mitigation, Planning and management before, after or during a disaster.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26224"></a>[224] SIH26224: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26224` (SIH26224) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Hardware |
| **Theme** | Travel & Tourism |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Technology ideas in tertiary sectors like Hospitality, Financial Services, Entertainment and Retail.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26225"></a>[225] SIH26225: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26225` (SIH26225) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Hardware |
| **Theme** | Heritage & Culture |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Challenge your creative mind to conceptualize and develop unique toys and games based on our civilization, history, and culture etc.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---

### <a id="sih26226"></a>[226] SIH26226: Student Innovation

| Attribute | Value |
|---|---|
| **Problem Statement ID** | `26226` (SIH26226) |
| **Problem Statement Title** | Student Innovation |
| **Organization** | AICTE |
| **Department** | AICTE, MIC-Student Innovation |
| **Category** | Hardware |
| **Theme** | Space Technology |
| **Submitted Idea(s) Count** | 0/500 |
| **Submission Deadline** | 20 September 2026 |

#### Description & Problem Scope

Space technology refers to the application of engineering principles to the design, development, manufacture, and operation of devices and systems for space travel and exploration.

[&uarr; Back to Top](#table-of-contents) &nbsp;|&nbsp; [&uarr; Back to Index](#master-problem-statement-index)

---
