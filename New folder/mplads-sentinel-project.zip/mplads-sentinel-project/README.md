# 🛡️ MPLADS Sentinel (रक्षक)
### *AI-Powered Anomaly, Fraud & Inefficiency Detection Layer for eSAKSHI*
**Problem Statement: SIH26102 | Ministry of Statistics and Programme Implementation (MoSPI)**

---

## 📁 Reorganized Project Structure

This folder was consolidated from 26 files down to **14**, by removing exact duplicates and
merging documents that are always read together. No content was deleted — everything below
is still fully present, just organized so the team isn't juggling near-identical files.

```
project/
├── README.md                                  ← you are here
│
├── docs/
│   ├── RESEARCH_AND_ANALYSIS.md                ← Deep-Dive Analysis + 12-Stage Workflow + Data Sources (merged)
│   ├── TECHNICAL_BUILD_GUIDE.md                ← Master Execution Guide + Free AI Agent Build Guide (merged)
│   ├── PITCH_DECK_6_SLIDE_OFFICIAL.md          ← Official SIH submission format (unchanged, kept separate)
│   ├── PITCH_DECK_12_SLIDE_DETAILED.md         ← Internal detailed deck w/ speaker notes (unchanged, kept separate)
│   └── SIH_2026_PROBLEM_STATEMENTS_DIRECTORY.md ← Full 226-PS reference (deduped, kept for citation only)
│
├── data/
│   ├── MPLADS_Allocated_Limits.csv             ← LS + RS combined, 774 rows, cleaned amounts
│   ├── MPLADS_Calamity_Consent.csv             ← LS + RS combined, 32 rows
│   ├── MPLADS_Works_Recommended.csv            ← LS + RS combined, 11,000 rows
│   ├── MPLADS_Works_Sanctioned.csv             ← LS + RS combined, 10,000 rows
│   ├── MPLADS_Works_Completed.csv              ← LS + RS combined, 9,000 rows
│   └── MPLADS_Expenditure.csv                  ← LS + RS combined, 15,000 rows
│
├── statutory/
│   └── MPLADS_Guidelines_2023_Official.pdf     ← Official MoSPI guidelines (source of every rule threshold)
│
└── case_study/
    └── CAG_Audit_Case_Study_Anand_District.pdf ← Real fraud precedent (4 pages, combined into 1 PDF)
```

---

## 🗑️ What was removed (and why it's safe)

| Removed | Reason |
|---|---|
| `SIH26102_MPLADS_Deep_Dive_Analysis_1_.md` | **Byte-for-byte duplicate** of `SIH26102_Deep_Dive_Problem_Analysis.md` (verified via checksum) |
| `SIH_2026_Problem_Statements.md` | **Byte-for-byte duplicate** of `SIH_2026_All_Problem_Statements_Directory.md` |
| `Allocated_Limit_for_Honble_MPs.csv` | Superseded — the `__Lok_Sabha_` version has newer, updated allocation figures for the same MPs; the un-suffixed file was a stale earlier pull |
| 6× separate LS/RS CSV pairs | Merged into 6 combined files with a `House` column (Lok Sabha / Rajya Sabha), instead of 12 near-identical files |
| 4× CAG audit screenshots | Combined into a single ordered PDF, same content, one file instead of four |

---

## 🧹 What changed inside the merged CSVs (worth knowing before you code against them)

Every combined data file has already had these fixes applied, so downstream code doesn't need to redo them:

1. **"Grand Total" footer row removed** — every original file had one baked in as a fake data row; if left in, it silently corrupts any `.sum()` or `pd.to_numeric()` on the amount column.
2. **Amount columns coerced to real numbers** — originals stored amounts as text with commas (`"1,47,000,000"`); now proper numeric columns.
3. **`MP_Name` column standardized** — Lok Sabha files used `"Hon'ble Members of Parliaments"` (plural) and Rajya Sabha used the singular form; both are now unified under `MP_Name`.
4. **`House` column added** — every row now says `Lok Sabha` or `Rajya Sabha`, so you can filter or `groupby` across both without re-merging.
5. **Fresh sequential `Sr_No`** — the original per-file serial numbers reset at 1 in both LS and RS files, which would collide after merging; replaced with one continuous ID.

---

## 🧠 Quick Orientation — What's in Each Doc

- **`RESEARCH_AND_ANALYSIS.md`** — read this first. Covers *why* the problem exists, the 12-stage financial lifecycle with fraud vulnerabilities at each stage, and an honest assessment of what data is/isn't available.
- **`TECHNICAL_BUILD_GUIDE.md`** — the actual engineering plan: DB schema, the 5-pillar risk engine (NLP duplicate matching, stats-based cost outliers, graph-based cartel detection, rule engine, XAI layer), plus an optional RAG copilot add-on.
- **`PITCH_DECK_6_SLIDE_OFFICIAL.md`** — use this one for the actual SIH submission portal (matches the mandated template).
- **`PITCH_DECK_12_SLIDE_DETAILED.md`** — use this one internally / for mentor review sessions where more depth helps.
- **`SIH_2026_PROBLEM_STATEMENTS_DIRECTORY.md`** — only needed if you ever have to reference or compare against another problem statement's exact wording. Safe to ignore day-to-day.

---
*Consolidated for Smart India Hackathon 2026 | Problem Statement SIH26102*
